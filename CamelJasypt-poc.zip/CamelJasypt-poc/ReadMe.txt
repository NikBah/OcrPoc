Camel Router Spring Project
===========================

To build this project use

    mvn install

To run this project with Maven use

    mvn camel:run

For more help see the Apache Camel documentation

    http://camel.apache.org/jasypt.html

Tooling
=======
Apache Camel Jasypt takes the following options
 
  -h or -help = Displays the help screen
  -c or -command <command> = Command either encrypt or decrypt
  -p or -password <password> = Password to use
  -i or -input <input> = Text to encrypt or decrypt
  -a or -algorithm <algorithm> = Optional algorithm to use
  
  e.g.
  
  java -jar apache-camel-2.15.6\lib\camel-jasypt-2.15.6.jar -c encrypt -p secret -i TEST
  Encrypted text: HzdcEEgcjl2glwcPG+tMXA==
  
  java -jar apache-camel-2.15.6\lib\camel-jasypt-2.15.6.jar -c decrypt -p secret -i HzdcEEgcjl2glwcPG+tMXA==
  Decrypted text: TEST
  