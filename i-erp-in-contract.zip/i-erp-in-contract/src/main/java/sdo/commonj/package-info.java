@javax.xml.bind.annotation.XmlSchema(namespace = "commonj.sdo", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package sdo.commonj;
