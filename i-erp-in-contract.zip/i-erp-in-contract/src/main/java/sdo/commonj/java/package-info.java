@javax.xml.bind.annotation.XmlSchema(namespace = "commonj.sdo/java")
package sdo.commonj.java;
