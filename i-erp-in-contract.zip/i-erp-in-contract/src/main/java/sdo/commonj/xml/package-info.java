@javax.xml.bind.annotation.XmlSchema(namespace = "commonj.sdo/xml")
package sdo.commonj.xml;
