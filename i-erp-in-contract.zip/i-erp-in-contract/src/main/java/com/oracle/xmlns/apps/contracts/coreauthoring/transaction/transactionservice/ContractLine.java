
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.oracle.xmlns.adf.svc.types.AmountType;
import com.oracle.xmlns.apps.contracts.coreauthoring.lines.flex.lines.ContractLineDescFlexfield;


/**
 * <p>Java class for ContractLine complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContractLine"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MajorVersion" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ExternalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SourceCodeClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LineNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LineTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="JtotObject1Code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="StartDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="EndDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="Object1Id1" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Object1Id2" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ItemName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="UomCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NumOfItem" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="LineAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="PriceUnit" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="TaxAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="ShipToAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ShipToSiteUseId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ShipInvOrgId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="TaxExemptionControl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExemptReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExemptCertificateNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OutputTaxClassificationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Comments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AgreedAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="Cognomen" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrigSystemSourceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrigSystemReference1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrigSystemId1" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="StatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CleId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="HoldReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HoldUntilDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="DeleteFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="CustPoNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalItemKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalItemReference1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalItemReference2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalItemReference3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalItemReference4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalItemReference5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalItemSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TrnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TrnCodeSetId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="HoldReasonCodeSetId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ContractParty" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractParty" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ContractSubLine" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractLine" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ContractLineDFFVL" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/lines/flex/lines/}ContractLineDescFlexfield" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContractLine", propOrder = {
    "id",
    "majorVersion",
    "externalSourceKey",
    "externalReferenceKey",
    "sourceCodeClass",
    "lineNumber",
    "lineTypeId",
    "jtotObject1Code",
    "startDate",
    "endDate",
    "object1Id1",
    "object1Id2",
    "itemName",
    "name",
    "description",
    "uomCode",
    "numOfItem",
    "lineAmount",
    "priceUnit",
    "taxAmount",
    "shipToAcctId",
    "shipToSiteUseId",
    "shipInvOrgId",
    "taxExemptionControl",
    "exemptReasonCode",
    "exemptCertificateNumber",
    "outputTaxClassificationCode",
    "comments",
    "agreedAmount",
    "cognomen",
    "origSystemSourceCode",
    "origSystemReference1",
    "origSystemId1",
    "statusCode",
    "cleId",
    "holdReasonCode",
    "holdUntilDate",
    "deleteFlag",
    "custPoNumber",
    "externalItemKey",
    "externalItemReference1",
    "externalItemReference2",
    "externalItemReference3",
    "externalItemReference4",
    "externalItemReference5",
    "externalItemSource",
    "trnCode",
    "trnCodeSetId",
    "holdReasonCodeSetId",
    "contractParty",
    "contractSubLine",
    "contractLineDFFVL"
})
@XmlSeeAlso({
    ContractProjectLine.class,
    ContractServiceLine.class,
    ContractBuyLine.class,
    SalesAgreementLineSA.class
})
public class ContractLine {

    @XmlElement(name = "Id")
    protected Long id;
    @XmlElement(name = "MajorVersion")
    protected Long majorVersion;
    @XmlElementRef(name = "ExternalSourceKey", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalSourceKey;
    @XmlElementRef(name = "ExternalReferenceKey", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalReferenceKey;
    @XmlElement(name = "SourceCodeClass")
    protected String sourceCodeClass;
    @XmlElement(name = "LineNumber")
    protected String lineNumber;
    @XmlElement(name = "LineTypeId")
    protected Long lineTypeId;
    @XmlElementRef(name = "JtotObject1Code", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> jtotObject1Code;
    @XmlElement(name = "StartDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar startDate;
    @XmlElementRef(name = "EndDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> endDate;
    @XmlElementRef(name = "Object1Id1", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> object1Id1;
    @XmlElementRef(name = "Object1Id2", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> object1Id2;
    @XmlElementRef(name = "ItemName", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> itemName;
    @XmlElementRef(name = "Name", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> name;
    @XmlElementRef(name = "Description", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "UomCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> uomCode;
    @XmlElementRef(name = "NumOfItem", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> numOfItem;
    @XmlElementRef(name = "LineAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> lineAmount;
    @XmlElementRef(name = "PriceUnit", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> priceUnit;
    @XmlElementRef(name = "TaxAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> taxAmount;
    @XmlElementRef(name = "ShipToAcctId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> shipToAcctId;
    @XmlElementRef(name = "ShipToSiteUseId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> shipToSiteUseId;
    @XmlElementRef(name = "ShipInvOrgId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> shipInvOrgId;
    @XmlElementRef(name = "TaxExemptionControl", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> taxExemptionControl;
    @XmlElementRef(name = "ExemptReasonCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> exemptReasonCode;
    @XmlElementRef(name = "ExemptCertificateNumber", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> exemptCertificateNumber;
    @XmlElementRef(name = "OutputTaxClassificationCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> outputTaxClassificationCode;
    @XmlElementRef(name = "Comments", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> comments;
    @XmlElementRef(name = "AgreedAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> agreedAmount;
    @XmlElementRef(name = "Cognomen", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cognomen;
    @XmlElementRef(name = "OrigSystemSourceCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> origSystemSourceCode;
    @XmlElementRef(name = "OrigSystemReference1", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> origSystemReference1;
    @XmlElementRef(name = "OrigSystemId1", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> origSystemId1;
    @XmlElement(name = "StatusCode")
    protected String statusCode;
    @XmlElementRef(name = "CleId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> cleId;
    @XmlElementRef(name = "HoldReasonCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> holdReasonCode;
    @XmlElementRef(name = "HoldUntilDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> holdUntilDate;
    @XmlElementRef(name = "DeleteFlag", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> deleteFlag;
    @XmlElementRef(name = "CustPoNumber", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> custPoNumber;
    @XmlElementRef(name = "ExternalItemKey", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalItemKey;
    @XmlElementRef(name = "ExternalItemReference1", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalItemReference1;
    @XmlElementRef(name = "ExternalItemReference2", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalItemReference2;
    @XmlElementRef(name = "ExternalItemReference3", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalItemReference3;
    @XmlElementRef(name = "ExternalItemReference4", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalItemReference4;
    @XmlElementRef(name = "ExternalItemReference5", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalItemReference5;
    @XmlElementRef(name = "ExternalItemSource", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalItemSource;
    @XmlElementRef(name = "TrnCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> trnCode;
    @XmlElementRef(name = "TrnCodeSetId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> trnCodeSetId;
    @XmlElementRef(name = "HoldReasonCodeSetId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> holdReasonCodeSetId;
    @XmlElement(name = "ContractParty")
    protected List<ContractParty> contractParty;
    @XmlElement(name = "ContractSubLine")
    protected List<ContractLine> contractSubLine;
    @XmlElement(name = "ContractLineDFFVL")
    protected ContractLineDescFlexfield contractLineDFFVL;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setId(Long value) {
        this.id = value;
    }

    /**
     * Gets the value of the majorVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMajorVersion() {
        return majorVersion;
    }

    /**
     * Sets the value of the majorVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMajorVersion(Long value) {
        this.majorVersion = value;
    }

    /**
     * Gets the value of the externalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalSourceKey() {
        return externalSourceKey;
    }

    /**
     * Sets the value of the externalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalSourceKey(JAXBElement<String> value) {
        this.externalSourceKey = value;
    }

    /**
     * Gets the value of the externalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalReferenceKey() {
        return externalReferenceKey;
    }

    /**
     * Sets the value of the externalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalReferenceKey(JAXBElement<String> value) {
        this.externalReferenceKey = value;
    }

    /**
     * Gets the value of the sourceCodeClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCodeClass() {
        return sourceCodeClass;
    }

    /**
     * Sets the value of the sourceCodeClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCodeClass(String value) {
        this.sourceCodeClass = value;
    }

    /**
     * Gets the value of the lineNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineNumber() {
        return lineNumber;
    }

    /**
     * Sets the value of the lineNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineNumber(String value) {
        this.lineNumber = value;
    }

    /**
     * Gets the value of the lineTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLineTypeId() {
        return lineTypeId;
    }

    /**
     * Sets the value of the lineTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLineTypeId(Long value) {
        this.lineTypeId = value;
    }

    /**
     * Gets the value of the jtotObject1Code property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getJtotObject1Code() {
        return jtotObject1Code;
    }

    /**
     * Sets the value of the jtotObject1Code property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setJtotObject1Code(JAXBElement<String> value) {
        this.jtotObject1Code = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDate(XMLGregorianCalendar value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setEndDate(JAXBElement<XMLGregorianCalendar> value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the object1Id1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getObject1Id1() {
        return object1Id1;
    }

    /**
     * Sets the value of the object1Id1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setObject1Id1(JAXBElement<Long> value) {
        this.object1Id1 = value;
    }

    /**
     * Gets the value of the object1Id2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getObject1Id2() {
        return object1Id2;
    }

    /**
     * Sets the value of the object1Id2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setObject1Id2(JAXBElement<Long> value) {
        this.object1Id2 = value;
    }

    /**
     * Gets the value of the itemName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getItemName() {
        return itemName;
    }

    /**
     * Sets the value of the itemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setItemName(JAXBElement<String> value) {
        this.itemName = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setName(JAXBElement<String> value) {
        this.name = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the uomCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUomCode() {
        return uomCode;
    }

    /**
     * Sets the value of the uomCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUomCode(JAXBElement<String> value) {
        this.uomCode = value;
    }

    /**
     * Gets the value of the numOfItem property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getNumOfItem() {
        return numOfItem;
    }

    /**
     * Sets the value of the numOfItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setNumOfItem(JAXBElement<BigDecimal> value) {
        this.numOfItem = value;
    }

    /**
     * Gets the value of the lineAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getLineAmount() {
        return lineAmount;
    }

    /**
     * Sets the value of the lineAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setLineAmount(JAXBElement<AmountType> value) {
        this.lineAmount = value;
    }

    /**
     * Gets the value of the priceUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getPriceUnit() {
        return priceUnit;
    }

    /**
     * Sets the value of the priceUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setPriceUnit(JAXBElement<BigDecimal> value) {
        this.priceUnit = value;
    }

    /**
     * Gets the value of the taxAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getTaxAmount() {
        return taxAmount;
    }

    /**
     * Sets the value of the taxAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setTaxAmount(JAXBElement<AmountType> value) {
        this.taxAmount = value;
    }

    /**
     * Gets the value of the shipToAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getShipToAcctId() {
        return shipToAcctId;
    }

    /**
     * Sets the value of the shipToAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setShipToAcctId(JAXBElement<Long> value) {
        this.shipToAcctId = value;
    }

    /**
     * Gets the value of the shipToSiteUseId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getShipToSiteUseId() {
        return shipToSiteUseId;
    }

    /**
     * Sets the value of the shipToSiteUseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setShipToSiteUseId(JAXBElement<Long> value) {
        this.shipToSiteUseId = value;
    }

    /**
     * Gets the value of the shipInvOrgId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getShipInvOrgId() {
        return shipInvOrgId;
    }

    /**
     * Sets the value of the shipInvOrgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setShipInvOrgId(JAXBElement<Long> value) {
        this.shipInvOrgId = value;
    }

    /**
     * Gets the value of the taxExemptionControl property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTaxExemptionControl() {
        return taxExemptionControl;
    }

    /**
     * Sets the value of the taxExemptionControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTaxExemptionControl(JAXBElement<String> value) {
        this.taxExemptionControl = value;
    }

    /**
     * Gets the value of the exemptReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExemptReasonCode() {
        return exemptReasonCode;
    }

    /**
     * Sets the value of the exemptReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExemptReasonCode(JAXBElement<String> value) {
        this.exemptReasonCode = value;
    }

    /**
     * Gets the value of the exemptCertificateNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExemptCertificateNumber() {
        return exemptCertificateNumber;
    }

    /**
     * Sets the value of the exemptCertificateNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExemptCertificateNumber(JAXBElement<String> value) {
        this.exemptCertificateNumber = value;
    }

    /**
     * Gets the value of the outputTaxClassificationCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOutputTaxClassificationCode() {
        return outputTaxClassificationCode;
    }

    /**
     * Sets the value of the outputTaxClassificationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOutputTaxClassificationCode(JAXBElement<String> value) {
        this.outputTaxClassificationCode = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setComments(JAXBElement<String> value) {
        this.comments = value;
    }

    /**
     * Gets the value of the agreedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getAgreedAmount() {
        return agreedAmount;
    }

    /**
     * Sets the value of the agreedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setAgreedAmount(JAXBElement<AmountType> value) {
        this.agreedAmount = value;
    }

    /**
     * Gets the value of the cognomen property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCognomen() {
        return cognomen;
    }

    /**
     * Sets the value of the cognomen property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCognomen(JAXBElement<String> value) {
        this.cognomen = value;
    }

    /**
     * Gets the value of the origSystemSourceCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOrigSystemSourceCode() {
        return origSystemSourceCode;
    }

    /**
     * Sets the value of the origSystemSourceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOrigSystemSourceCode(JAXBElement<String> value) {
        this.origSystemSourceCode = value;
    }

    /**
     * Gets the value of the origSystemReference1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOrigSystemReference1() {
        return origSystemReference1;
    }

    /**
     * Sets the value of the origSystemReference1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOrigSystemReference1(JAXBElement<String> value) {
        this.origSystemReference1 = value;
    }

    /**
     * Gets the value of the origSystemId1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getOrigSystemId1() {
        return origSystemId1;
    }

    /**
     * Sets the value of the origSystemId1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setOrigSystemId1(JAXBElement<BigDecimal> value) {
        this.origSystemId1 = value;
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCode(String value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the cleId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCleId() {
        return cleId;
    }

    /**
     * Sets the value of the cleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCleId(JAXBElement<Long> value) {
        this.cleId = value;
    }

    /**
     * Gets the value of the holdReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getHoldReasonCode() {
        return holdReasonCode;
    }

    /**
     * Sets the value of the holdReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setHoldReasonCode(JAXBElement<String> value) {
        this.holdReasonCode = value;
    }

    /**
     * Gets the value of the holdUntilDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getHoldUntilDate() {
        return holdUntilDate;
    }

    /**
     * Sets the value of the holdUntilDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setHoldUntilDate(JAXBElement<XMLGregorianCalendar> value) {
        this.holdUntilDate = value;
    }

    /**
     * Gets the value of the deleteFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getDeleteFlag() {
        return deleteFlag;
    }

    /**
     * Sets the value of the deleteFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setDeleteFlag(JAXBElement<Boolean> value) {
        this.deleteFlag = value;
    }

    /**
     * Gets the value of the custPoNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustPoNumber() {
        return custPoNumber;
    }

    /**
     * Sets the value of the custPoNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustPoNumber(JAXBElement<String> value) {
        this.custPoNumber = value;
    }

    /**
     * Gets the value of the externalItemKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalItemKey() {
        return externalItemKey;
    }

    /**
     * Sets the value of the externalItemKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalItemKey(JAXBElement<String> value) {
        this.externalItemKey = value;
    }

    /**
     * Gets the value of the externalItemReference1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalItemReference1() {
        return externalItemReference1;
    }

    /**
     * Sets the value of the externalItemReference1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalItemReference1(JAXBElement<String> value) {
        this.externalItemReference1 = value;
    }

    /**
     * Gets the value of the externalItemReference2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalItemReference2() {
        return externalItemReference2;
    }

    /**
     * Sets the value of the externalItemReference2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalItemReference2(JAXBElement<String> value) {
        this.externalItemReference2 = value;
    }

    /**
     * Gets the value of the externalItemReference3 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalItemReference3() {
        return externalItemReference3;
    }

    /**
     * Sets the value of the externalItemReference3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalItemReference3(JAXBElement<String> value) {
        this.externalItemReference3 = value;
    }

    /**
     * Gets the value of the externalItemReference4 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalItemReference4() {
        return externalItemReference4;
    }

    /**
     * Sets the value of the externalItemReference4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalItemReference4(JAXBElement<String> value) {
        this.externalItemReference4 = value;
    }

    /**
     * Gets the value of the externalItemReference5 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalItemReference5() {
        return externalItemReference5;
    }

    /**
     * Sets the value of the externalItemReference5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalItemReference5(JAXBElement<String> value) {
        this.externalItemReference5 = value;
    }

    /**
     * Gets the value of the externalItemSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalItemSource() {
        return externalItemSource;
    }

    /**
     * Sets the value of the externalItemSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalItemSource(JAXBElement<String> value) {
        this.externalItemSource = value;
    }

    /**
     * Gets the value of the trnCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTrnCode() {
        return trnCode;
    }

    /**
     * Sets the value of the trnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTrnCode(JAXBElement<String> value) {
        this.trnCode = value;
    }

    /**
     * Gets the value of the trnCodeSetId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTrnCodeSetId() {
        return trnCodeSetId;
    }

    /**
     * Sets the value of the trnCodeSetId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTrnCodeSetId(JAXBElement<Long> value) {
        this.trnCodeSetId = value;
    }

    /**
     * Gets the value of the holdReasonCodeSetId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHoldReasonCodeSetId() {
        return holdReasonCodeSetId;
    }

    /**
     * Sets the value of the holdReasonCodeSetId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHoldReasonCodeSetId(JAXBElement<Long> value) {
        this.holdReasonCodeSetId = value;
    }

    /**
     * Gets the value of the contractParty property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contractParty property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContractParty().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContractParty }
     * 
     * 
     */
    public List<ContractParty> getContractParty() {
        if (contractParty == null) {
            contractParty = new ArrayList<ContractParty>();
        }
        return this.contractParty;
    }

    /**
     * Gets the value of the contractSubLine property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contractSubLine property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContractSubLine().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContractLine }
     * 
     * 
     */
    public List<ContractLine> getContractSubLine() {
        if (contractSubLine == null) {
            contractSubLine = new ArrayList<ContractLine>();
        }
        return this.contractSubLine;
    }

    /**
     * Gets the value of the contractLineDFFVL property.
     * 
     * @return
     *     possible object is
     *     {@link ContractLineDescFlexfield }
     *     
     */
    public ContractLineDescFlexfield getContractLineDFFVL() {
        return contractLineDFFVL;
    }

    /**
     * Sets the value of the contractLineDFFVL property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContractLineDescFlexfield }
     *     
     */
    public void setContractLineDFFVL(ContractLineDescFlexfield value) {
        this.contractLineDFFVL = value;
    }

}
