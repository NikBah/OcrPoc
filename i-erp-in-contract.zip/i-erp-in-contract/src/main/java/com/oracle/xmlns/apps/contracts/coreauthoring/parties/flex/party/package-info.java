@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/parties/flex/party/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.apps.contracts.coreauthoring.parties.flex.party;
