@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/lines/flex/lines/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.apps.contracts.coreauthoring.lines.flex.lines;
