
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import com.oracle.xmlns.adf.svc.types.AmountType;
import com.oracle.xmlns.adf.svc.types.MeasureType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ContractPartyAddress_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractPartyAddress");
    private final static QName _ContractPartyAddressResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractPartyAddressResult");
    private final static QName _TierLineSA_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "tierLineSA");
    private final static QName _TierLineSAResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "tierLineSAResult");
    private final static QName _PricingTermSAResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "pricingTermSAResult");
    private final static QName _PricingTermSA_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "pricingTermSA");
    private final static QName _ContractPartyContactResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractPartyContactResult");
    private final static QName _ContractPartyContact_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractPartyContact");
    private final static QName _ContractParty_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractParty");
    private final static QName _ContractPartyResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractPartyResult");
    private final static QName _ContractLine_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractLine");
    private final static QName _ContractProjectLine_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractProjectLine");
    private final static QName _SalesCredit_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "salesCredit");
    private final static QName _SalesCreditResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "salesCreditResult");
    private final static QName _ContractServiceLine_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractServiceLine");
    private final static QName _ContractRelatedDocumentResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractRelatedDocumentResult");
    private final static QName _ContractRelatedDocument_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractRelatedDocument");
    private final static QName _ContractHeader_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractHeader");
    private final static QName _ContractHeaderResult_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractHeaderResult");
    private final static QName _ContractBuyLine_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "contractBuyLine");
    private final static QName _SalesAgreementLineSA_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "salesAgreementLineSA");
    private final static QName _ContractLineExternalSourceKey_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalSourceKey");
    private final static QName _ContractLineExternalReferenceKey_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalReferenceKey");
    private final static QName _ContractLineJtotObject1Code_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "JtotObject1Code");
    private final static QName _ContractLineEndDate_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "EndDate");
    private final static QName _ContractLineObject1Id1_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Object1Id1");
    private final static QName _ContractLineObject1Id2_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Object1Id2");
    private final static QName _ContractLineItemName_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ItemName");
    private final static QName _ContractLineName_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Name");
    private final static QName _ContractLineDescription_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Description");
    private final static QName _ContractLineUomCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "UomCode");
    private final static QName _ContractLineNumOfItem_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "NumOfItem");
    private final static QName _ContractLineLineAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "LineAmount");
    private final static QName _ContractLinePriceUnit_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "PriceUnit");
    private final static QName _ContractLineTaxAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "TaxAmount");
    private final static QName _ContractLineShipToAcctId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ShipToAcctId");
    private final static QName _ContractLineShipToSiteUseId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ShipToSiteUseId");
    private final static QName _ContractLineShipInvOrgId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ShipInvOrgId");
    private final static QName _ContractLineTaxExemptionControl_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "TaxExemptionControl");
    private final static QName _ContractLineExemptReasonCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExemptReasonCode");
    private final static QName _ContractLineExemptCertificateNumber_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExemptCertificateNumber");
    private final static QName _ContractLineOutputTaxClassificationCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "OutputTaxClassificationCode");
    private final static QName _ContractLineComments_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Comments");
    private final static QName _ContractLineAgreedAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreedAmount");
    private final static QName _ContractLineCognomen_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Cognomen");
    private final static QName _ContractLineOrigSystemSourceCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "OrigSystemSourceCode");
    private final static QName _ContractLineOrigSystemReference1_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "OrigSystemReference1");
    private final static QName _ContractLineOrigSystemId1_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "OrigSystemId1");
    private final static QName _ContractLineCleId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "CleId");
    private final static QName _ContractLineHoldReasonCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "HoldReasonCode");
    private final static QName _ContractLineHoldUntilDate_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "HoldUntilDate");
    private final static QName _ContractLineDeleteFlag_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "DeleteFlag");
    private final static QName _ContractLineCustPoNumber_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "CustPoNumber");
    private final static QName _ContractLineExternalItemKey_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalItemKey");
    private final static QName _ContractLineExternalItemReference1_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalItemReference1");
    private final static QName _ContractLineExternalItemReference2_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalItemReference2");
    private final static QName _ContractLineExternalItemReference3_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalItemReference3");
    private final static QName _ContractLineExternalItemReference4_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalItemReference4");
    private final static QName _ContractLineExternalItemReference5_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalItemReference5");
    private final static QName _ContractLineExternalItemSource_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ExternalItemSource");
    private final static QName _ContractLineTrnCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "TrnCode");
    private final static QName _ContractLineTrnCodeSetId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "TrnCodeSetId");
    private final static QName _ContractLineHoldReasonCodeSetId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "HoldReasonCodeSetId");
    private final static QName _SalesAgreementLineSAPriceListId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "PriceListId");
    private final static QName _SalesAgreementLineSAAllowPricelistOverrideYn_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AllowPricelistOverrideYn");
    private final static QName _SalesAgreementLineSAMinReleaseQuantity_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "MinReleaseQuantity");
    private final static QName _SalesAgreementLineSACommittedQuantity_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "CommittedQuantity");
    private final static QName _SalesAgreementLineSACommitLevelCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "CommitLevelCode");
    private final static QName _ContractBuyLineLinePurchaseAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "LinePurchaseAmount");
    private final static QName _ContractBuyLineSupplierId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "SupplierId");
    private final static QName _ContractBuyLineSupplierSiteId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "SupplierSiteId");
    private final static QName _ContractBuyLineRecvInvOrgId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "RecvInvOrgId");
    private final static QName _ContractBuyLineDeliveryDate_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "DeliveryDate");
    private final static QName _ContractBuyLineFobCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "FobCode");
    private final static QName _ContractBuyLineFreightTermsCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "FreightTermsCode");
    private final static QName _ContractBuyLineRecvLocationId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "RecvLocationId");
    private final static QName _ContractBuyLinePurchasingCategoryId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "PurchasingCategoryId");
    private final static QName _ContractBuyLinePaymentTermsId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "PaymentTermsId");
    private final static QName _ContractBuyLineCarrierId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "CarrierId");
    private final static QName _ContractBuyLineAgreementUnitPrice_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreementUnitPrice");
    private final static QName _ContractBuyLineAgreementLimitPrice_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreementLimitPrice");
    private final static QName _ContractBuyLineAgreedQuantity_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreedQuantity");
    private final static QName _ContractBuyLineAgreementLimitQuantity_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreementLimitQuantity");
    private final static QName _ContractBuyLineAgreementLimitAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreementLimitAmount");
    private final static QName _ContractBuyLineMinReleaseAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "MinReleaseAmount");
    private final static QName _ContractHeaderSalesAcctId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "SalesAcctId");
    private final static QName _ContractHeaderApTermsId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ApTermsId");
    private final static QName _ContractHeaderAmendmentEffectiveDate_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AmendmentEffectiveDate");
    private final static QName _ContractHeaderAutoReleaseInvoice_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AutoReleaseInvoice");
    private final static QName _ContractHeaderBillSequence_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "BillSequence");
    private final static QName _ContractHeaderBillToAcctId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "BillToAcctId");
    private final static QName _ContractHeaderBillToSiteUseId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "BillToSiteUseId");
    private final static QName _ContractHeaderBilledAtSource_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "BilledAtSource");
    private final static QName _ContractHeaderContributionPercent_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ContributionPercent");
    private final static QName _ContractHeaderEstimatedAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "EstimatedAmount");
    private final static QName _ContractHeaderFob_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Fob");
    private final static QName _ContractHeaderFreightTerms_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "FreightTerms");
    private final static QName _ContractHeaderInvConvRateDateType_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "InvConvRateDateType");
    private final static QName _ContractHeaderInvConvRateDate_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "InvConvRateDate");
    private final static QName _ContractHeaderInvConvRateType_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "InvConvRateType");
    private final static QName _ContractHeaderInvTrxTypeId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "InvTrxTypeId");
    private final static QName _ContractHeaderLastRevRecogDate_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "LastRevRecogDate");
    private final static QName _ContractHeaderLegalEntityId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "LegalEntityId");
    private final static QName _ContractHeaderLineAutonumberEnabledFlag_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "LineAutonumberEnabledFlag");
    private final static QName _ContractHeaderNetInvoiceFlag_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "NetInvoiceFlag");
    private final static QName _ContractHeaderOverallRiskCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "OverallRiskCode");
    private final static QName _ContractHeaderOwningOrgId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "OwningOrgId");
    private final static QName _ContractHeaderShiptoLocationId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ShiptoLocationId");
    private final static QName _ContractHeaderShortDescription_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ShortDescription");
    private final static QName _ContractHeaderSoldToAcctId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "SoldToAcctId");
    private final static QName _ContractHeaderSoldToSiteId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "SoldToSiteId");
    private final static QName _ContractHeaderWebServiceFlag_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "WebServiceFlag");
    private final static QName _ContractHeaderBilltoLocationId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "BilltoLocationId");
    private final static QName _ContractHeaderTermsTemplateId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "TermsTemplateId");
    private final static QName _ContractHeaderContractOwnerId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ContractOwnerId");
    private final static QName _ContractHeaderPartyId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "PartyId");
    private final static QName _ContractHeaderAgreementEnabledFlag_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreementEnabledFlag");
    private final static QName _ContractHeaderAgreementAmtLimit_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AgreementAmtLimit");
    private final static QName _ContractHeaderMinReleaseAmt_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "MinReleaseAmt");
    private final static QName _ContractHeaderEncumbranceLevel_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "EncumbranceLevel");
    private final static QName _ContractHeaderBillingSalesrepId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "BillingSalesrepId");
    private final static QName _ContractHeaderVersionDescription_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "VersionDescription");
    private final static QName _ContractHeaderPriceList_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "PriceList");
    private final static QName _ContractHeaderDiscountPercent_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "DiscountPercent");
    private final static QName _ContractHeaderAdjustmentBasis_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AdjustmentBasis");
    private final static QName _ContractHeaderCommitmentAmount_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "CommitmentAmount");
    private final static QName _ContractProjectLineLineValue_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "LineValue");
    private final static QName _ContractProjectLineBillPlanId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "BillPlanId");
    private final static QName _ContractProjectLineRevenuePlanId_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "RevenuePlanId");
    private final static QName _ContractProjectLinePercentComplete_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "PercentComplete");
    private final static QName _ContractProjectLineRevenueImpactDate_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "RevenueImpactDate");
    private final static QName _ContractPartyContactOwnerYn_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "OwnerYn");
    private final static QName _ContractPartyContactAccessLevel_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AccessLevel");
    private final static QName _PricingTermSAAdjustment_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "Adjustment");
    private final static QName _PricingTermSAAdjustmentBasisCode_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "AdjustmentBasisCode");
    private final static QName _PricingTermSAListPrice_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "ListPrice");
    private final static QName _TierLineSAMaximumValue_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", "MaximumValue");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ContractPartyAddress }
     * 
     */
    public ContractPartyAddress createContractPartyAddress() {
        return new ContractPartyAddress();
    }

    /**
     * Create an instance of {@link ContractPartyAddressResult }
     * 
     */
    public ContractPartyAddressResult createContractPartyAddressResult() {
        return new ContractPartyAddressResult();
    }

    /**
     * Create an instance of {@link TierLineSA }
     * 
     */
    public TierLineSA createTierLineSA() {
        return new TierLineSA();
    }

    /**
     * Create an instance of {@link TierLineSAResult }
     * 
     */
    public TierLineSAResult createTierLineSAResult() {
        return new TierLineSAResult();
    }

    /**
     * Create an instance of {@link PricingTermSAResult }
     * 
     */
    public PricingTermSAResult createPricingTermSAResult() {
        return new PricingTermSAResult();
    }

    /**
     * Create an instance of {@link PricingTermSA }
     * 
     */
    public PricingTermSA createPricingTermSA() {
        return new PricingTermSA();
    }

    /**
     * Create an instance of {@link ContractPartyContactResult }
     * 
     */
    public ContractPartyContactResult createContractPartyContactResult() {
        return new ContractPartyContactResult();
    }

    /**
     * Create an instance of {@link ContractPartyContact }
     * 
     */
    public ContractPartyContact createContractPartyContact() {
        return new ContractPartyContact();
    }

    /**
     * Create an instance of {@link ContractParty }
     * 
     */
    public ContractParty createContractParty() {
        return new ContractParty();
    }

    /**
     * Create an instance of {@link ContractPartyResult }
     * 
     */
    public ContractPartyResult createContractPartyResult() {
        return new ContractPartyResult();
    }

    /**
     * Create an instance of {@link ContractLine }
     * 
     */
    public ContractLine createContractLine() {
        return new ContractLine();
    }

    /**
     * Create an instance of {@link ContractProjectLine }
     * 
     */
    public ContractProjectLine createContractProjectLine() {
        return new ContractProjectLine();
    }

    /**
     * Create an instance of {@link SalesCredit }
     * 
     */
    public SalesCredit createSalesCredit() {
        return new SalesCredit();
    }

    /**
     * Create an instance of {@link SalesCreditResult }
     * 
     */
    public SalesCreditResult createSalesCreditResult() {
        return new SalesCreditResult();
    }

    /**
     * Create an instance of {@link ContractServiceLine }
     * 
     */
    public ContractServiceLine createContractServiceLine() {
        return new ContractServiceLine();
    }

    /**
     * Create an instance of {@link ContractRelatedDocumentResult }
     * 
     */
    public ContractRelatedDocumentResult createContractRelatedDocumentResult() {
        return new ContractRelatedDocumentResult();
    }

    /**
     * Create an instance of {@link ContractRelatedDocument }
     * 
     */
    public ContractRelatedDocument createContractRelatedDocument() {
        return new ContractRelatedDocument();
    }

    /**
     * Create an instance of {@link ContractHeader }
     * 
     */
    public ContractHeader createContractHeader() {
        return new ContractHeader();
    }

    /**
     * Create an instance of {@link ContractHeaderResult }
     * 
     */
    public ContractHeaderResult createContractHeaderResult() {
        return new ContractHeaderResult();
    }

    /**
     * Create an instance of {@link ContractBuyLine }
     * 
     */
    public ContractBuyLine createContractBuyLine() {
        return new ContractBuyLine();
    }

    /**
     * Create an instance of {@link SalesAgreementLineSA }
     * 
     */
    public SalesAgreementLineSA createSalesAgreementLineSA() {
        return new SalesAgreementLineSA();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractPartyAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractPartyAddress")
    public JAXBElement<ContractPartyAddress> createContractPartyAddress(ContractPartyAddress value) {
        return new JAXBElement<ContractPartyAddress>(_ContractPartyAddress_QNAME, ContractPartyAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractPartyAddressResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractPartyAddressResult")
    public JAXBElement<ContractPartyAddressResult> createContractPartyAddressResult(ContractPartyAddressResult value) {
        return new JAXBElement<ContractPartyAddressResult>(_ContractPartyAddressResult_QNAME, ContractPartyAddressResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TierLineSA }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "tierLineSA")
    public JAXBElement<TierLineSA> createTierLineSA(TierLineSA value) {
        return new JAXBElement<TierLineSA>(_TierLineSA_QNAME, TierLineSA.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TierLineSAResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "tierLineSAResult")
    public JAXBElement<TierLineSAResult> createTierLineSAResult(TierLineSAResult value) {
        return new JAXBElement<TierLineSAResult>(_TierLineSAResult_QNAME, TierLineSAResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PricingTermSAResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "pricingTermSAResult")
    public JAXBElement<PricingTermSAResult> createPricingTermSAResult(PricingTermSAResult value) {
        return new JAXBElement<PricingTermSAResult>(_PricingTermSAResult_QNAME, PricingTermSAResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PricingTermSA }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "pricingTermSA")
    public JAXBElement<PricingTermSA> createPricingTermSA(PricingTermSA value) {
        return new JAXBElement<PricingTermSA>(_PricingTermSA_QNAME, PricingTermSA.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractPartyContactResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractPartyContactResult")
    public JAXBElement<ContractPartyContactResult> createContractPartyContactResult(ContractPartyContactResult value) {
        return new JAXBElement<ContractPartyContactResult>(_ContractPartyContactResult_QNAME, ContractPartyContactResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractPartyContact }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractPartyContact")
    public JAXBElement<ContractPartyContact> createContractPartyContact(ContractPartyContact value) {
        return new JAXBElement<ContractPartyContact>(_ContractPartyContact_QNAME, ContractPartyContact.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractParty }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractParty")
    public JAXBElement<ContractParty> createContractParty(ContractParty value) {
        return new JAXBElement<ContractParty>(_ContractParty_QNAME, ContractParty.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractPartyResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractPartyResult")
    public JAXBElement<ContractPartyResult> createContractPartyResult(ContractPartyResult value) {
        return new JAXBElement<ContractPartyResult>(_ContractPartyResult_QNAME, ContractPartyResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractLine }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractLine")
    public JAXBElement<ContractLine> createContractLine(ContractLine value) {
        return new JAXBElement<ContractLine>(_ContractLine_QNAME, ContractLine.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractProjectLine }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractProjectLine")
    public JAXBElement<ContractProjectLine> createContractProjectLine(ContractProjectLine value) {
        return new JAXBElement<ContractProjectLine>(_ContractProjectLine_QNAME, ContractProjectLine.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SalesCredit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "salesCredit")
    public JAXBElement<SalesCredit> createSalesCredit(SalesCredit value) {
        return new JAXBElement<SalesCredit>(_SalesCredit_QNAME, SalesCredit.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SalesCreditResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "salesCreditResult")
    public JAXBElement<SalesCreditResult> createSalesCreditResult(SalesCreditResult value) {
        return new JAXBElement<SalesCreditResult>(_SalesCreditResult_QNAME, SalesCreditResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractServiceLine }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractServiceLine")
    public JAXBElement<ContractServiceLine> createContractServiceLine(ContractServiceLine value) {
        return new JAXBElement<ContractServiceLine>(_ContractServiceLine_QNAME, ContractServiceLine.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractRelatedDocumentResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractRelatedDocumentResult")
    public JAXBElement<ContractRelatedDocumentResult> createContractRelatedDocumentResult(ContractRelatedDocumentResult value) {
        return new JAXBElement<ContractRelatedDocumentResult>(_ContractRelatedDocumentResult_QNAME, ContractRelatedDocumentResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractRelatedDocument }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractRelatedDocument")
    public JAXBElement<ContractRelatedDocument> createContractRelatedDocument(ContractRelatedDocument value) {
        return new JAXBElement<ContractRelatedDocument>(_ContractRelatedDocument_QNAME, ContractRelatedDocument.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractHeader }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractHeader")
    public JAXBElement<ContractHeader> createContractHeader(ContractHeader value) {
        return new JAXBElement<ContractHeader>(_ContractHeader_QNAME, ContractHeader.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractHeaderResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractHeaderResult")
    public JAXBElement<ContractHeaderResult> createContractHeaderResult(ContractHeaderResult value) {
        return new JAXBElement<ContractHeaderResult>(_ContractHeaderResult_QNAME, ContractHeaderResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractBuyLine }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "contractBuyLine")
    public JAXBElement<ContractBuyLine> createContractBuyLine(ContractBuyLine value) {
        return new JAXBElement<ContractBuyLine>(_ContractBuyLine_QNAME, ContractBuyLine.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SalesAgreementLineSA }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "salesAgreementLineSA")
    public JAXBElement<SalesAgreementLineSA> createSalesAgreementLineSA(SalesAgreementLineSA value) {
        return new JAXBElement<SalesAgreementLineSA>(_SalesAgreementLineSA_QNAME, SalesAgreementLineSA.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalSourceKey", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalSourceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalSourceKey_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalReferenceKey", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalReferenceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalReferenceKey_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "JtotObject1Code", scope = ContractLine.class)
    public JAXBElement<String> createContractLineJtotObject1Code(String value) {
        return new JAXBElement<String>(_ContractLineJtotObject1Code_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "EndDate", scope = ContractLine.class)
    public JAXBElement<XMLGregorianCalendar> createContractLineEndDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractLineEndDate_QNAME, XMLGregorianCalendar.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Object1Id1", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineObject1Id1(Long value) {
        return new JAXBElement<Long>(_ContractLineObject1Id1_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Object1Id2", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineObject1Id2(Long value) {
        return new JAXBElement<Long>(_ContractLineObject1Id2_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ItemName", scope = ContractLine.class)
    public JAXBElement<String> createContractLineItemName(String value) {
        return new JAXBElement<String>(_ContractLineItemName_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Name", scope = ContractLine.class)
    public JAXBElement<String> createContractLineName(String value) {
        return new JAXBElement<String>(_ContractLineName_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Description", scope = ContractLine.class)
    public JAXBElement<String> createContractLineDescription(String value) {
        return new JAXBElement<String>(_ContractLineDescription_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "UomCode", scope = ContractLine.class)
    public JAXBElement<String> createContractLineUomCode(String value) {
        return new JAXBElement<String>(_ContractLineUomCode_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "NumOfItem", scope = ContractLine.class)
    public JAXBElement<BigDecimal> createContractLineNumOfItem(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractLineNumOfItem_QNAME, BigDecimal.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "LineAmount", scope = ContractLine.class)
    public JAXBElement<AmountType> createContractLineLineAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractLineLineAmount_QNAME, AmountType.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "PriceUnit", scope = ContractLine.class)
    public JAXBElement<BigDecimal> createContractLinePriceUnit(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractLinePriceUnit_QNAME, BigDecimal.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TaxAmount", scope = ContractLine.class)
    public JAXBElement<AmountType> createContractLineTaxAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractLineTaxAmount_QNAME, AmountType.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShipToAcctId", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineShipToAcctId(Long value) {
        return new JAXBElement<Long>(_ContractLineShipToAcctId_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShipToSiteUseId", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineShipToSiteUseId(Long value) {
        return new JAXBElement<Long>(_ContractLineShipToSiteUseId_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShipInvOrgId", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineShipInvOrgId(Long value) {
        return new JAXBElement<Long>(_ContractLineShipInvOrgId_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TaxExemptionControl", scope = ContractLine.class)
    public JAXBElement<String> createContractLineTaxExemptionControl(String value) {
        return new JAXBElement<String>(_ContractLineTaxExemptionControl_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExemptReasonCode", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExemptReasonCode(String value) {
        return new JAXBElement<String>(_ContractLineExemptReasonCode_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExemptCertificateNumber", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExemptCertificateNumber(String value) {
        return new JAXBElement<String>(_ContractLineExemptCertificateNumber_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OutputTaxClassificationCode", scope = ContractLine.class)
    public JAXBElement<String> createContractLineOutputTaxClassificationCode(String value) {
        return new JAXBElement<String>(_ContractLineOutputTaxClassificationCode_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Comments", scope = ContractLine.class)
    public JAXBElement<String> createContractLineComments(String value) {
        return new JAXBElement<String>(_ContractLineComments_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreedAmount", scope = ContractLine.class)
    public JAXBElement<AmountType> createContractLineAgreedAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractLineAgreedAmount_QNAME, AmountType.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Cognomen", scope = ContractLine.class)
    public JAXBElement<String> createContractLineCognomen(String value) {
        return new JAXBElement<String>(_ContractLineCognomen_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OrigSystemSourceCode", scope = ContractLine.class)
    public JAXBElement<String> createContractLineOrigSystemSourceCode(String value) {
        return new JAXBElement<String>(_ContractLineOrigSystemSourceCode_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OrigSystemReference1", scope = ContractLine.class)
    public JAXBElement<String> createContractLineOrigSystemReference1(String value) {
        return new JAXBElement<String>(_ContractLineOrigSystemReference1_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OrigSystemId1", scope = ContractLine.class)
    public JAXBElement<BigDecimal> createContractLineOrigSystemId1(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractLineOrigSystemId1_QNAME, BigDecimal.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CleId", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineCleId(Long value) {
        return new JAXBElement<Long>(_ContractLineCleId_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "HoldReasonCode", scope = ContractLine.class)
    public JAXBElement<String> createContractLineHoldReasonCode(String value) {
        return new JAXBElement<String>(_ContractLineHoldReasonCode_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "HoldUntilDate", scope = ContractLine.class)
    public JAXBElement<XMLGregorianCalendar> createContractLineHoldUntilDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractLineHoldUntilDate_QNAME, XMLGregorianCalendar.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DeleteFlag", scope = ContractLine.class)
    public JAXBElement<Boolean> createContractLineDeleteFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractLineDeleteFlag_QNAME, Boolean.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CustPoNumber", scope = ContractLine.class)
    public JAXBElement<String> createContractLineCustPoNumber(String value) {
        return new JAXBElement<String>(_ContractLineCustPoNumber_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalItemKey", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalItemKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalItemKey_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalItemReference1", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalItemReference1(String value) {
        return new JAXBElement<String>(_ContractLineExternalItemReference1_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalItemReference2", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalItemReference2(String value) {
        return new JAXBElement<String>(_ContractLineExternalItemReference2_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalItemReference3", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalItemReference3(String value) {
        return new JAXBElement<String>(_ContractLineExternalItemReference3_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalItemReference4", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalItemReference4(String value) {
        return new JAXBElement<String>(_ContractLineExternalItemReference4_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalItemReference5", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalItemReference5(String value) {
        return new JAXBElement<String>(_ContractLineExternalItemReference5_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalItemSource", scope = ContractLine.class)
    public JAXBElement<String> createContractLineExternalItemSource(String value) {
        return new JAXBElement<String>(_ContractLineExternalItemSource_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TrnCode", scope = ContractLine.class)
    public JAXBElement<String> createContractLineTrnCode(String value) {
        return new JAXBElement<String>(_ContractLineTrnCode_QNAME, String.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TrnCodeSetId", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineTrnCodeSetId(Long value) {
        return new JAXBElement<Long>(_ContractLineTrnCodeSetId_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "HoldReasonCodeSetId", scope = ContractLine.class)
    public JAXBElement<Long> createContractLineHoldReasonCodeSetId(Long value) {
        return new JAXBElement<Long>(_ContractLineHoldReasonCodeSetId_QNAME, Long.class, ContractLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "PriceListId", scope = SalesAgreementLineSA.class)
    public JAXBElement<String> createSalesAgreementLineSAPriceListId(String value) {
        return new JAXBElement<String>(_SalesAgreementLineSAPriceListId_QNAME, String.class, SalesAgreementLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AllowPricelistOverrideYn", scope = SalesAgreementLineSA.class)
    public JAXBElement<String> createSalesAgreementLineSAAllowPricelistOverrideYn(String value) {
        return new JAXBElement<String>(_SalesAgreementLineSAAllowPricelistOverrideYn_QNAME, String.class, SalesAgreementLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MeasureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "MinReleaseQuantity", scope = SalesAgreementLineSA.class)
    public JAXBElement<MeasureType> createSalesAgreementLineSAMinReleaseQuantity(MeasureType value) {
        return new JAXBElement<MeasureType>(_SalesAgreementLineSAMinReleaseQuantity_QNAME, MeasureType.class, SalesAgreementLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MeasureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CommittedQuantity", scope = SalesAgreementLineSA.class)
    public JAXBElement<MeasureType> createSalesAgreementLineSACommittedQuantity(MeasureType value) {
        return new JAXBElement<MeasureType>(_SalesAgreementLineSACommittedQuantity_QNAME, MeasureType.class, SalesAgreementLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CommitLevelCode", scope = SalesAgreementLineSA.class)
    public JAXBElement<String> createSalesAgreementLineSACommitLevelCode(String value) {
        return new JAXBElement<String>(_SalesAgreementLineSACommitLevelCode_QNAME, String.class, SalesAgreementLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "LinePurchaseAmount", scope = ContractBuyLine.class)
    public JAXBElement<AmountType> createContractBuyLineLinePurchaseAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractBuyLineLinePurchaseAmount_QNAME, AmountType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "SupplierId", scope = ContractBuyLine.class)
    public JAXBElement<Long> createContractBuyLineSupplierId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineSupplierId_QNAME, Long.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "SupplierSiteId", scope = ContractBuyLine.class)
    public JAXBElement<Long> createContractBuyLineSupplierSiteId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineSupplierSiteId_QNAME, Long.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "RecvInvOrgId", scope = ContractBuyLine.class)
    public JAXBElement<Long> createContractBuyLineRecvInvOrgId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineRecvInvOrgId_QNAME, Long.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DeliveryDate", scope = ContractBuyLine.class)
    public JAXBElement<XMLGregorianCalendar> createContractBuyLineDeliveryDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractBuyLineDeliveryDate_QNAME, XMLGregorianCalendar.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "FobCode", scope = ContractBuyLine.class)
    public JAXBElement<String> createContractBuyLineFobCode(String value) {
        return new JAXBElement<String>(_ContractBuyLineFobCode_QNAME, String.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "FreightTermsCode", scope = ContractBuyLine.class)
    public JAXBElement<String> createContractBuyLineFreightTermsCode(String value) {
        return new JAXBElement<String>(_ContractBuyLineFreightTermsCode_QNAME, String.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "RecvLocationId", scope = ContractBuyLine.class)
    public JAXBElement<Long> createContractBuyLineRecvLocationId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineRecvLocationId_QNAME, Long.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "PurchasingCategoryId", scope = ContractBuyLine.class)
    public JAXBElement<Long> createContractBuyLinePurchasingCategoryId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLinePurchasingCategoryId_QNAME, Long.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "PaymentTermsId", scope = ContractBuyLine.class)
    public JAXBElement<Long> createContractBuyLinePaymentTermsId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLinePaymentTermsId_QNAME, Long.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CarrierId", scope = ContractBuyLine.class)
    public JAXBElement<Long> createContractBuyLineCarrierId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineCarrierId_QNAME, Long.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreementUnitPrice", scope = ContractBuyLine.class)
    public JAXBElement<AmountType> createContractBuyLineAgreementUnitPrice(AmountType value) {
        return new JAXBElement<AmountType>(_ContractBuyLineAgreementUnitPrice_QNAME, AmountType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreementLimitPrice", scope = ContractBuyLine.class)
    public JAXBElement<AmountType> createContractBuyLineAgreementLimitPrice(AmountType value) {
        return new JAXBElement<AmountType>(_ContractBuyLineAgreementLimitPrice_QNAME, AmountType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MeasureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreedQuantity", scope = ContractBuyLine.class)
    public JAXBElement<MeasureType> createContractBuyLineAgreedQuantity(MeasureType value) {
        return new JAXBElement<MeasureType>(_ContractBuyLineAgreedQuantity_QNAME, MeasureType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MeasureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreementLimitQuantity", scope = ContractBuyLine.class)
    public JAXBElement<MeasureType> createContractBuyLineAgreementLimitQuantity(MeasureType value) {
        return new JAXBElement<MeasureType>(_ContractBuyLineAgreementLimitQuantity_QNAME, MeasureType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreementLimitAmount", scope = ContractBuyLine.class)
    public JAXBElement<AmountType> createContractBuyLineAgreementLimitAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractBuyLineAgreementLimitAmount_QNAME, AmountType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MeasureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "MinReleaseQuantity", scope = ContractBuyLine.class)
    public JAXBElement<MeasureType> createContractBuyLineMinReleaseQuantity(MeasureType value) {
        return new JAXBElement<MeasureType>(_SalesAgreementLineSAMinReleaseQuantity_QNAME, MeasureType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "MinReleaseAmount", scope = ContractBuyLine.class)
    public JAXBElement<AmountType> createContractBuyLineMinReleaseAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractBuyLineMinReleaseAmount_QNAME, AmountType.class, ContractBuyLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalSourceKey", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderExternalSourceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalSourceKey_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalReferenceKey", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderExternalReferenceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalReferenceKey_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "EndDate", scope = ContractHeader.class)
    public JAXBElement<XMLGregorianCalendar> createContractHeaderEndDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractLineEndDate_QNAME, XMLGregorianCalendar.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "SalesAcctId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderSalesAcctId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderSalesAcctId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ApTermsId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderApTermsId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderApTermsId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AmendmentEffectiveDate", scope = ContractHeader.class)
    public JAXBElement<XMLGregorianCalendar> createContractHeaderAmendmentEffectiveDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractHeaderAmendmentEffectiveDate_QNAME, XMLGregorianCalendar.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AutoReleaseInvoice", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderAutoReleaseInvoice(String value) {
        return new JAXBElement<String>(_ContractHeaderAutoReleaseInvoice_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "BillSequence", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderBillSequence(Long value) {
        return new JAXBElement<Long>(_ContractHeaderBillSequence_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "BillToAcctId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderBillToAcctId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderBillToAcctId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "BillToSiteUseId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderBillToSiteUseId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderBillToSiteUseId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "BilledAtSource", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderBilledAtSource(String value) {
        return new JAXBElement<String>(_ContractHeaderBilledAtSource_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Cognomen", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderCognomen(String value) {
        return new JAXBElement<String>(_ContractLineCognomen_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ContributionPercent", scope = ContractHeader.class)
    public JAXBElement<BigDecimal> createContractHeaderContributionPercent(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractHeaderContributionPercent_QNAME, BigDecimal.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Description", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderDescription(String value) {
        return new JAXBElement<String>(_ContractLineDescription_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "EstimatedAmount", scope = ContractHeader.class)
    public JAXBElement<AmountType> createContractHeaderEstimatedAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractHeaderEstimatedAmount_QNAME, AmountType.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExemptCertificateNumber", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderExemptCertificateNumber(String value) {
        return new JAXBElement<String>(_ContractLineExemptCertificateNumber_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExemptReasonCode", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderExemptReasonCode(String value) {
        return new JAXBElement<String>(_ContractLineExemptReasonCode_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Fob", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderFob(String value) {
        return new JAXBElement<String>(_ContractHeaderFob_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "FreightTerms", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderFreightTerms(String value) {
        return new JAXBElement<String>(_ContractHeaderFreightTerms_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "InvConvRateDateType", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderInvConvRateDateType(String value) {
        return new JAXBElement<String>(_ContractHeaderInvConvRateDateType_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "InvConvRateDate", scope = ContractHeader.class)
    public JAXBElement<XMLGregorianCalendar> createContractHeaderInvConvRateDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractHeaderInvConvRateDate_QNAME, XMLGregorianCalendar.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "InvConvRateType", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderInvConvRateType(String value) {
        return new JAXBElement<String>(_ContractHeaderInvConvRateType_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "InvTrxTypeId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderInvTrxTypeId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderInvTrxTypeId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "LastRevRecogDate", scope = ContractHeader.class)
    public JAXBElement<XMLGregorianCalendar> createContractHeaderLastRevRecogDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractHeaderLastRevRecogDate_QNAME, XMLGregorianCalendar.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "LegalEntityId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderLegalEntityId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderLegalEntityId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "LineAutonumberEnabledFlag", scope = ContractHeader.class)
    public JAXBElement<Boolean> createContractHeaderLineAutonumberEnabledFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractHeaderLineAutonumberEnabledFlag_QNAME, Boolean.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "NetInvoiceFlag", scope = ContractHeader.class)
    public JAXBElement<Boolean> createContractHeaderNetInvoiceFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractHeaderNetInvoiceFlag_QNAME, Boolean.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OrigSystemId1", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderOrigSystemId1(Long value) {
        return new JAXBElement<Long>(_ContractLineOrigSystemId1_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OrigSystemReference1", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderOrigSystemReference1(String value) {
        return new JAXBElement<String>(_ContractLineOrigSystemReference1_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OrigSystemSourceCode", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderOrigSystemSourceCode(String value) {
        return new JAXBElement<String>(_ContractLineOrigSystemSourceCode_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OutputTaxClassificationCode", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderOutputTaxClassificationCode(String value) {
        return new JAXBElement<String>(_ContractLineOutputTaxClassificationCode_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OverallRiskCode", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderOverallRiskCode(String value) {
        return new JAXBElement<String>(_ContractHeaderOverallRiskCode_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OwningOrgId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderOwningOrgId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderOwningOrgId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShipInvOrgId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderShipInvOrgId(Long value) {
        return new JAXBElement<Long>(_ContractLineShipInvOrgId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShipToAcctId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderShipToAcctId(Long value) {
        return new JAXBElement<Long>(_ContractLineShipToAcctId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShipToSiteUseId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderShipToSiteUseId(Long value) {
        return new JAXBElement<Long>(_ContractLineShipToSiteUseId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShiptoLocationId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderShiptoLocationId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderShiptoLocationId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ShortDescription", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderShortDescription(String value) {
        return new JAXBElement<String>(_ContractHeaderShortDescription_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "SoldToAcctId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderSoldToAcctId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderSoldToAcctId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "SoldToSiteId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderSoldToSiteId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderSoldToSiteId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "SupplierId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderSupplierId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineSupplierId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "SupplierSiteId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderSupplierSiteId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineSupplierSiteId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TaxAmount", scope = ContractHeader.class)
    public JAXBElement<AmountType> createContractHeaderTaxAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractLineTaxAmount_QNAME, AmountType.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TaxExemptionControl", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderTaxExemptionControl(String value) {
        return new JAXBElement<String>(_ContractLineTaxExemptionControl_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "WebServiceFlag", scope = ContractHeader.class, defaultValue = "true")
    public JAXBElement<Boolean> createContractHeaderWebServiceFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractHeaderWebServiceFlag_QNAME, Boolean.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "RecvInvOrgId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderRecvInvOrgId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineRecvInvOrgId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "BilltoLocationId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderBilltoLocationId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderBilltoLocationId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TermsTemplateId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderTermsTemplateId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderTermsTemplateId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ContractOwnerId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderContractOwnerId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderContractOwnerId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "PartyId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderPartyId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderPartyId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreementEnabledFlag", scope = ContractHeader.class)
    public JAXBElement<Boolean> createContractHeaderAgreementEnabledFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractHeaderAgreementEnabledFlag_QNAME, Boolean.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreementAmtLimit", scope = ContractHeader.class)
    public JAXBElement<BigDecimal> createContractHeaderAgreementAmtLimit(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractHeaderAgreementAmtLimit_QNAME, BigDecimal.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AgreedAmount", scope = ContractHeader.class)
    public JAXBElement<AmountType> createContractHeaderAgreedAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractLineAgreedAmount_QNAME, AmountType.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "MinReleaseAmt", scope = ContractHeader.class)
    public JAXBElement<BigDecimal> createContractHeaderMinReleaseAmt(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractHeaderMinReleaseAmt_QNAME, BigDecimal.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "EncumbranceLevel", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderEncumbranceLevel(String value) {
        return new JAXBElement<String>(_ContractHeaderEncumbranceLevel_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CarrierId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderCarrierId(Long value) {
        return new JAXBElement<Long>(_ContractBuyLineCarrierId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "HoldReasonCode", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderHoldReasonCode(String value) {
        return new JAXBElement<String>(_ContractLineHoldReasonCode_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "HoldUntilDate", scope = ContractHeader.class)
    public JAXBElement<XMLGregorianCalendar> createContractHeaderHoldUntilDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractLineHoldUntilDate_QNAME, XMLGregorianCalendar.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CustPoNumber", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderCustPoNumber(String value) {
        return new JAXBElement<String>(_ContractLineCustPoNumber_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "BillingSalesrepId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderBillingSalesrepId(Long value) {
        return new JAXBElement<Long>(_ContractHeaderBillingSalesrepId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "VersionDescription", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderVersionDescription(String value) {
        return new JAXBElement<String>(_ContractHeaderVersionDescription_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "PriceList", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderPriceList(String value) {
        return new JAXBElement<String>(_ContractHeaderPriceList_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DiscountPercent", scope = ContractHeader.class)
    public JAXBElement<BigDecimal> createContractHeaderDiscountPercent(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractHeaderDiscountPercent_QNAME, BigDecimal.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AdjustmentBasis", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderAdjustmentBasis(String value) {
        return new JAXBElement<String>(_ContractHeaderAdjustmentBasis_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CommitmentAmount", scope = ContractHeader.class)
    public JAXBElement<AmountType> createContractHeaderCommitmentAmount(AmountType value) {
        return new JAXBElement<AmountType>(_ContractHeaderCommitmentAmount_QNAME, AmountType.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "HoldReasonCodeSetId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderHoldReasonCodeSetId(Long value) {
        return new JAXBElement<Long>(_ContractLineHoldReasonCodeSetId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TrnCode", scope = ContractHeader.class)
    public JAXBElement<String> createContractHeaderTrnCode(String value) {
        return new JAXBElement<String>(_ContractLineTrnCode_QNAME, String.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "TrnCodeSetId", scope = ContractHeader.class)
    public JAXBElement<Long> createContractHeaderTrnCodeSetId(Long value) {
        return new JAXBElement<Long>(_ContractLineTrnCodeSetId_QNAME, Long.class, ContractHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalSourceKey", scope = ContractRelatedDocument.class)
    public JAXBElement<String> createContractRelatedDocumentExternalSourceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalSourceKey_QNAME, String.class, ContractRelatedDocument.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalReferenceKey", scope = ContractRelatedDocument.class)
    public JAXBElement<String> createContractRelatedDocumentExternalReferenceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalReferenceKey_QNAME, String.class, ContractRelatedDocument.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Object1Id1", scope = ContractRelatedDocument.class)
    public JAXBElement<Long> createContractRelatedDocumentObject1Id1(Long value) {
        return new JAXBElement<Long>(_ContractLineObject1Id1_QNAME, Long.class, ContractRelatedDocument.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DeleteFlag", scope = ContractRelatedDocument.class)
    public JAXBElement<Boolean> createContractRelatedDocumentDeleteFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractLineDeleteFlag_QNAME, Boolean.class, ContractRelatedDocument.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "LineValue", scope = ContractProjectLine.class)
    public JAXBElement<BigDecimal> createContractProjectLineLineValue(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractProjectLineLineValue_QNAME, BigDecimal.class, ContractProjectLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "BillPlanId", scope = ContractProjectLine.class)
    public JAXBElement<Long> createContractProjectLineBillPlanId(Long value) {
        return new JAXBElement<Long>(_ContractProjectLineBillPlanId_QNAME, Long.class, ContractProjectLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "RevenuePlanId", scope = ContractProjectLine.class)
    public JAXBElement<Long> createContractProjectLineRevenuePlanId(Long value) {
        return new JAXBElement<Long>(_ContractProjectLineRevenuePlanId_QNAME, Long.class, ContractProjectLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "LastRevRecogDate", scope = ContractProjectLine.class)
    public JAXBElement<XMLGregorianCalendar> createContractProjectLineLastRevRecogDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractHeaderLastRevRecogDate_QNAME, XMLGregorianCalendar.class, ContractProjectLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "PercentComplete", scope = ContractProjectLine.class)
    public JAXBElement<BigDecimal> createContractProjectLinePercentComplete(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_ContractProjectLinePercentComplete_QNAME, BigDecimal.class, ContractProjectLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "RevenueImpactDate", scope = ContractProjectLine.class)
    public JAXBElement<XMLGregorianCalendar> createContractProjectLineRevenueImpactDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractProjectLineRevenueImpactDate_QNAME, XMLGregorianCalendar.class, ContractProjectLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalSourceKey", scope = ContractParty.class)
    public JAXBElement<String> createContractPartyExternalSourceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalSourceKey_QNAME, String.class, ContractParty.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalReferenceKey", scope = ContractParty.class)
    public JAXBElement<String> createContractPartyExternalReferenceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalReferenceKey_QNAME, String.class, ContractParty.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "JtotObject1Code", scope = ContractParty.class)
    public JAXBElement<String> createContractPartyJtotObject1Code(String value) {
        return new JAXBElement<String>(_ContractLineJtotObject1Code_QNAME, String.class, ContractParty.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DeleteFlag", scope = ContractParty.class)
    public JAXBElement<Boolean> createContractPartyDeleteFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractLineDeleteFlag_QNAME, Boolean.class, ContractParty.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalSourceKey", scope = ContractPartyContact.class)
    public JAXBElement<String> createContractPartyContactExternalSourceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalSourceKey_QNAME, String.class, ContractPartyContact.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalReferenceKey", scope = ContractPartyContact.class)
    public JAXBElement<String> createContractPartyContactExternalReferenceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalReferenceKey_QNAME, String.class, ContractPartyContact.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Object1Id2", scope = ContractPartyContact.class)
    public JAXBElement<Long> createContractPartyContactObject1Id2(Long value) {
        return new JAXBElement<Long>(_ContractLineObject1Id2_QNAME, Long.class, ContractPartyContact.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "OwnerYn", scope = ContractPartyContact.class)
    public JAXBElement<String> createContractPartyContactOwnerYn(String value) {
        return new JAXBElement<String>(_ContractPartyContactOwnerYn_QNAME, String.class, ContractPartyContact.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DeleteFlag", scope = ContractPartyContact.class)
    public JAXBElement<Boolean> createContractPartyContactDeleteFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractLineDeleteFlag_QNAME, Boolean.class, ContractPartyContact.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AccessLevel", scope = ContractPartyContact.class)
    public JAXBElement<String> createContractPartyContactAccessLevel(String value) {
        return new JAXBElement<String>(_ContractPartyContactAccessLevel_QNAME, String.class, ContractPartyContact.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Adjustment", scope = PricingTermSA.class)
    public JAXBElement<BigDecimal> createPricingTermSAAdjustment(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_PricingTermSAAdjustment_QNAME, BigDecimal.class, PricingTermSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "AdjustmentBasisCode", scope = PricingTermSA.class)
    public JAXBElement<String> createPricingTermSAAdjustmentBasisCode(String value) {
        return new JAXBElement<String>(_PricingTermSAAdjustmentBasisCode_QNAME, String.class, PricingTermSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "CleId", scope = PricingTermSA.class)
    public JAXBElement<Long> createPricingTermSACleId(Long value) {
        return new JAXBElement<Long>(_ContractLineCleId_QNAME, Long.class, PricingTermSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "EndDate", scope = PricingTermSA.class)
    public JAXBElement<XMLGregorianCalendar> createPricingTermSAEndDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ContractLineEndDate_QNAME, XMLGregorianCalendar.class, PricingTermSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ListPrice", scope = PricingTermSA.class)
    public JAXBElement<AmountType> createPricingTermSAListPrice(AmountType value) {
        return new JAXBElement<AmountType>(_PricingTermSAListPrice_QNAME, AmountType.class, PricingTermSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DeleteFlag", scope = TierLineSA.class)
    public JAXBElement<Boolean> createTierLineSADeleteFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractLineDeleteFlag_QNAME, Boolean.class, TierLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "MaximumValue", scope = TierLineSA.class)
    public JAXBElement<BigDecimal> createTierLineSAMaximumValue(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_TierLineSAMaximumValue_QNAME, BigDecimal.class, TierLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "Adjustment", scope = TierLineSA.class)
    public JAXBElement<BigDecimal> createTierLineSAAdjustment(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_PricingTermSAAdjustment_QNAME, BigDecimal.class, TierLineSA.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalSourceKey", scope = ContractPartyAddress.class)
    public JAXBElement<String> createContractPartyAddressExternalSourceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalSourceKey_QNAME, String.class, ContractPartyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "ExternalReferenceKey", scope = ContractPartyAddress.class)
    public JAXBElement<String> createContractPartyAddressExternalReferenceKey(String value) {
        return new JAXBElement<String>(_ContractLineExternalReferenceKey_QNAME, String.class, ContractPartyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", name = "DeleteFlag", scope = ContractPartyAddress.class)
    public JAXBElement<Boolean> createContractPartyAddressDeleteFlag(Boolean value) {
        return new JAXBElement<Boolean>(_ContractLineDeleteFlag_QNAME, Boolean.class, ContractPartyAddress.class, value);
    }

}
