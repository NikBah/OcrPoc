
package com.oracle.xmlns.apps.projects.billing.contracts.contractservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.adf.svc.types.AmountType;


/**
 * <p>Java class for AssignmentDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AssignmentDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AssignmentDetailId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MajorVersion" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ExtensionAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="CurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Percentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="CalculationLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ActiveFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="ExternalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssignmentDetail", propOrder = {
    "assignmentDetailId",
    "majorVersion",
    "extensionAmount",
    "currencyCode",
    "percentage",
    "calculationLevelCode",
    "activeFlag",
    "externalSourceKey",
    "externalReferenceKey"
})
public class AssignmentDetail {

    @XmlElement(name = "AssignmentDetailId")
    protected Long assignmentDetailId;
    @XmlElement(name = "MajorVersion")
    protected Long majorVersion;
    @XmlElementRef(name = "ExtensionAmount", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> extensionAmount;
    @XmlElementRef(name = "CurrencyCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> currencyCode;
    @XmlElementRef(name = "Percentage", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> percentage;
    @XmlElement(name = "CalculationLevelCode")
    protected String calculationLevelCode;
    @XmlElement(name = "ActiveFlag")
    protected Boolean activeFlag;
    @XmlElementRef(name = "ExternalSourceKey", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalSourceKey;
    @XmlElementRef(name = "ExternalReferenceKey", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalReferenceKey;

    /**
     * Gets the value of the assignmentDetailId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAssignmentDetailId() {
        return assignmentDetailId;
    }

    /**
     * Sets the value of the assignmentDetailId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAssignmentDetailId(Long value) {
        this.assignmentDetailId = value;
    }

    /**
     * Gets the value of the majorVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMajorVersion() {
        return majorVersion;
    }

    /**
     * Sets the value of the majorVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMajorVersion(Long value) {
        this.majorVersion = value;
    }

    /**
     * Gets the value of the extensionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getExtensionAmount() {
        return extensionAmount;
    }

    /**
     * Sets the value of the extensionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setExtensionAmount(JAXBElement<AmountType> value) {
        this.extensionAmount = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCurrencyCode(JAXBElement<String> value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the percentage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getPercentage() {
        return percentage;
    }

    /**
     * Sets the value of the percentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setPercentage(JAXBElement<BigDecimal> value) {
        this.percentage = value;
    }

    /**
     * Gets the value of the calculationLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalculationLevelCode() {
        return calculationLevelCode;
    }

    /**
     * Sets the value of the calculationLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalculationLevelCode(String value) {
        this.calculationLevelCode = value;
    }

    /**
     * Gets the value of the activeFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isActiveFlag() {
        return activeFlag;
    }

    /**
     * Sets the value of the activeFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setActiveFlag(Boolean value) {
        this.activeFlag = value;
    }

    /**
     * Gets the value of the externalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalSourceKey() {
        return externalSourceKey;
    }

    /**
     * Sets the value of the externalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalSourceKey(JAXBElement<String> value) {
        this.externalSourceKey = value;
    }

    /**
     * Gets the value of the externalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalReferenceKey() {
        return externalReferenceKey;
    }

    /**
     * Sets the value of the externalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalReferenceKey(JAXBElement<String> value) {
        this.externalReferenceKey = value;
    }

}
