
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="contractId" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="closedDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date"/&gt;
 *         &lt;element name="reasonCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="externalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="externalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="trnCodeSetId" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "contractId",
    "closedDate",
    "reasonCode",
    "externalSourceKey",
    "externalReferenceKey",
    "trnCodeSetId"
})
@XmlRootElement(name = "closeContractUsingSetId")
public class CloseContractUsingSetId {

    protected long contractId;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar closedDate;
    @XmlElement(required = true)
    protected String reasonCode;
    @XmlElement(required = true)
    protected String externalSourceKey;
    @XmlElement(required = true)
    protected String externalReferenceKey;
    protected long trnCodeSetId;

    /**
     * Gets the value of the contractId property.
     * 
     */
    public long getContractId() {
        return contractId;
    }

    /**
     * Sets the value of the contractId property.
     * 
     */
    public void setContractId(long value) {
        this.contractId = value;
    }

    /**
     * Gets the value of the closedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClosedDate() {
        return closedDate;
    }

    /**
     * Sets the value of the closedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClosedDate(XMLGregorianCalendar value) {
        this.closedDate = value;
    }

    /**
     * Gets the value of the reasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Sets the value of the reasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCode(String value) {
        this.reasonCode = value;
    }

    /**
     * Gets the value of the externalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalSourceKey() {
        return externalSourceKey;
    }

    /**
     * Sets the value of the externalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalSourceKey(String value) {
        this.externalSourceKey = value;
    }

    /**
     * Gets the value of the externalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalReferenceKey() {
        return externalReferenceKey;
    }

    /**
     * Sets the value of the externalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalReferenceKey(String value) {
        this.externalReferenceKey = value;
    }

    /**
     * Gets the value of the trnCodeSetId property.
     * 
     */
    public long getTrnCodeSetId() {
        return trnCodeSetId;
    }

    /**
     * Sets the value of the trnCodeSetId property.
     * 
     */
    public void setTrnCodeSetId(long value) {
        this.trnCodeSetId = value;
    }

}
