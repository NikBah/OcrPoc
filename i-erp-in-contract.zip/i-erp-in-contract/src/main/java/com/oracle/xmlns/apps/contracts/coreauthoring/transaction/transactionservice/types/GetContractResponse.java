
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractHeader;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="result" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractHeader"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "result"
})
@XmlRootElement(name = "getContractResponse")
public class GetContractResponse {

    @XmlElement(required = true)
    protected ContractHeader result;

    /**
     * Gets the value of the result property.
     * 
     * @return
     *     possible object is
     *     {@link ContractHeader }
     *     
     */
    public ContractHeader getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContractHeader }
     *     
     */
    public void setResult(ContractHeader value) {
        this.result = value;
    }

}
