@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.apps.projects.billing.contracts.contractservice;
