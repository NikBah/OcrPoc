
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetContract }
     * 
     */
    public GetContract createGetContract() {
        return new GetContract();
    }

    /**
     * Create an instance of {@link GetContractResponse }
     * 
     */
    public GetContractResponse createGetContractResponse() {
        return new GetContractResponse();
    }

    /**
     * Create an instance of {@link CreateContract }
     * 
     */
    public CreateContract createCreateContract() {
        return new CreateContract();
    }

    /**
     * Create an instance of {@link CreateContractResponse }
     * 
     */
    public CreateContractResponse createCreateContractResponse() {
        return new CreateContractResponse();
    }

    /**
     * Create an instance of {@link UpdateContract }
     * 
     */
    public UpdateContract createUpdateContract() {
        return new UpdateContract();
    }

    /**
     * Create an instance of {@link UpdateContractResponse }
     * 
     */
    public UpdateContractResponse createUpdateContractResponse() {
        return new UpdateContractResponse();
    }

    /**
     * Create an instance of {@link MergeContract }
     * 
     */
    public MergeContract createMergeContract() {
        return new MergeContract();
    }

    /**
     * Create an instance of {@link MergeContractResponse }
     * 
     */
    public MergeContractResponse createMergeContractResponse() {
        return new MergeContractResponse();
    }

    /**
     * Create an instance of {@link FindContract }
     * 
     */
    public FindContract createFindContract() {
        return new FindContract();
    }

    /**
     * Create an instance of {@link FindContractResponse }
     * 
     */
    public FindContractResponse createFindContractResponse() {
        return new FindContractResponse();
    }

    /**
     * Create an instance of {@link UpdateContractAsync }
     * 
     */
    public UpdateContractAsync createUpdateContractAsync() {
        return new UpdateContractAsync();
    }

    /**
     * Create an instance of {@link UpdateContractAsyncResponse }
     * 
     */
    public UpdateContractAsyncResponse createUpdateContractAsyncResponse() {
        return new UpdateContractAsyncResponse();
    }

    /**
     * Create an instance of {@link GetContractAsync }
     * 
     */
    public GetContractAsync createGetContractAsync() {
        return new GetContractAsync();
    }

    /**
     * Create an instance of {@link GetContractAsyncResponse }
     * 
     */
    public GetContractAsyncResponse createGetContractAsyncResponse() {
        return new GetContractAsyncResponse();
    }

    /**
     * Create an instance of {@link MergeContractAsync }
     * 
     */
    public MergeContractAsync createMergeContractAsync() {
        return new MergeContractAsync();
    }

    /**
     * Create an instance of {@link MergeContractAsyncResponse }
     * 
     */
    public MergeContractAsyncResponse createMergeContractAsyncResponse() {
        return new MergeContractAsyncResponse();
    }

    /**
     * Create an instance of {@link FindContractAsync }
     * 
     */
    public FindContractAsync createFindContractAsync() {
        return new FindContractAsync();
    }

    /**
     * Create an instance of {@link FindContractAsyncResponse }
     * 
     */
    public FindContractAsyncResponse createFindContractAsyncResponse() {
        return new FindContractAsyncResponse();
    }

    /**
     * Create an instance of {@link CreateContractAsync }
     * 
     */
    public CreateContractAsync createCreateContractAsync() {
        return new CreateContractAsync();
    }

    /**
     * Create an instance of {@link CreateContractAsyncResponse }
     * 
     */
    public CreateContractAsyncResponse createCreateContractAsyncResponse() {
        return new CreateContractAsyncResponse();
    }

    /**
     * Create an instance of {@link MergeContractInAllStatus }
     * 
     */
    public MergeContractInAllStatus createMergeContractInAllStatus() {
        return new MergeContractInAllStatus();
    }

    /**
     * Create an instance of {@link MergeContractInAllStatusResponse }
     * 
     */
    public MergeContractInAllStatusResponse createMergeContractInAllStatusResponse() {
        return new MergeContractInAllStatusResponse();
    }

    /**
     * Create an instance of {@link MergeContractInAllStatusAsync }
     * 
     */
    public MergeContractInAllStatusAsync createMergeContractInAllStatusAsync() {
        return new MergeContractInAllStatusAsync();
    }

    /**
     * Create an instance of {@link MergeContractInAllStatusAsyncResponse }
     * 
     */
    public MergeContractInAllStatusAsyncResponse createMergeContractInAllStatusAsyncResponse() {
        return new MergeContractInAllStatusAsyncResponse();
    }

    /**
     * Create an instance of {@link DeleteContract }
     * 
     */
    public DeleteContract createDeleteContract() {
        return new DeleteContract();
    }

    /**
     * Create an instance of {@link DeleteContractResponse }
     * 
     */
    public DeleteContractResponse createDeleteContractResponse() {
        return new DeleteContractResponse();
    }

    /**
     * Create an instance of {@link RemoveHoldOnContract }
     * 
     */
    public RemoveHoldOnContract createRemoveHoldOnContract() {
        return new RemoveHoldOnContract();
    }

    /**
     * Create an instance of {@link RemoveHoldOnContractResponse }
     * 
     */
    public RemoveHoldOnContractResponse createRemoveHoldOnContractResponse() {
        return new RemoveHoldOnContractResponse();
    }

    /**
     * Create an instance of {@link ReopenContract }
     * 
     */
    public ReopenContract createReopenContract() {
        return new ReopenContract();
    }

    /**
     * Create an instance of {@link ReopenContractResponse }
     * 
     */
    public ReopenContractResponse createReopenContractResponse() {
        return new ReopenContractResponse();
    }

    /**
     * Create an instance of {@link ReopenContractLine }
     * 
     */
    public ReopenContractLine createReopenContractLine() {
        return new ReopenContractLine();
    }

    /**
     * Create an instance of {@link ReopenContractLineResponse }
     * 
     */
    public ReopenContractLineResponse createReopenContractLineResponse() {
        return new ReopenContractLineResponse();
    }

    /**
     * Create an instance of {@link ApplyHoldOnContractUsingSetId }
     * 
     */
    public ApplyHoldOnContractUsingSetId createApplyHoldOnContractUsingSetId() {
        return new ApplyHoldOnContractUsingSetId();
    }

    /**
     * Create an instance of {@link ApplyHoldOnContractUsingSetIdResponse }
     * 
     */
    public ApplyHoldOnContractUsingSetIdResponse createApplyHoldOnContractUsingSetIdResponse() {
        return new ApplyHoldOnContractUsingSetIdResponse();
    }

    /**
     * Create an instance of {@link CloseContractLineUsingSetId }
     * 
     */
    public CloseContractLineUsingSetId createCloseContractLineUsingSetId() {
        return new CloseContractLineUsingSetId();
    }

    /**
     * Create an instance of {@link CloseContractLineUsingSetIdResponse }
     * 
     */
    public CloseContractLineUsingSetIdResponse createCloseContractLineUsingSetIdResponse() {
        return new CloseContractLineUsingSetIdResponse();
    }

    /**
     * Create an instance of {@link CloseContractUsingSetId }
     * 
     */
    public CloseContractUsingSetId createCloseContractUsingSetId() {
        return new CloseContractUsingSetId();
    }

    /**
     * Create an instance of {@link CloseContractUsingSetIdResponse }
     * 
     */
    public CloseContractUsingSetIdResponse createCloseContractUsingSetIdResponse() {
        return new CloseContractUsingSetIdResponse();
    }

    /**
     * Create an instance of {@link RemoveHoldOnContractAsync }
     * 
     */
    public RemoveHoldOnContractAsync createRemoveHoldOnContractAsync() {
        return new RemoveHoldOnContractAsync();
    }

    /**
     * Create an instance of {@link RemoveHoldOnContractAsyncResponse }
     * 
     */
    public RemoveHoldOnContractAsyncResponse createRemoveHoldOnContractAsyncResponse() {
        return new RemoveHoldOnContractAsyncResponse();
    }

    /**
     * Create an instance of {@link ApplyHoldOnContractUsingSetIdAsync }
     * 
     */
    public ApplyHoldOnContractUsingSetIdAsync createApplyHoldOnContractUsingSetIdAsync() {
        return new ApplyHoldOnContractUsingSetIdAsync();
    }

    /**
     * Create an instance of {@link ApplyHoldOnContractUsingSetIdAsyncResponse }
     * 
     */
    public ApplyHoldOnContractUsingSetIdAsyncResponse createApplyHoldOnContractUsingSetIdAsyncResponse() {
        return new ApplyHoldOnContractUsingSetIdAsyncResponse();
    }

    /**
     * Create an instance of {@link DeleteContractAsync }
     * 
     */
    public DeleteContractAsync createDeleteContractAsync() {
        return new DeleteContractAsync();
    }

    /**
     * Create an instance of {@link DeleteContractAsyncResponse }
     * 
     */
    public DeleteContractAsyncResponse createDeleteContractAsyncResponse() {
        return new DeleteContractAsyncResponse();
    }

    /**
     * Create an instance of {@link CloseContractLineUsingSetIdAsync }
     * 
     */
    public CloseContractLineUsingSetIdAsync createCloseContractLineUsingSetIdAsync() {
        return new CloseContractLineUsingSetIdAsync();
    }

    /**
     * Create an instance of {@link CloseContractLineUsingSetIdAsyncResponse }
     * 
     */
    public CloseContractLineUsingSetIdAsyncResponse createCloseContractLineUsingSetIdAsyncResponse() {
        return new CloseContractLineUsingSetIdAsyncResponse();
    }

    /**
     * Create an instance of {@link CloseContractUsingSetIdAsync }
     * 
     */
    public CloseContractUsingSetIdAsync createCloseContractUsingSetIdAsync() {
        return new CloseContractUsingSetIdAsync();
    }

    /**
     * Create an instance of {@link CloseContractUsingSetIdAsyncResponse }
     * 
     */
    public CloseContractUsingSetIdAsyncResponse createCloseContractUsingSetIdAsyncResponse() {
        return new CloseContractUsingSetIdAsyncResponse();
    }

    /**
     * Create an instance of {@link ReopenContractLineAsync }
     * 
     */
    public ReopenContractLineAsync createReopenContractLineAsync() {
        return new ReopenContractLineAsync();
    }

    /**
     * Create an instance of {@link ReopenContractLineAsyncResponse }
     * 
     */
    public ReopenContractLineAsyncResponse createReopenContractLineAsyncResponse() {
        return new ReopenContractLineAsyncResponse();
    }

    /**
     * Create an instance of {@link ReopenContractAsync }
     * 
     */
    public ReopenContractAsync createReopenContractAsync() {
        return new ReopenContractAsync();
    }

    /**
     * Create an instance of {@link ReopenContractAsyncResponse }
     * 
     */
    public ReopenContractAsyncResponse createReopenContractAsyncResponse() {
        return new ReopenContractAsyncResponse();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHints }
     * 
     */
    public GetDfltObjAttrHints createGetDfltObjAttrHints() {
        return new GetDfltObjAttrHints();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHintsResponse }
     * 
     */
    public GetDfltObjAttrHintsResponse createGetDfltObjAttrHintsResponse() {
        return new GetDfltObjAttrHintsResponse();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTime }
     * 
     */
    public GetServiceLastUpdateTime createGetServiceLastUpdateTime() {
        return new GetServiceLastUpdateTime();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTimeResponse }
     * 
     */
    public GetServiceLastUpdateTimeResponse createGetServiceLastUpdateTimeResponse() {
        return new GetServiceLastUpdateTimeResponse();
    }

    /**
     * Create an instance of {@link GetEntityList }
     * 
     */
    public GetEntityList createGetEntityList() {
        return new GetEntityList();
    }

    /**
     * Create an instance of {@link GetEntityListResponse }
     * 
     */
    public GetEntityListResponse createGetEntityListResponse() {
        return new GetEntityListResponse();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHintsAsync }
     * 
     */
    public GetDfltObjAttrHintsAsync createGetDfltObjAttrHintsAsync() {
        return new GetDfltObjAttrHintsAsync();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHintsAsyncResponse }
     * 
     */
    public GetDfltObjAttrHintsAsyncResponse createGetDfltObjAttrHintsAsyncResponse() {
        return new GetDfltObjAttrHintsAsyncResponse();
    }

    /**
     * Create an instance of {@link GetEntityListAsync }
     * 
     */
    public GetEntityListAsync createGetEntityListAsync() {
        return new GetEntityListAsync();
    }

    /**
     * Create an instance of {@link GetEntityListAsyncResponse }
     * 
     */
    public GetEntityListAsyncResponse createGetEntityListAsyncResponse() {
        return new GetEntityListAsyncResponse();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTimeAsync }
     * 
     */
    public GetServiceLastUpdateTimeAsync createGetServiceLastUpdateTimeAsync() {
        return new GetServiceLastUpdateTimeAsync();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTimeAsyncResponse }
     * 
     */
    public GetServiceLastUpdateTimeAsyncResponse createGetServiceLastUpdateTimeAsyncResponse() {
        return new GetServiceLastUpdateTimeAsyncResponse();
    }

    /**
     * Create an instance of {@link CancelContractUsingSetId }
     * 
     */
    public CancelContractUsingSetId createCancelContractUsingSetId() {
        return new CancelContractUsingSetId();
    }

    /**
     * Create an instance of {@link CancelContractUsingSetIdResponse }
     * 
     */
    public CancelContractUsingSetIdResponse createCancelContractUsingSetIdResponse() {
        return new CancelContractUsingSetIdResponse();
    }

    /**
     * Create an instance of {@link CancelContractUsingSetIdAsync }
     * 
     */
    public CancelContractUsingSetIdAsync createCancelContractUsingSetIdAsync() {
        return new CancelContractUsingSetIdAsync();
    }

    /**
     * Create an instance of {@link CancelContractUsingSetIdAsyncResponse }
     * 
     */
    public CancelContractUsingSetIdAsyncResponse createCancelContractUsingSetIdAsyncResponse() {
        return new CancelContractUsingSetIdAsyncResponse();
    }

    /**
     * Create an instance of {@link UpdateContractToActive }
     * 
     */
    public UpdateContractToActive createUpdateContractToActive() {
        return new UpdateContractToActive();
    }

    /**
     * Create an instance of {@link UpdateContractToActiveResponse }
     * 
     */
    public UpdateContractToActiveResponse createUpdateContractToActiveResponse() {
        return new UpdateContractToActiveResponse();
    }

    /**
     * Create an instance of {@link UpdateContractToActiveAsync }
     * 
     */
    public UpdateContractToActiveAsync createUpdateContractToActiveAsync() {
        return new UpdateContractToActiveAsync();
    }

    /**
     * Create an instance of {@link UpdateContractToActiveAsyncResponse }
     * 
     */
    public UpdateContractToActiveAsyncResponse createUpdateContractToActiveAsyncResponse() {
        return new UpdateContractToActiveAsyncResponse();
    }

}
