@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/flex/BilllPlanDff/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.apps.projects.billing.contracts.flex.billlplandff;
