
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.AssociatedProject;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.BillingControl;


/**
 * <p>Java class for ContractProjectLine complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContractProjectLine"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractLine"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LineValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="BillPlanId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="RevenuePlanId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LastRevRecogDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="PercentComplete" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="AtRiskYn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AssociatedProject" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}AssociatedProject" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LineBillingControl" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}BillingControl" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RevenueImpactDate" type="{http://xmlns.oracle.com/adf/svc/types/}dateTime-Timestamp" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContractProjectLine", propOrder = {
    "lineValue",
    "billPlanId",
    "revenuePlanId",
    "lastRevRecogDate",
    "percentComplete",
    "atRiskYn",
    "associatedProject",
    "lineBillingControl",
    "revenueImpactDate"
})
public class ContractProjectLine
    extends ContractLine
{

    @XmlElementRef(name = "LineValue", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> lineValue;
    @XmlElementRef(name = "BillPlanId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPlanId;
    @XmlElementRef(name = "RevenuePlanId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> revenuePlanId;
    @XmlElementRef(name = "LastRevRecogDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> lastRevRecogDate;
    @XmlElementRef(name = "PercentComplete", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> percentComplete;
    @XmlElement(name = "AtRiskYn")
    protected String atRiskYn;
    @XmlElement(name = "AssociatedProject")
    protected List<AssociatedProject> associatedProject;
    @XmlElement(name = "LineBillingControl")
    protected List<BillingControl> lineBillingControl;
    @XmlElementRef(name = "RevenueImpactDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> revenueImpactDate;

    /**
     * Gets the value of the lineValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getLineValue() {
        return lineValue;
    }

    /**
     * Sets the value of the lineValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setLineValue(JAXBElement<BigDecimal> value) {
        this.lineValue = value;
    }

    /**
     * Gets the value of the billPlanId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPlanId() {
        return billPlanId;
    }

    /**
     * Sets the value of the billPlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPlanId(JAXBElement<Long> value) {
        this.billPlanId = value;
    }

    /**
     * Gets the value of the revenuePlanId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRevenuePlanId() {
        return revenuePlanId;
    }

    /**
     * Sets the value of the revenuePlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRevenuePlanId(JAXBElement<Long> value) {
        this.revenuePlanId = value;
    }

    /**
     * Gets the value of the lastRevRecogDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLastRevRecogDate() {
        return lastRevRecogDate;
    }

    /**
     * Sets the value of the lastRevRecogDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLastRevRecogDate(JAXBElement<XMLGregorianCalendar> value) {
        this.lastRevRecogDate = value;
    }

    /**
     * Gets the value of the percentComplete property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getPercentComplete() {
        return percentComplete;
    }

    /**
     * Sets the value of the percentComplete property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setPercentComplete(JAXBElement<BigDecimal> value) {
        this.percentComplete = value;
    }

    /**
     * Gets the value of the atRiskYn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAtRiskYn() {
        return atRiskYn;
    }

    /**
     * Sets the value of the atRiskYn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAtRiskYn(String value) {
        this.atRiskYn = value;
    }

    /**
     * Gets the value of the associatedProject property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the associatedProject property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssociatedProject().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssociatedProject }
     * 
     * 
     */
    public List<AssociatedProject> getAssociatedProject() {
        if (associatedProject == null) {
            associatedProject = new ArrayList<AssociatedProject>();
        }
        return this.associatedProject;
    }

    /**
     * Gets the value of the lineBillingControl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lineBillingControl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLineBillingControl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BillingControl }
     * 
     * 
     */
    public List<BillingControl> getLineBillingControl() {
        if (lineBillingControl == null) {
            lineBillingControl = new ArrayList<BillingControl>();
        }
        return this.lineBillingControl;
    }

    /**
     * Gets the value of the revenueImpactDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getRevenueImpactDate() {
        return revenueImpactDate;
    }

    /**
     * Sets the value of the revenueImpactDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setRevenueImpactDate(JAXBElement<XMLGregorianCalendar> value) {
        this.revenueImpactDate = value;
    }

}
