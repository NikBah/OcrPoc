
package com.oracle.xmlns.apps.contracts.coreauthoring.header.flex.header;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.contracts.coreauthoring.header.flex.header package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ContractHeaderFlexfield_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", "contractHeaderFlexfield");
    private final static QName _ContractHeaderFlexfieldFLEXContext_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", "__FLEX_Context");
    private final static QName _ContractHeaderFlexfieldFLEXContextDisplayValue_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", "__FLEX_Context_DisplayValue");
    private final static QName _ContractHeaderFlexfieldFLEXNumOfSegments_QNAME = new QName("http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", "_FLEX_NumOfSegments");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.contracts.coreauthoring.header.flex.header
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ContractHeaderFlexfield }
     * 
     */
    public ContractHeaderFlexfield createContractHeaderFlexfield() {
        return new ContractHeaderFlexfield();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContractHeaderFlexfield }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", name = "contractHeaderFlexfield")
    public JAXBElement<ContractHeaderFlexfield> createContractHeaderFlexfield(ContractHeaderFlexfield value) {
        return new JAXBElement<ContractHeaderFlexfield>(_ContractHeaderFlexfield_QNAME, ContractHeaderFlexfield.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", name = "__FLEX_Context", scope = ContractHeaderFlexfield.class)
    public JAXBElement<String> createContractHeaderFlexfieldFLEXContext(String value) {
        return new JAXBElement<String>(_ContractHeaderFlexfieldFLEXContext_QNAME, String.class, ContractHeaderFlexfield.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", name = "__FLEX_Context_DisplayValue", scope = ContractHeaderFlexfield.class)
    public JAXBElement<String> createContractHeaderFlexfieldFLEXContextDisplayValue(String value) {
        return new JAXBElement<String>(_ContractHeaderFlexfieldFLEXContextDisplayValue_QNAME, String.class, ContractHeaderFlexfield.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", name = "_FLEX_NumOfSegments", scope = ContractHeaderFlexfield.class)
    public JAXBElement<Integer> createContractHeaderFlexfieldFLEXNumOfSegments(Integer value) {
        return new JAXBElement<Integer>(_ContractHeaderFlexfieldFLEXNumOfSegments_QNAME, Integer.class, ContractHeaderFlexfield.class, value);
    }

}
