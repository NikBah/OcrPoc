
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.oracle.xmlns.adf.svc.types.AmountType;
import com.oracle.xmlns.adf.svc.types.MeasureType;


/**
 * <p>Java class for ContractBuyLine complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContractBuyLine"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractLine"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FixedPriceServiceYn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LinePurchaseAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="SupplierId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="SupplierSiteId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="RecvInvOrgId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="DeliveryDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="FobCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FreightTermsCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RecvLocationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="PurchasingCategoryId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="PaymentTermsId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="CarrierId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="AgreementUnitPrice" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="AgreementPriceOverAllwdYn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AgreementLimitPrice" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="AgreedQuantity" type="{http://xmlns.oracle.com/adf/svc/types/}MeasureType" minOccurs="0"/&gt;
 *         &lt;element name="AgreementLimitQuantity" type="{http://xmlns.oracle.com/adf/svc/types/}MeasureType" minOccurs="0"/&gt;
 *         &lt;element name="AgreementLimitAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="MinReleaseQuantity" type="{http://xmlns.oracle.com/adf/svc/types/}MeasureType" minOccurs="0"/&gt;
 *         &lt;element name="MinReleaseAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContractBuyLine", propOrder = {
    "fixedPriceServiceYn",
    "linePurchaseAmount",
    "supplierId",
    "supplierSiteId",
    "recvInvOrgId",
    "deliveryDate",
    "fobCode",
    "freightTermsCode",
    "recvLocationId",
    "purchasingCategoryId",
    "paymentTermsId",
    "carrierId",
    "agreementUnitPrice",
    "agreementPriceOverAllwdYn",
    "agreementLimitPrice",
    "agreedQuantity",
    "agreementLimitQuantity",
    "agreementLimitAmount",
    "minReleaseQuantity",
    "minReleaseAmount"
})
public class ContractBuyLine
    extends ContractLine
{

    @XmlElement(name = "FixedPriceServiceYn")
    protected String fixedPriceServiceYn;
    @XmlElementRef(name = "LinePurchaseAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> linePurchaseAmount;
    @XmlElementRef(name = "SupplierId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> supplierId;
    @XmlElementRef(name = "SupplierSiteId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> supplierSiteId;
    @XmlElementRef(name = "RecvInvOrgId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> recvInvOrgId;
    @XmlElementRef(name = "DeliveryDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> deliveryDate;
    @XmlElementRef(name = "FobCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> fobCode;
    @XmlElementRef(name = "FreightTermsCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> freightTermsCode;
    @XmlElementRef(name = "RecvLocationId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> recvLocationId;
    @XmlElementRef(name = "PurchasingCategoryId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> purchasingCategoryId;
    @XmlElementRef(name = "PaymentTermsId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymentTermsId;
    @XmlElementRef(name = "CarrierId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> carrierId;
    @XmlElementRef(name = "AgreementUnitPrice", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> agreementUnitPrice;
    @XmlElement(name = "AgreementPriceOverAllwdYn")
    protected String agreementPriceOverAllwdYn;
    @XmlElementRef(name = "AgreementLimitPrice", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> agreementLimitPrice;
    @XmlElementRef(name = "AgreedQuantity", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<MeasureType> agreedQuantity;
    @XmlElementRef(name = "AgreementLimitQuantity", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<MeasureType> agreementLimitQuantity;
    @XmlElementRef(name = "AgreementLimitAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> agreementLimitAmount;
    @XmlElementRef(name = "MinReleaseQuantity", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<MeasureType> minReleaseQuantity;
    @XmlElementRef(name = "MinReleaseAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> minReleaseAmount;

    /**
     * Gets the value of the fixedPriceServiceYn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFixedPriceServiceYn() {
        return fixedPriceServiceYn;
    }

    /**
     * Sets the value of the fixedPriceServiceYn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFixedPriceServiceYn(String value) {
        this.fixedPriceServiceYn = value;
    }

    /**
     * Gets the value of the linePurchaseAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getLinePurchaseAmount() {
        return linePurchaseAmount;
    }

    /**
     * Sets the value of the linePurchaseAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setLinePurchaseAmount(JAXBElement<AmountType> value) {
        this.linePurchaseAmount = value;
    }

    /**
     * Gets the value of the supplierId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSupplierId() {
        return supplierId;
    }

    /**
     * Sets the value of the supplierId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSupplierId(JAXBElement<Long> value) {
        this.supplierId = value;
    }

    /**
     * Gets the value of the supplierSiteId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSupplierSiteId() {
        return supplierSiteId;
    }

    /**
     * Sets the value of the supplierSiteId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSupplierSiteId(JAXBElement<Long> value) {
        this.supplierSiteId = value;
    }

    /**
     * Gets the value of the recvInvOrgId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRecvInvOrgId() {
        return recvInvOrgId;
    }

    /**
     * Sets the value of the recvInvOrgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRecvInvOrgId(JAXBElement<Long> value) {
        this.recvInvOrgId = value;
    }

    /**
     * Gets the value of the deliveryDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getDeliveryDate() {
        return deliveryDate;
    }

    /**
     * Sets the value of the deliveryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setDeliveryDate(JAXBElement<XMLGregorianCalendar> value) {
        this.deliveryDate = value;
    }

    /**
     * Gets the value of the fobCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFobCode() {
        return fobCode;
    }

    /**
     * Sets the value of the fobCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFobCode(JAXBElement<String> value) {
        this.fobCode = value;
    }

    /**
     * Gets the value of the freightTermsCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFreightTermsCode() {
        return freightTermsCode;
    }

    /**
     * Sets the value of the freightTermsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFreightTermsCode(JAXBElement<String> value) {
        this.freightTermsCode = value;
    }

    /**
     * Gets the value of the recvLocationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRecvLocationId() {
        return recvLocationId;
    }

    /**
     * Sets the value of the recvLocationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRecvLocationId(JAXBElement<Long> value) {
        this.recvLocationId = value;
    }

    /**
     * Gets the value of the purchasingCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPurchasingCategoryId() {
        return purchasingCategoryId;
    }

    /**
     * Sets the value of the purchasingCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPurchasingCategoryId(JAXBElement<Long> value) {
        this.purchasingCategoryId = value;
    }

    /**
     * Gets the value of the paymentTermsId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymentTermsId() {
        return paymentTermsId;
    }

    /**
     * Sets the value of the paymentTermsId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymentTermsId(JAXBElement<Long> value) {
        this.paymentTermsId = value;
    }

    /**
     * Gets the value of the carrierId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCarrierId() {
        return carrierId;
    }

    /**
     * Sets the value of the carrierId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCarrierId(JAXBElement<Long> value) {
        this.carrierId = value;
    }

    /**
     * Gets the value of the agreementUnitPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getAgreementUnitPrice() {
        return agreementUnitPrice;
    }

    /**
     * Sets the value of the agreementUnitPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setAgreementUnitPrice(JAXBElement<AmountType> value) {
        this.agreementUnitPrice = value;
    }

    /**
     * Gets the value of the agreementPriceOverAllwdYn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgreementPriceOverAllwdYn() {
        return agreementPriceOverAllwdYn;
    }

    /**
     * Sets the value of the agreementPriceOverAllwdYn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgreementPriceOverAllwdYn(String value) {
        this.agreementPriceOverAllwdYn = value;
    }

    /**
     * Gets the value of the agreementLimitPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getAgreementLimitPrice() {
        return agreementLimitPrice;
    }

    /**
     * Sets the value of the agreementLimitPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setAgreementLimitPrice(JAXBElement<AmountType> value) {
        this.agreementLimitPrice = value;
    }

    /**
     * Gets the value of the agreedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public JAXBElement<MeasureType> getAgreedQuantity() {
        return agreedQuantity;
    }

    /**
     * Sets the value of the agreedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public void setAgreedQuantity(JAXBElement<MeasureType> value) {
        this.agreedQuantity = value;
    }

    /**
     * Gets the value of the agreementLimitQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public JAXBElement<MeasureType> getAgreementLimitQuantity() {
        return agreementLimitQuantity;
    }

    /**
     * Sets the value of the agreementLimitQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public void setAgreementLimitQuantity(JAXBElement<MeasureType> value) {
        this.agreementLimitQuantity = value;
    }

    /**
     * Gets the value of the agreementLimitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getAgreementLimitAmount() {
        return agreementLimitAmount;
    }

    /**
     * Sets the value of the agreementLimitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setAgreementLimitAmount(JAXBElement<AmountType> value) {
        this.agreementLimitAmount = value;
    }

    /**
     * Gets the value of the minReleaseQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public JAXBElement<MeasureType> getMinReleaseQuantity() {
        return minReleaseQuantity;
    }

    /**
     * Sets the value of the minReleaseQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public void setMinReleaseQuantity(JAXBElement<MeasureType> value) {
        this.minReleaseQuantity = value;
    }

    /**
     * Gets the value of the minReleaseAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getMinReleaseAmount() {
        return minReleaseAmount;
    }

    /**
     * Sets the value of the minReleaseAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setMinReleaseAmount(JAXBElement<AmountType> value) {
        this.minReleaseAmount = value;
    }

}
