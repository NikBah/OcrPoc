
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.oracle.xmlns.adf.svc.types.AmountType;
import com.oracle.xmlns.apps.contracts.coreauthoring.header.flex.header.ContractHeaderFlexfield;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.BillPlan;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.BillingControl;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.RevenuePlan;


/**
 * <p>Java class for ContractHeader complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContractHeader"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MajorVersion" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ExternalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrgId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="InvOrganizationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ContractTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ContractNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="StartDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="EndDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="BuyOrSell" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SalesAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ApTermsId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="AmendmentEffectiveDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="AutoReleaseInvoice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BillSequence" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillToAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillToSiteUseId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BilledAtSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Cognomen" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ContributionPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EstimatedAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="ExemptCertificateNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExemptReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Fob" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="FreightTerms" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvConvRateDateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvConvRateDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="InvConvRateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvTrxTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LastRevRecogDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="LegalEntityId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LineAutonumberEnabledFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="NetInvoiceFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="OrigSystemId1" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="OrigSystemReference1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrigSystemSourceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OutputTaxClassificationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OverallRiskCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OwningOrgId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ShipInvOrgId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ShipToAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ShipToSiteUseId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ShiptoLocationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ShortDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SoldToAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="SoldToSiteId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="StsCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SupplierId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="SupplierSiteId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="TaxAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="TaxExemptionControl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VersionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="WebServiceFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RecvInvOrgId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BilltoLocationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="TermsTemplateId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="ContractOwnerId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="PartyId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="AgreementEnabledFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="AgreementAmtLimit" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="AgreedAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="MinReleaseAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="EncumbranceLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CarrierId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="HoldReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HoldUntilDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="CustPoNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BillingSalesrepId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="VersionDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PriceList" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DiscountPercent" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="AdjustmentBasis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentAmount" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="HoldReasonCodeSetId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="TrnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TrnCodeSetId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LastUpdateDate" type="{http://xmlns.oracle.com/adf/svc/types/}dateTime-Timestamp" minOccurs="0"/&gt;
 *         &lt;element name="ContractParty" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractParty" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ContractLine" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractLine" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ContractRelatedDocument" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractRelatedDocument" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ContractHeaderDFFVL" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/}ContractHeaderFlexfield" minOccurs="0"/&gt;
 *         &lt;element name="BillPlan" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}BillPlan" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RevenuePlan" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}RevenuePlan" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SalesCredit" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}SalesCredit" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="HeaderBillingControl" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}BillingControl" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContractHeader", propOrder = {
    "id",
    "majorVersion",
    "externalSourceKey",
    "externalReferenceKey",
    "orgId",
    "invOrganizationId",
    "contractTypeId",
    "contractNumber",
    "startDate",
    "endDate",
    "buyOrSell",
    "currencyCode",
    "salesAcctId",
    "apTermsId",
    "amendmentEffectiveDate",
    "autoReleaseInvoice",
    "billSequence",
    "billToAcctId",
    "billToSiteUseId",
    "billedAtSource",
    "cognomen",
    "contributionPercent",
    "description",
    "estimatedAmount",
    "exemptCertificateNumber",
    "exemptReasonCode",
    "fob",
    "freightTerms",
    "invConvRateDateType",
    "invConvRateDate",
    "invConvRateType",
    "invTrxTypeId",
    "lastRevRecogDate",
    "legalEntityId",
    "lineAutonumberEnabledFlag",
    "netInvoiceFlag",
    "origSystemId1",
    "origSystemReference1",
    "origSystemSourceCode",
    "outputTaxClassificationCode",
    "overallRiskCode",
    "owningOrgId",
    "shipInvOrgId",
    "shipToAcctId",
    "shipToSiteUseId",
    "shiptoLocationId",
    "shortDescription",
    "soldToAcctId",
    "soldToSiteId",
    "stsCode",
    "supplierId",
    "supplierSiteId",
    "taxAmount",
    "taxExemptionControl",
    "versionType",
    "webServiceFlag",
    "recvInvOrgId",
    "billtoLocationId",
    "termsTemplateId",
    "contractOwnerId",
    "partyId",
    "agreementEnabledFlag",
    "agreementAmtLimit",
    "agreedAmount",
    "minReleaseAmt",
    "encumbranceLevel",
    "carrierId",
    "holdReasonCode",
    "holdUntilDate",
    "custPoNumber",
    "billingSalesrepId",
    "versionDescription",
    "priceList",
    "discountPercent",
    "adjustmentBasis",
    "commitmentAmount",
    "holdReasonCodeSetId",
    "trnCode",
    "trnCodeSetId",
    "lastUpdateDate",
    "contractParty",
    "contractLine",
    "contractRelatedDocument",
    "contractHeaderDFFVL",
    "billPlan",
    "revenuePlan",
    "salesCredit",
    "headerBillingControl"
})
public class ContractHeader {

    @XmlElement(name = "Id")
    protected Long id;
    @XmlElement(name = "MajorVersion")
    protected Long majorVersion;
    @XmlElementRef(name = "ExternalSourceKey", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalSourceKey;
    @XmlElementRef(name = "ExternalReferenceKey", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalReferenceKey;
    @XmlElement(name = "OrgId")
    protected Long orgId;
    @XmlElement(name = "InvOrganizationId")
    protected Long invOrganizationId;
    @XmlElement(name = "ContractTypeId")
    protected Long contractTypeId;
    @XmlElement(name = "ContractNumber")
    protected String contractNumber;
    @XmlElement(name = "StartDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar startDate;
    @XmlElementRef(name = "EndDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> endDate;
    @XmlElement(name = "BuyOrSell")
    protected String buyOrSell;
    @XmlElement(name = "CurrencyCode")
    protected String currencyCode;
    @XmlElementRef(name = "SalesAcctId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> salesAcctId;
    @XmlElementRef(name = "ApTermsId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> apTermsId;
    @XmlElementRef(name = "AmendmentEffectiveDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> amendmentEffectiveDate;
    @XmlElementRef(name = "AutoReleaseInvoice", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> autoReleaseInvoice;
    @XmlElementRef(name = "BillSequence", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billSequence;
    @XmlElementRef(name = "BillToAcctId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billToAcctId;
    @XmlElementRef(name = "BillToSiteUseId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billToSiteUseId;
    @XmlElementRef(name = "BilledAtSource", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billedAtSource;
    @XmlElementRef(name = "Cognomen", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cognomen;
    @XmlElementRef(name = "ContributionPercent", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> contributionPercent;
    @XmlElementRef(name = "Description", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "EstimatedAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> estimatedAmount;
    @XmlElementRef(name = "ExemptCertificateNumber", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> exemptCertificateNumber;
    @XmlElementRef(name = "ExemptReasonCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> exemptReasonCode;
    @XmlElementRef(name = "Fob", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> fob;
    @XmlElementRef(name = "FreightTerms", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> freightTerms;
    @XmlElementRef(name = "InvConvRateDateType", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invConvRateDateType;
    @XmlElementRef(name = "InvConvRateDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> invConvRateDate;
    @XmlElementRef(name = "InvConvRateType", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invConvRateType;
    @XmlElementRef(name = "InvTrxTypeId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> invTrxTypeId;
    @XmlElementRef(name = "LastRevRecogDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> lastRevRecogDate;
    @XmlElementRef(name = "LegalEntityId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> legalEntityId;
    @XmlElementRef(name = "LineAutonumberEnabledFlag", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> lineAutonumberEnabledFlag;
    @XmlElementRef(name = "NetInvoiceFlag", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> netInvoiceFlag;
    @XmlElementRef(name = "OrigSystemId1", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> origSystemId1;
    @XmlElementRef(name = "OrigSystemReference1", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> origSystemReference1;
    @XmlElementRef(name = "OrigSystemSourceCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> origSystemSourceCode;
    @XmlElementRef(name = "OutputTaxClassificationCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> outputTaxClassificationCode;
    @XmlElementRef(name = "OverallRiskCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> overallRiskCode;
    @XmlElementRef(name = "OwningOrgId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> owningOrgId;
    @XmlElementRef(name = "ShipInvOrgId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> shipInvOrgId;
    @XmlElementRef(name = "ShipToAcctId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> shipToAcctId;
    @XmlElementRef(name = "ShipToSiteUseId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> shipToSiteUseId;
    @XmlElementRef(name = "ShiptoLocationId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> shiptoLocationId;
    @XmlElementRef(name = "ShortDescription", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> shortDescription;
    @XmlElementRef(name = "SoldToAcctId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> soldToAcctId;
    @XmlElementRef(name = "SoldToSiteId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> soldToSiteId;
    @XmlElement(name = "StsCode")
    protected String stsCode;
    @XmlElementRef(name = "SupplierId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> supplierId;
    @XmlElementRef(name = "SupplierSiteId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> supplierSiteId;
    @XmlElementRef(name = "TaxAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> taxAmount;
    @XmlElementRef(name = "TaxExemptionControl", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> taxExemptionControl;
    @XmlElement(name = "VersionType")
    protected String versionType;
    @XmlElementRef(name = "WebServiceFlag", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> webServiceFlag;
    @XmlElementRef(name = "RecvInvOrgId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> recvInvOrgId;
    @XmlElementRef(name = "BilltoLocationId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billtoLocationId;
    @XmlElementRef(name = "TermsTemplateId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> termsTemplateId;
    @XmlElementRef(name = "ContractOwnerId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> contractOwnerId;
    @XmlElementRef(name = "PartyId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> partyId;
    @XmlElementRef(name = "AgreementEnabledFlag", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> agreementEnabledFlag;
    @XmlElementRef(name = "AgreementAmtLimit", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> agreementAmtLimit;
    @XmlElementRef(name = "AgreedAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> agreedAmount;
    @XmlElementRef(name = "MinReleaseAmt", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> minReleaseAmt;
    @XmlElementRef(name = "EncumbranceLevel", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> encumbranceLevel;
    @XmlElementRef(name = "CarrierId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> carrierId;
    @XmlElementRef(name = "HoldReasonCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> holdReasonCode;
    @XmlElementRef(name = "HoldUntilDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> holdUntilDate;
    @XmlElementRef(name = "CustPoNumber", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> custPoNumber;
    @XmlElementRef(name = "BillingSalesrepId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billingSalesrepId;
    @XmlElementRef(name = "VersionDescription", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> versionDescription;
    @XmlElementRef(name = "PriceList", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> priceList;
    @XmlElementRef(name = "DiscountPercent", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> discountPercent;
    @XmlElementRef(name = "AdjustmentBasis", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> adjustmentBasis;
    @XmlElementRef(name = "CommitmentAmount", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> commitmentAmount;
    @XmlElementRef(name = "HoldReasonCodeSetId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> holdReasonCodeSetId;
    @XmlElementRef(name = "TrnCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> trnCode;
    @XmlElementRef(name = "TrnCodeSetId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> trnCodeSetId;
    @XmlElement(name = "LastUpdateDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdateDate;
    @XmlElement(name = "ContractParty")
    protected List<ContractParty> contractParty;
    @XmlElement(name = "ContractLine")
    protected List<ContractLine> contractLine;
    @XmlElement(name = "ContractRelatedDocument")
    protected List<ContractRelatedDocument> contractRelatedDocument;
    @XmlElement(name = "ContractHeaderDFFVL")
    protected ContractHeaderFlexfield contractHeaderDFFVL;
    @XmlElement(name = "BillPlan")
    protected List<BillPlan> billPlan;
    @XmlElement(name = "RevenuePlan")
    protected List<RevenuePlan> revenuePlan;
    @XmlElement(name = "SalesCredit")
    protected List<SalesCredit> salesCredit;
    @XmlElement(name = "HeaderBillingControl")
    protected List<BillingControl> headerBillingControl;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setId(Long value) {
        this.id = value;
    }

    /**
     * Gets the value of the majorVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMajorVersion() {
        return majorVersion;
    }

    /**
     * Sets the value of the majorVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMajorVersion(Long value) {
        this.majorVersion = value;
    }

    /**
     * Gets the value of the externalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalSourceKey() {
        return externalSourceKey;
    }

    /**
     * Sets the value of the externalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalSourceKey(JAXBElement<String> value) {
        this.externalSourceKey = value;
    }

    /**
     * Gets the value of the externalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalReferenceKey() {
        return externalReferenceKey;
    }

    /**
     * Sets the value of the externalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalReferenceKey(JAXBElement<String> value) {
        this.externalReferenceKey = value;
    }

    /**
     * Gets the value of the orgId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getOrgId() {
        return orgId;
    }

    /**
     * Sets the value of the orgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setOrgId(Long value) {
        this.orgId = value;
    }

    /**
     * Gets the value of the invOrganizationId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getInvOrganizationId() {
        return invOrganizationId;
    }

    /**
     * Sets the value of the invOrganizationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setInvOrganizationId(Long value) {
        this.invOrganizationId = value;
    }

    /**
     * Gets the value of the contractTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getContractTypeId() {
        return contractTypeId;
    }

    /**
     * Sets the value of the contractTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setContractTypeId(Long value) {
        this.contractTypeId = value;
    }

    /**
     * Gets the value of the contractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractNumber() {
        return contractNumber;
    }

    /**
     * Sets the value of the contractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractNumber(String value) {
        this.contractNumber = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDate(XMLGregorianCalendar value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setEndDate(JAXBElement<XMLGregorianCalendar> value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the buyOrSell property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuyOrSell() {
        return buyOrSell;
    }

    /**
     * Sets the value of the buyOrSell property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuyOrSell(String value) {
        this.buyOrSell = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the salesAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSalesAcctId() {
        return salesAcctId;
    }

    /**
     * Sets the value of the salesAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSalesAcctId(JAXBElement<Long> value) {
        this.salesAcctId = value;
    }

    /**
     * Gets the value of the apTermsId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getApTermsId() {
        return apTermsId;
    }

    /**
     * Sets the value of the apTermsId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setApTermsId(JAXBElement<Long> value) {
        this.apTermsId = value;
    }

    /**
     * Gets the value of the amendmentEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getAmendmentEffectiveDate() {
        return amendmentEffectiveDate;
    }

    /**
     * Sets the value of the amendmentEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setAmendmentEffectiveDate(JAXBElement<XMLGregorianCalendar> value) {
        this.amendmentEffectiveDate = value;
    }

    /**
     * Gets the value of the autoReleaseInvoice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAutoReleaseInvoice() {
        return autoReleaseInvoice;
    }

    /**
     * Sets the value of the autoReleaseInvoice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAutoReleaseInvoice(JAXBElement<String> value) {
        this.autoReleaseInvoice = value;
    }

    /**
     * Gets the value of the billSequence property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillSequence() {
        return billSequence;
    }

    /**
     * Sets the value of the billSequence property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillSequence(JAXBElement<Long> value) {
        this.billSequence = value;
    }

    /**
     * Gets the value of the billToAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillToAcctId() {
        return billToAcctId;
    }

    /**
     * Sets the value of the billToAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillToAcctId(JAXBElement<Long> value) {
        this.billToAcctId = value;
    }

    /**
     * Gets the value of the billToSiteUseId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillToSiteUseId() {
        return billToSiteUseId;
    }

    /**
     * Sets the value of the billToSiteUseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillToSiteUseId(JAXBElement<Long> value) {
        this.billToSiteUseId = value;
    }

    /**
     * Gets the value of the billedAtSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBilledAtSource() {
        return billedAtSource;
    }

    /**
     * Sets the value of the billedAtSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBilledAtSource(JAXBElement<String> value) {
        this.billedAtSource = value;
    }

    /**
     * Gets the value of the cognomen property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCognomen() {
        return cognomen;
    }

    /**
     * Sets the value of the cognomen property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCognomen(JAXBElement<String> value) {
        this.cognomen = value;
    }

    /**
     * Gets the value of the contributionPercent property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getContributionPercent() {
        return contributionPercent;
    }

    /**
     * Sets the value of the contributionPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setContributionPercent(JAXBElement<BigDecimal> value) {
        this.contributionPercent = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the estimatedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getEstimatedAmount() {
        return estimatedAmount;
    }

    /**
     * Sets the value of the estimatedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setEstimatedAmount(JAXBElement<AmountType> value) {
        this.estimatedAmount = value;
    }

    /**
     * Gets the value of the exemptCertificateNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExemptCertificateNumber() {
        return exemptCertificateNumber;
    }

    /**
     * Sets the value of the exemptCertificateNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExemptCertificateNumber(JAXBElement<String> value) {
        this.exemptCertificateNumber = value;
    }

    /**
     * Gets the value of the exemptReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExemptReasonCode() {
        return exemptReasonCode;
    }

    /**
     * Sets the value of the exemptReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExemptReasonCode(JAXBElement<String> value) {
        this.exemptReasonCode = value;
    }

    /**
     * Gets the value of the fob property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFob() {
        return fob;
    }

    /**
     * Sets the value of the fob property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFob(JAXBElement<String> value) {
        this.fob = value;
    }

    /**
     * Gets the value of the freightTerms property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFreightTerms() {
        return freightTerms;
    }

    /**
     * Sets the value of the freightTerms property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFreightTerms(JAXBElement<String> value) {
        this.freightTerms = value;
    }

    /**
     * Gets the value of the invConvRateDateType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvConvRateDateType() {
        return invConvRateDateType;
    }

    /**
     * Sets the value of the invConvRateDateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvConvRateDateType(JAXBElement<String> value) {
        this.invConvRateDateType = value;
    }

    /**
     * Gets the value of the invConvRateDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getInvConvRateDate() {
        return invConvRateDate;
    }

    /**
     * Sets the value of the invConvRateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setInvConvRateDate(JAXBElement<XMLGregorianCalendar> value) {
        this.invConvRateDate = value;
    }

    /**
     * Gets the value of the invConvRateType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvConvRateType() {
        return invConvRateType;
    }

    /**
     * Sets the value of the invConvRateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvConvRateType(JAXBElement<String> value) {
        this.invConvRateType = value;
    }

    /**
     * Gets the value of the invTrxTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvTrxTypeId() {
        return invTrxTypeId;
    }

    /**
     * Sets the value of the invTrxTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvTrxTypeId(JAXBElement<Long> value) {
        this.invTrxTypeId = value;
    }

    /**
     * Gets the value of the lastRevRecogDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLastRevRecogDate() {
        return lastRevRecogDate;
    }

    /**
     * Sets the value of the lastRevRecogDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLastRevRecogDate(JAXBElement<XMLGregorianCalendar> value) {
        this.lastRevRecogDate = value;
    }

    /**
     * Gets the value of the legalEntityId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLegalEntityId() {
        return legalEntityId;
    }

    /**
     * Sets the value of the legalEntityId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLegalEntityId(JAXBElement<Long> value) {
        this.legalEntityId = value;
    }

    /**
     * Gets the value of the lineAutonumberEnabledFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getLineAutonumberEnabledFlag() {
        return lineAutonumberEnabledFlag;
    }

    /**
     * Sets the value of the lineAutonumberEnabledFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setLineAutonumberEnabledFlag(JAXBElement<Boolean> value) {
        this.lineAutonumberEnabledFlag = value;
    }

    /**
     * Gets the value of the netInvoiceFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getNetInvoiceFlag() {
        return netInvoiceFlag;
    }

    /**
     * Sets the value of the netInvoiceFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setNetInvoiceFlag(JAXBElement<Boolean> value) {
        this.netInvoiceFlag = value;
    }

    /**
     * Gets the value of the origSystemId1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getOrigSystemId1() {
        return origSystemId1;
    }

    /**
     * Sets the value of the origSystemId1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setOrigSystemId1(JAXBElement<Long> value) {
        this.origSystemId1 = value;
    }

    /**
     * Gets the value of the origSystemReference1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOrigSystemReference1() {
        return origSystemReference1;
    }

    /**
     * Sets the value of the origSystemReference1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOrigSystemReference1(JAXBElement<String> value) {
        this.origSystemReference1 = value;
    }

    /**
     * Gets the value of the origSystemSourceCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOrigSystemSourceCode() {
        return origSystemSourceCode;
    }

    /**
     * Sets the value of the origSystemSourceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOrigSystemSourceCode(JAXBElement<String> value) {
        this.origSystemSourceCode = value;
    }

    /**
     * Gets the value of the outputTaxClassificationCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOutputTaxClassificationCode() {
        return outputTaxClassificationCode;
    }

    /**
     * Sets the value of the outputTaxClassificationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOutputTaxClassificationCode(JAXBElement<String> value) {
        this.outputTaxClassificationCode = value;
    }

    /**
     * Gets the value of the overallRiskCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOverallRiskCode() {
        return overallRiskCode;
    }

    /**
     * Sets the value of the overallRiskCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOverallRiskCode(JAXBElement<String> value) {
        this.overallRiskCode = value;
    }

    /**
     * Gets the value of the owningOrgId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getOwningOrgId() {
        return owningOrgId;
    }

    /**
     * Sets the value of the owningOrgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setOwningOrgId(JAXBElement<Long> value) {
        this.owningOrgId = value;
    }

    /**
     * Gets the value of the shipInvOrgId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getShipInvOrgId() {
        return shipInvOrgId;
    }

    /**
     * Sets the value of the shipInvOrgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setShipInvOrgId(JAXBElement<Long> value) {
        this.shipInvOrgId = value;
    }

    /**
     * Gets the value of the shipToAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getShipToAcctId() {
        return shipToAcctId;
    }

    /**
     * Sets the value of the shipToAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setShipToAcctId(JAXBElement<Long> value) {
        this.shipToAcctId = value;
    }

    /**
     * Gets the value of the shipToSiteUseId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getShipToSiteUseId() {
        return shipToSiteUseId;
    }

    /**
     * Sets the value of the shipToSiteUseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setShipToSiteUseId(JAXBElement<Long> value) {
        this.shipToSiteUseId = value;
    }

    /**
     * Gets the value of the shiptoLocationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getShiptoLocationId() {
        return shiptoLocationId;
    }

    /**
     * Sets the value of the shiptoLocationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setShiptoLocationId(JAXBElement<Long> value) {
        this.shiptoLocationId = value;
    }

    /**
     * Gets the value of the shortDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getShortDescription() {
        return shortDescription;
    }

    /**
     * Sets the value of the shortDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setShortDescription(JAXBElement<String> value) {
        this.shortDescription = value;
    }

    /**
     * Gets the value of the soldToAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSoldToAcctId() {
        return soldToAcctId;
    }

    /**
     * Sets the value of the soldToAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSoldToAcctId(JAXBElement<Long> value) {
        this.soldToAcctId = value;
    }

    /**
     * Gets the value of the soldToSiteId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSoldToSiteId() {
        return soldToSiteId;
    }

    /**
     * Sets the value of the soldToSiteId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSoldToSiteId(JAXBElement<Long> value) {
        this.soldToSiteId = value;
    }

    /**
     * Gets the value of the stsCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStsCode() {
        return stsCode;
    }

    /**
     * Sets the value of the stsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStsCode(String value) {
        this.stsCode = value;
    }

    /**
     * Gets the value of the supplierId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSupplierId() {
        return supplierId;
    }

    /**
     * Sets the value of the supplierId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSupplierId(JAXBElement<Long> value) {
        this.supplierId = value;
    }

    /**
     * Gets the value of the supplierSiteId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSupplierSiteId() {
        return supplierSiteId;
    }

    /**
     * Sets the value of the supplierSiteId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSupplierSiteId(JAXBElement<Long> value) {
        this.supplierSiteId = value;
    }

    /**
     * Gets the value of the taxAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getTaxAmount() {
        return taxAmount;
    }

    /**
     * Sets the value of the taxAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setTaxAmount(JAXBElement<AmountType> value) {
        this.taxAmount = value;
    }

    /**
     * Gets the value of the taxExemptionControl property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTaxExemptionControl() {
        return taxExemptionControl;
    }

    /**
     * Sets the value of the taxExemptionControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTaxExemptionControl(JAXBElement<String> value) {
        this.taxExemptionControl = value;
    }

    /**
     * Gets the value of the versionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersionType() {
        return versionType;
    }

    /**
     * Sets the value of the versionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersionType(String value) {
        this.versionType = value;
    }

    /**
     * Gets the value of the webServiceFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getWebServiceFlag() {
        return webServiceFlag;
    }

    /**
     * Sets the value of the webServiceFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setWebServiceFlag(JAXBElement<Boolean> value) {
        this.webServiceFlag = value;
    }

    /**
     * Gets the value of the recvInvOrgId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRecvInvOrgId() {
        return recvInvOrgId;
    }

    /**
     * Sets the value of the recvInvOrgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRecvInvOrgId(JAXBElement<Long> value) {
        this.recvInvOrgId = value;
    }

    /**
     * Gets the value of the billtoLocationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBilltoLocationId() {
        return billtoLocationId;
    }

    /**
     * Sets the value of the billtoLocationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBilltoLocationId(JAXBElement<Long> value) {
        this.billtoLocationId = value;
    }

    /**
     * Gets the value of the termsTemplateId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTermsTemplateId() {
        return termsTemplateId;
    }

    /**
     * Sets the value of the termsTemplateId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTermsTemplateId(JAXBElement<Long> value) {
        this.termsTemplateId = value;
    }

    /**
     * Gets the value of the contractOwnerId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getContractOwnerId() {
        return contractOwnerId;
    }

    /**
     * Sets the value of the contractOwnerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setContractOwnerId(JAXBElement<Long> value) {
        this.contractOwnerId = value;
    }

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPartyId(JAXBElement<Long> value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the agreementEnabledFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getAgreementEnabledFlag() {
        return agreementEnabledFlag;
    }

    /**
     * Sets the value of the agreementEnabledFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setAgreementEnabledFlag(JAXBElement<Boolean> value) {
        this.agreementEnabledFlag = value;
    }

    /**
     * Gets the value of the agreementAmtLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getAgreementAmtLimit() {
        return agreementAmtLimit;
    }

    /**
     * Sets the value of the agreementAmtLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setAgreementAmtLimit(JAXBElement<BigDecimal> value) {
        this.agreementAmtLimit = value;
    }

    /**
     * Gets the value of the agreedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getAgreedAmount() {
        return agreedAmount;
    }

    /**
     * Sets the value of the agreedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setAgreedAmount(JAXBElement<AmountType> value) {
        this.agreedAmount = value;
    }

    /**
     * Gets the value of the minReleaseAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getMinReleaseAmt() {
        return minReleaseAmt;
    }

    /**
     * Sets the value of the minReleaseAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setMinReleaseAmt(JAXBElement<BigDecimal> value) {
        this.minReleaseAmt = value;
    }

    /**
     * Gets the value of the encumbranceLevel property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEncumbranceLevel() {
        return encumbranceLevel;
    }

    /**
     * Sets the value of the encumbranceLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEncumbranceLevel(JAXBElement<String> value) {
        this.encumbranceLevel = value;
    }

    /**
     * Gets the value of the carrierId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCarrierId() {
        return carrierId;
    }

    /**
     * Sets the value of the carrierId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCarrierId(JAXBElement<Long> value) {
        this.carrierId = value;
    }

    /**
     * Gets the value of the holdReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getHoldReasonCode() {
        return holdReasonCode;
    }

    /**
     * Sets the value of the holdReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setHoldReasonCode(JAXBElement<String> value) {
        this.holdReasonCode = value;
    }

    /**
     * Gets the value of the holdUntilDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getHoldUntilDate() {
        return holdUntilDate;
    }

    /**
     * Sets the value of the holdUntilDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setHoldUntilDate(JAXBElement<XMLGregorianCalendar> value) {
        this.holdUntilDate = value;
    }

    /**
     * Gets the value of the custPoNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustPoNumber() {
        return custPoNumber;
    }

    /**
     * Sets the value of the custPoNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustPoNumber(JAXBElement<String> value) {
        this.custPoNumber = value;
    }

    /**
     * Gets the value of the billingSalesrepId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillingSalesrepId() {
        return billingSalesrepId;
    }

    /**
     * Sets the value of the billingSalesrepId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillingSalesrepId(JAXBElement<Long> value) {
        this.billingSalesrepId = value;
    }

    /**
     * Gets the value of the versionDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getVersionDescription() {
        return versionDescription;
    }

    /**
     * Sets the value of the versionDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setVersionDescription(JAXBElement<String> value) {
        this.versionDescription = value;
    }

    /**
     * Gets the value of the priceList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPriceList() {
        return priceList;
    }

    /**
     * Sets the value of the priceList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPriceList(JAXBElement<String> value) {
        this.priceList = value;
    }

    /**
     * Gets the value of the discountPercent property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getDiscountPercent() {
        return discountPercent;
    }

    /**
     * Sets the value of the discountPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setDiscountPercent(JAXBElement<BigDecimal> value) {
        this.discountPercent = value;
    }

    /**
     * Gets the value of the adjustmentBasis property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAdjustmentBasis() {
        return adjustmentBasis;
    }

    /**
     * Sets the value of the adjustmentBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAdjustmentBasis(JAXBElement<String> value) {
        this.adjustmentBasis = value;
    }

    /**
     * Gets the value of the commitmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getCommitmentAmount() {
        return commitmentAmount;
    }

    /**
     * Sets the value of the commitmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setCommitmentAmount(JAXBElement<AmountType> value) {
        this.commitmentAmount = value;
    }

    /**
     * Gets the value of the holdReasonCodeSetId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHoldReasonCodeSetId() {
        return holdReasonCodeSetId;
    }

    /**
     * Sets the value of the holdReasonCodeSetId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHoldReasonCodeSetId(JAXBElement<Long> value) {
        this.holdReasonCodeSetId = value;
    }

    /**
     * Gets the value of the trnCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTrnCode() {
        return trnCode;
    }

    /**
     * Sets the value of the trnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTrnCode(JAXBElement<String> value) {
        this.trnCode = value;
    }

    /**
     * Gets the value of the trnCodeSetId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTrnCodeSetId() {
        return trnCodeSetId;
    }

    /**
     * Sets the value of the trnCodeSetId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTrnCodeSetId(JAXBElement<Long> value) {
        this.trnCodeSetId = value;
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdateDate(XMLGregorianCalendar value) {
        this.lastUpdateDate = value;
    }

    /**
     * Gets the value of the contractParty property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contractParty property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContractParty().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContractParty }
     * 
     * 
     */
    public List<ContractParty> getContractParty() {
        if (contractParty == null) {
            contractParty = new ArrayList<ContractParty>();
        }
        return this.contractParty;
    }

    /**
     * Gets the value of the contractLine property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contractLine property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContractLine().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContractLine }
     * 
     * 
     */
    public List<ContractLine> getContractLine() {
        if (contractLine == null) {
            contractLine = new ArrayList<ContractLine>();
        }
        return this.contractLine;
    }

    /**
     * Gets the value of the contractRelatedDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contractRelatedDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContractRelatedDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContractRelatedDocument }
     * 
     * 
     */
    public List<ContractRelatedDocument> getContractRelatedDocument() {
        if (contractRelatedDocument == null) {
            contractRelatedDocument = new ArrayList<ContractRelatedDocument>();
        }
        return this.contractRelatedDocument;
    }

    /**
     * Gets the value of the contractHeaderDFFVL property.
     * 
     * @return
     *     possible object is
     *     {@link ContractHeaderFlexfield }
     *     
     */
    public ContractHeaderFlexfield getContractHeaderDFFVL() {
        return contractHeaderDFFVL;
    }

    /**
     * Sets the value of the contractHeaderDFFVL property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContractHeaderFlexfield }
     *     
     */
    public void setContractHeaderDFFVL(ContractHeaderFlexfield value) {
        this.contractHeaderDFFVL = value;
    }

    /**
     * Gets the value of the billPlan property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the billPlan property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBillPlan().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BillPlan }
     * 
     * 
     */
    public List<BillPlan> getBillPlan() {
        if (billPlan == null) {
            billPlan = new ArrayList<BillPlan>();
        }
        return this.billPlan;
    }

    /**
     * Gets the value of the revenuePlan property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the revenuePlan property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRevenuePlan().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RevenuePlan }
     * 
     * 
     */
    public List<RevenuePlan> getRevenuePlan() {
        if (revenuePlan == null) {
            revenuePlan = new ArrayList<RevenuePlan>();
        }
        return this.revenuePlan;
    }

    /**
     * Gets the value of the salesCredit property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the salesCredit property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSalesCredit().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SalesCredit }
     * 
     * 
     */
    public List<SalesCredit> getSalesCredit() {
        if (salesCredit == null) {
            salesCredit = new ArrayList<SalesCredit>();
        }
        return this.salesCredit;
    }

    /**
     * Gets the value of the headerBillingControl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headerBillingControl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeaderBillingControl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BillingControl }
     * 
     * 
     */
    public List<BillingControl> getHeaderBillingControl() {
        if (headerBillingControl == null) {
            headerBillingControl = new ArrayList<BillingControl>();
        }
        return this.headerBillingControl;
    }

}
