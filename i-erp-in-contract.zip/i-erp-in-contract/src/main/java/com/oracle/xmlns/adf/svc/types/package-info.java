@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/adf/svc/types/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.adf.svc.types;
