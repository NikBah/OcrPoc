
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractHeader;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="contractHeader" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractHeader"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "contractHeader"
})
@XmlRootElement(name = "mergeContractAsync")
public class MergeContractAsync {

    @XmlElement(required = true)
    protected ContractHeader contractHeader;

    /**
     * Gets the value of the contractHeader property.
     * 
     * @return
     *     possible object is
     *     {@link ContractHeader }
     *     
     */
    public ContractHeader getContractHeader() {
        return contractHeader;
    }

    /**
     * Sets the value of the contractHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContractHeader }
     *     
     */
    public void setContractHeader(ContractHeader value) {
        this.contractHeader = value;
    }

}
