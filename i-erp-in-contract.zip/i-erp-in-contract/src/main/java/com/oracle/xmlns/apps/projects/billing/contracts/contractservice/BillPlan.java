
package com.oracle.xmlns.apps.projects.billing.contracts.contractservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.oracle.xmlns.apps.projects.billing.contracts.flex.billlplandff.BilllPlanDff;


/**
 * <p>Java class for BillPlan complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillPlan"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BillPlanId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MajorVersion" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillMethodId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillPlanName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceCurrencyOptCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentTermId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillSetNum" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="BillToCustAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillToSiteUseId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillToContactId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BillingCycleId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LaborInvoiceFormatId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="NlInvoiceFormatId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="EventsInvoiceFormatId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="FirstBillingOffsetDays" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceInstructions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceComment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EmpBillRateSchId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="JobBillRateSchId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LaborSchFixedDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="LaborDiscountPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="LaborDiscountReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EnableLbrBillXtnsnFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="NlBillRateSchId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="NlSchFixedDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="NlDiscountPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="NlDiscountReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="EnableNlBillXtnsnFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="BurdenSchId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="BurdenSchFixedDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="LaborTpScheduleId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="LaborTpSchFixedDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="NlTpScheduleId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="NlTpSchFixedDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="OnHoldFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="ExternalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExternalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceCurrDateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceCurrExchgDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceCurrRateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="NlBillBasisCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LaborBillBasisCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LaborMarkupPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="NlMarkupPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="DocNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LocFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="ReportTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AssignmentDetail" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}AssignmentDetail" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="JobAssignmentOverride" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}JobAssignmentOverride" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="JobTitleOverride" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}JobTitleOverride" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LaborMultiplierOverride" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}LaborMultiplierOverride" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="NonLaborRateOverride" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}NonLaborRateOverride" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PersonRateOverride" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}PersonRateOverride" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BillPlanDescriptiveFlexField" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/flex/BilllPlanDff/}BilllPlanDff" minOccurs="0"/&gt;
 *         &lt;element name="BillPlanTranslation" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}BillPlanTranslation" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="JobRateOverride" type="{http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/}JobRateOverride" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillPlan", propOrder = {
    "billPlanId",
    "majorVersion",
    "billMethodId",
    "billPlanName",
    "invoiceCurrencyOptCode",
    "paymentTermId",
    "billSetNum",
    "billToCustAcctId",
    "billToSiteUseId",
    "billToContactId",
    "billingCycleId",
    "laborInvoiceFormatId",
    "nlInvoiceFormatId",
    "eventsInvoiceFormatId",
    "firstBillingOffsetDays",
    "invoiceInstructions",
    "invoiceComment",
    "empBillRateSchId",
    "jobBillRateSchId",
    "laborSchFixedDate",
    "laborDiscountPercentage",
    "laborDiscountReasonCode",
    "enableLbrBillXtnsnFlag",
    "nlBillRateSchId",
    "nlSchFixedDate",
    "nlDiscountPercentage",
    "nlDiscountReasonCode",
    "enableNlBillXtnsnFlag",
    "burdenSchId",
    "burdenSchFixedDate",
    "laborTpScheduleId",
    "laborTpSchFixedDate",
    "nlTpScheduleId",
    "nlTpSchFixedDate",
    "onHoldFlag",
    "externalSourceKey",
    "externalReferenceKey",
    "invoiceCurrDateType",
    "invoiceCurrExchgDate",
    "invoiceCurrRateType",
    "invoiceCurrencyCode",
    "nlBillBasisCode",
    "laborBillBasisCode",
    "laborMarkupPercentage",
    "nlMarkupPercentage",
    "docNumber",
    "locFlag",
    "reportTypeCode",
    "assignmentDetail",
    "jobAssignmentOverride",
    "jobTitleOverride",
    "laborMultiplierOverride",
    "nonLaborRateOverride",
    "personRateOverride",
    "billPlanDescriptiveFlexField",
    "billPlanTranslation",
    "jobRateOverride"
})
public class BillPlan {

    @XmlElement(name = "BillPlanId")
    protected Long billPlanId;
    @XmlElement(name = "MajorVersion")
    protected Long majorVersion;
    @XmlElement(name = "BillMethodId")
    protected Long billMethodId;
    @XmlElement(name = "BillPlanName")
    protected String billPlanName;
    @XmlElementRef(name = "InvoiceCurrencyOptCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceCurrencyOptCode;
    @XmlElement(name = "PaymentTermId")
    protected Long paymentTermId;
    @XmlElement(name = "BillSetNum")
    protected BigDecimal billSetNum;
    @XmlElement(name = "BillToCustAcctId")
    protected Long billToCustAcctId;
    @XmlElement(name = "BillToSiteUseId")
    protected Long billToSiteUseId;
    @XmlElement(name = "BillToContactId")
    protected Long billToContactId;
    @XmlElement(name = "BillingCycleId")
    protected Long billingCycleId;
    @XmlElement(name = "LaborInvoiceFormatId")
    protected Long laborInvoiceFormatId;
    @XmlElement(name = "NlInvoiceFormatId")
    protected Long nlInvoiceFormatId;
    @XmlElement(name = "EventsInvoiceFormatId")
    protected Long eventsInvoiceFormatId;
    @XmlElementRef(name = "FirstBillingOffsetDays", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> firstBillingOffsetDays;
    @XmlElementRef(name = "InvoiceInstructions", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceInstructions;
    @XmlElementRef(name = "InvoiceComment", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceComment;
    @XmlElementRef(name = "EmpBillRateSchId", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> empBillRateSchId;
    @XmlElementRef(name = "JobBillRateSchId", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> jobBillRateSchId;
    @XmlElementRef(name = "LaborSchFixedDate", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> laborSchFixedDate;
    @XmlElementRef(name = "LaborDiscountPercentage", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> laborDiscountPercentage;
    @XmlElementRef(name = "LaborDiscountReasonCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> laborDiscountReasonCode;
    @XmlElementRef(name = "EnableLbrBillXtnsnFlag", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> enableLbrBillXtnsnFlag;
    @XmlElementRef(name = "NlBillRateSchId", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> nlBillRateSchId;
    @XmlElementRef(name = "NlSchFixedDate", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> nlSchFixedDate;
    @XmlElementRef(name = "NlDiscountPercentage", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> nlDiscountPercentage;
    @XmlElementRef(name = "NlDiscountReasonCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nlDiscountReasonCode;
    @XmlElementRef(name = "EnableNlBillXtnsnFlag", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> enableNlBillXtnsnFlag;
    @XmlElementRef(name = "BurdenSchId", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> burdenSchId;
    @XmlElementRef(name = "BurdenSchFixedDate", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> burdenSchFixedDate;
    @XmlElementRef(name = "LaborTpScheduleId", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> laborTpScheduleId;
    @XmlElementRef(name = "LaborTpSchFixedDate", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> laborTpSchFixedDate;
    @XmlElementRef(name = "NlTpScheduleId", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> nlTpScheduleId;
    @XmlElementRef(name = "NlTpSchFixedDate", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> nlTpSchFixedDate;
    @XmlElementRef(name = "OnHoldFlag", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> onHoldFlag;
    @XmlElementRef(name = "ExternalSourceKey", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalSourceKey;
    @XmlElementRef(name = "ExternalReferenceKey", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> externalReferenceKey;
    @XmlElementRef(name = "InvoiceCurrDateType", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceCurrDateType;
    @XmlElementRef(name = "InvoiceCurrExchgDate", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> invoiceCurrExchgDate;
    @XmlElementRef(name = "InvoiceCurrRateType", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceCurrRateType;
    @XmlElementRef(name = "InvoiceCurrencyCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceCurrencyCode;
    @XmlElementRef(name = "NlBillBasisCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nlBillBasisCode;
    @XmlElementRef(name = "LaborBillBasisCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> laborBillBasisCode;
    @XmlElementRef(name = "LaborMarkupPercentage", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> laborMarkupPercentage;
    @XmlElementRef(name = "NlMarkupPercentage", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> nlMarkupPercentage;
    @XmlElementRef(name = "DocNumber", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> docNumber;
    @XmlElementRef(name = "LocFlag", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> locFlag;
    @XmlElementRef(name = "ReportTypeCode", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> reportTypeCode;
    @XmlElement(name = "AssignmentDetail")
    protected List<AssignmentDetail> assignmentDetail;
    @XmlElement(name = "JobAssignmentOverride")
    protected List<JobAssignmentOverride> jobAssignmentOverride;
    @XmlElement(name = "JobTitleOverride")
    protected List<JobTitleOverride> jobTitleOverride;
    @XmlElement(name = "LaborMultiplierOverride")
    protected List<LaborMultiplierOverride> laborMultiplierOverride;
    @XmlElement(name = "NonLaborRateOverride")
    protected List<NonLaborRateOverride> nonLaborRateOverride;
    @XmlElement(name = "PersonRateOverride")
    protected List<PersonRateOverride> personRateOverride;
    @XmlElement(name = "BillPlanDescriptiveFlexField")
    protected BilllPlanDff billPlanDescriptiveFlexField;
    @XmlElement(name = "BillPlanTranslation")
    protected List<BillPlanTranslation> billPlanTranslation;
    @XmlElement(name = "JobRateOverride")
    protected List<JobRateOverride> jobRateOverride;

    /**
     * Gets the value of the billPlanId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBillPlanId() {
        return billPlanId;
    }

    /**
     * Sets the value of the billPlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBillPlanId(Long value) {
        this.billPlanId = value;
    }

    /**
     * Gets the value of the majorVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMajorVersion() {
        return majorVersion;
    }

    /**
     * Sets the value of the majorVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMajorVersion(Long value) {
        this.majorVersion = value;
    }

    /**
     * Gets the value of the billMethodId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBillMethodId() {
        return billMethodId;
    }

    /**
     * Sets the value of the billMethodId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBillMethodId(Long value) {
        this.billMethodId = value;
    }

    /**
     * Gets the value of the billPlanName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillPlanName() {
        return billPlanName;
    }

    /**
     * Sets the value of the billPlanName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillPlanName(String value) {
        this.billPlanName = value;
    }

    /**
     * Gets the value of the invoiceCurrencyOptCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceCurrencyOptCode() {
        return invoiceCurrencyOptCode;
    }

    /**
     * Sets the value of the invoiceCurrencyOptCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceCurrencyOptCode(JAXBElement<String> value) {
        this.invoiceCurrencyOptCode = value;
    }

    /**
     * Gets the value of the paymentTermId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getPaymentTermId() {
        return paymentTermId;
    }

    /**
     * Sets the value of the paymentTermId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setPaymentTermId(Long value) {
        this.paymentTermId = value;
    }

    /**
     * Gets the value of the billSetNum property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBillSetNum() {
        return billSetNum;
    }

    /**
     * Sets the value of the billSetNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBillSetNum(BigDecimal value) {
        this.billSetNum = value;
    }

    /**
     * Gets the value of the billToCustAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBillToCustAcctId() {
        return billToCustAcctId;
    }

    /**
     * Sets the value of the billToCustAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBillToCustAcctId(Long value) {
        this.billToCustAcctId = value;
    }

    /**
     * Gets the value of the billToSiteUseId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBillToSiteUseId() {
        return billToSiteUseId;
    }

    /**
     * Sets the value of the billToSiteUseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBillToSiteUseId(Long value) {
        this.billToSiteUseId = value;
    }

    /**
     * Gets the value of the billToContactId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBillToContactId() {
        return billToContactId;
    }

    /**
     * Sets the value of the billToContactId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBillToContactId(Long value) {
        this.billToContactId = value;
    }

    /**
     * Gets the value of the billingCycleId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBillingCycleId() {
        return billingCycleId;
    }

    /**
     * Sets the value of the billingCycleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBillingCycleId(Long value) {
        this.billingCycleId = value;
    }

    /**
     * Gets the value of the laborInvoiceFormatId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLaborInvoiceFormatId() {
        return laborInvoiceFormatId;
    }

    /**
     * Sets the value of the laborInvoiceFormatId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLaborInvoiceFormatId(Long value) {
        this.laborInvoiceFormatId = value;
    }

    /**
     * Gets the value of the nlInvoiceFormatId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNlInvoiceFormatId() {
        return nlInvoiceFormatId;
    }

    /**
     * Sets the value of the nlInvoiceFormatId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNlInvoiceFormatId(Long value) {
        this.nlInvoiceFormatId = value;
    }

    /**
     * Gets the value of the eventsInvoiceFormatId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getEventsInvoiceFormatId() {
        return eventsInvoiceFormatId;
    }

    /**
     * Sets the value of the eventsInvoiceFormatId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setEventsInvoiceFormatId(Long value) {
        this.eventsInvoiceFormatId = value;
    }

    /**
     * Gets the value of the firstBillingOffsetDays property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getFirstBillingOffsetDays() {
        return firstBillingOffsetDays;
    }

    /**
     * Sets the value of the firstBillingOffsetDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setFirstBillingOffsetDays(JAXBElement<BigDecimal> value) {
        this.firstBillingOffsetDays = value;
    }

    /**
     * Gets the value of the invoiceInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceInstructions() {
        return invoiceInstructions;
    }

    /**
     * Sets the value of the invoiceInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceInstructions(JAXBElement<String> value) {
        this.invoiceInstructions = value;
    }

    /**
     * Gets the value of the invoiceComment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceComment() {
        return invoiceComment;
    }

    /**
     * Sets the value of the invoiceComment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceComment(JAXBElement<String> value) {
        this.invoiceComment = value;
    }

    /**
     * Gets the value of the empBillRateSchId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getEmpBillRateSchId() {
        return empBillRateSchId;
    }

    /**
     * Sets the value of the empBillRateSchId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setEmpBillRateSchId(JAXBElement<Long> value) {
        this.empBillRateSchId = value;
    }

    /**
     * Gets the value of the jobBillRateSchId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getJobBillRateSchId() {
        return jobBillRateSchId;
    }

    /**
     * Sets the value of the jobBillRateSchId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setJobBillRateSchId(JAXBElement<Long> value) {
        this.jobBillRateSchId = value;
    }

    /**
     * Gets the value of the laborSchFixedDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLaborSchFixedDate() {
        return laborSchFixedDate;
    }

    /**
     * Sets the value of the laborSchFixedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLaborSchFixedDate(JAXBElement<XMLGregorianCalendar> value) {
        this.laborSchFixedDate = value;
    }

    /**
     * Gets the value of the laborDiscountPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getLaborDiscountPercentage() {
        return laborDiscountPercentage;
    }

    /**
     * Sets the value of the laborDiscountPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setLaborDiscountPercentage(JAXBElement<BigDecimal> value) {
        this.laborDiscountPercentage = value;
    }

    /**
     * Gets the value of the laborDiscountReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLaborDiscountReasonCode() {
        return laborDiscountReasonCode;
    }

    /**
     * Sets the value of the laborDiscountReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLaborDiscountReasonCode(JAXBElement<String> value) {
        this.laborDiscountReasonCode = value;
    }

    /**
     * Gets the value of the enableLbrBillXtnsnFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getEnableLbrBillXtnsnFlag() {
        return enableLbrBillXtnsnFlag;
    }

    /**
     * Sets the value of the enableLbrBillXtnsnFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setEnableLbrBillXtnsnFlag(JAXBElement<Boolean> value) {
        this.enableLbrBillXtnsnFlag = value;
    }

    /**
     * Gets the value of the nlBillRateSchId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getNlBillRateSchId() {
        return nlBillRateSchId;
    }

    /**
     * Sets the value of the nlBillRateSchId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setNlBillRateSchId(JAXBElement<Long> value) {
        this.nlBillRateSchId = value;
    }

    /**
     * Gets the value of the nlSchFixedDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getNlSchFixedDate() {
        return nlSchFixedDate;
    }

    /**
     * Sets the value of the nlSchFixedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setNlSchFixedDate(JAXBElement<XMLGregorianCalendar> value) {
        this.nlSchFixedDate = value;
    }

    /**
     * Gets the value of the nlDiscountPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getNlDiscountPercentage() {
        return nlDiscountPercentage;
    }

    /**
     * Sets the value of the nlDiscountPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setNlDiscountPercentage(JAXBElement<BigDecimal> value) {
        this.nlDiscountPercentage = value;
    }

    /**
     * Gets the value of the nlDiscountReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNlDiscountReasonCode() {
        return nlDiscountReasonCode;
    }

    /**
     * Sets the value of the nlDiscountReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNlDiscountReasonCode(JAXBElement<String> value) {
        this.nlDiscountReasonCode = value;
    }

    /**
     * Gets the value of the enableNlBillXtnsnFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getEnableNlBillXtnsnFlag() {
        return enableNlBillXtnsnFlag;
    }

    /**
     * Sets the value of the enableNlBillXtnsnFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setEnableNlBillXtnsnFlag(JAXBElement<Boolean> value) {
        this.enableNlBillXtnsnFlag = value;
    }

    /**
     * Gets the value of the burdenSchId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBurdenSchId() {
        return burdenSchId;
    }

    /**
     * Sets the value of the burdenSchId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBurdenSchId(JAXBElement<Long> value) {
        this.burdenSchId = value;
    }

    /**
     * Gets the value of the burdenSchFixedDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getBurdenSchFixedDate() {
        return burdenSchFixedDate;
    }

    /**
     * Sets the value of the burdenSchFixedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setBurdenSchFixedDate(JAXBElement<XMLGregorianCalendar> value) {
        this.burdenSchFixedDate = value;
    }

    /**
     * Gets the value of the laborTpScheduleId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLaborTpScheduleId() {
        return laborTpScheduleId;
    }

    /**
     * Sets the value of the laborTpScheduleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLaborTpScheduleId(JAXBElement<Long> value) {
        this.laborTpScheduleId = value;
    }

    /**
     * Gets the value of the laborTpSchFixedDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLaborTpSchFixedDate() {
        return laborTpSchFixedDate;
    }

    /**
     * Sets the value of the laborTpSchFixedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLaborTpSchFixedDate(JAXBElement<XMLGregorianCalendar> value) {
        this.laborTpSchFixedDate = value;
    }

    /**
     * Gets the value of the nlTpScheduleId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getNlTpScheduleId() {
        return nlTpScheduleId;
    }

    /**
     * Sets the value of the nlTpScheduleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setNlTpScheduleId(JAXBElement<Long> value) {
        this.nlTpScheduleId = value;
    }

    /**
     * Gets the value of the nlTpSchFixedDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getNlTpSchFixedDate() {
        return nlTpSchFixedDate;
    }

    /**
     * Sets the value of the nlTpSchFixedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setNlTpSchFixedDate(JAXBElement<XMLGregorianCalendar> value) {
        this.nlTpSchFixedDate = value;
    }

    /**
     * Gets the value of the onHoldFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getOnHoldFlag() {
        return onHoldFlag;
    }

    /**
     * Sets the value of the onHoldFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setOnHoldFlag(JAXBElement<Boolean> value) {
        this.onHoldFlag = value;
    }

    /**
     * Gets the value of the externalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalSourceKey() {
        return externalSourceKey;
    }

    /**
     * Sets the value of the externalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalSourceKey(JAXBElement<String> value) {
        this.externalSourceKey = value;
    }

    /**
     * Gets the value of the externalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getExternalReferenceKey() {
        return externalReferenceKey;
    }

    /**
     * Sets the value of the externalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setExternalReferenceKey(JAXBElement<String> value) {
        this.externalReferenceKey = value;
    }

    /**
     * Gets the value of the invoiceCurrDateType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceCurrDateType() {
        return invoiceCurrDateType;
    }

    /**
     * Sets the value of the invoiceCurrDateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceCurrDateType(JAXBElement<String> value) {
        this.invoiceCurrDateType = value;
    }

    /**
     * Gets the value of the invoiceCurrExchgDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getInvoiceCurrExchgDate() {
        return invoiceCurrExchgDate;
    }

    /**
     * Sets the value of the invoiceCurrExchgDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setInvoiceCurrExchgDate(JAXBElement<XMLGregorianCalendar> value) {
        this.invoiceCurrExchgDate = value;
    }

    /**
     * Gets the value of the invoiceCurrRateType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceCurrRateType() {
        return invoiceCurrRateType;
    }

    /**
     * Sets the value of the invoiceCurrRateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceCurrRateType(JAXBElement<String> value) {
        this.invoiceCurrRateType = value;
    }

    /**
     * Gets the value of the invoiceCurrencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceCurrencyCode() {
        return invoiceCurrencyCode;
    }

    /**
     * Sets the value of the invoiceCurrencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceCurrencyCode(JAXBElement<String> value) {
        this.invoiceCurrencyCode = value;
    }

    /**
     * Gets the value of the nlBillBasisCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNlBillBasisCode() {
        return nlBillBasisCode;
    }

    /**
     * Sets the value of the nlBillBasisCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNlBillBasisCode(JAXBElement<String> value) {
        this.nlBillBasisCode = value;
    }

    /**
     * Gets the value of the laborBillBasisCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLaborBillBasisCode() {
        return laborBillBasisCode;
    }

    /**
     * Sets the value of the laborBillBasisCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLaborBillBasisCode(JAXBElement<String> value) {
        this.laborBillBasisCode = value;
    }

    /**
     * Gets the value of the laborMarkupPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getLaborMarkupPercentage() {
        return laborMarkupPercentage;
    }

    /**
     * Sets the value of the laborMarkupPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setLaborMarkupPercentage(JAXBElement<BigDecimal> value) {
        this.laborMarkupPercentage = value;
    }

    /**
     * Gets the value of the nlMarkupPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getNlMarkupPercentage() {
        return nlMarkupPercentage;
    }

    /**
     * Sets the value of the nlMarkupPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setNlMarkupPercentage(JAXBElement<BigDecimal> value) {
        this.nlMarkupPercentage = value;
    }

    /**
     * Gets the value of the docNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDocNumber() {
        return docNumber;
    }

    /**
     * Sets the value of the docNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDocNumber(JAXBElement<String> value) {
        this.docNumber = value;
    }

    /**
     * Gets the value of the locFlag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getLocFlag() {
        return locFlag;
    }

    /**
     * Sets the value of the locFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setLocFlag(JAXBElement<Boolean> value) {
        this.locFlag = value;
    }

    /**
     * Gets the value of the reportTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getReportTypeCode() {
        return reportTypeCode;
    }

    /**
     * Sets the value of the reportTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setReportTypeCode(JAXBElement<String> value) {
        this.reportTypeCode = value;
    }

    /**
     * Gets the value of the assignmentDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assignmentDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssignmentDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssignmentDetail }
     * 
     * 
     */
    public List<AssignmentDetail> getAssignmentDetail() {
        if (assignmentDetail == null) {
            assignmentDetail = new ArrayList<AssignmentDetail>();
        }
        return this.assignmentDetail;
    }

    /**
     * Gets the value of the jobAssignmentOverride property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the jobAssignmentOverride property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getJobAssignmentOverride().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JobAssignmentOverride }
     * 
     * 
     */
    public List<JobAssignmentOverride> getJobAssignmentOverride() {
        if (jobAssignmentOverride == null) {
            jobAssignmentOverride = new ArrayList<JobAssignmentOverride>();
        }
        return this.jobAssignmentOverride;
    }

    /**
     * Gets the value of the jobTitleOverride property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the jobTitleOverride property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getJobTitleOverride().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JobTitleOverride }
     * 
     * 
     */
    public List<JobTitleOverride> getJobTitleOverride() {
        if (jobTitleOverride == null) {
            jobTitleOverride = new ArrayList<JobTitleOverride>();
        }
        return this.jobTitleOverride;
    }

    /**
     * Gets the value of the laborMultiplierOverride property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the laborMultiplierOverride property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLaborMultiplierOverride().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LaborMultiplierOverride }
     * 
     * 
     */
    public List<LaborMultiplierOverride> getLaborMultiplierOverride() {
        if (laborMultiplierOverride == null) {
            laborMultiplierOverride = new ArrayList<LaborMultiplierOverride>();
        }
        return this.laborMultiplierOverride;
    }

    /**
     * Gets the value of the nonLaborRateOverride property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nonLaborRateOverride property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNonLaborRateOverride().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NonLaborRateOverride }
     * 
     * 
     */
    public List<NonLaborRateOverride> getNonLaborRateOverride() {
        if (nonLaborRateOverride == null) {
            nonLaborRateOverride = new ArrayList<NonLaborRateOverride>();
        }
        return this.nonLaborRateOverride;
    }

    /**
     * Gets the value of the personRateOverride property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the personRateOverride property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPersonRateOverride().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonRateOverride }
     * 
     * 
     */
    public List<PersonRateOverride> getPersonRateOverride() {
        if (personRateOverride == null) {
            personRateOverride = new ArrayList<PersonRateOverride>();
        }
        return this.personRateOverride;
    }

    /**
     * Gets the value of the billPlanDescriptiveFlexField property.
     * 
     * @return
     *     possible object is
     *     {@link BilllPlanDff }
     *     
     */
    public BilllPlanDff getBillPlanDescriptiveFlexField() {
        return billPlanDescriptiveFlexField;
    }

    /**
     * Sets the value of the billPlanDescriptiveFlexField property.
     * 
     * @param value
     *     allowed object is
     *     {@link BilllPlanDff }
     *     
     */
    public void setBillPlanDescriptiveFlexField(BilllPlanDff value) {
        this.billPlanDescriptiveFlexField = value;
    }

    /**
     * Gets the value of the billPlanTranslation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the billPlanTranslation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBillPlanTranslation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BillPlanTranslation }
     * 
     * 
     */
    public List<BillPlanTranslation> getBillPlanTranslation() {
        if (billPlanTranslation == null) {
            billPlanTranslation = new ArrayList<BillPlanTranslation>();
        }
        return this.billPlanTranslation;
    }

    /**
     * Gets the value of the jobRateOverride property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the jobRateOverride property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getJobRateOverride().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JobRateOverride }
     * 
     * 
     */
    public List<JobRateOverride> getJobRateOverride() {
        if (jobRateOverride == null) {
            jobRateOverride = new ArrayList<JobRateOverride>();
        }
        return this.jobRateOverride;
    }

}
