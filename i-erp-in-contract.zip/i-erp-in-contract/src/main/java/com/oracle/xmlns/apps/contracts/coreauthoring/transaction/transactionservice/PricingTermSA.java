
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.oracle.xmlns.adf.svc.types.AmountType;


/**
 * <p>Java class for PricingTermSA complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PricingTermSA"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AdjustmentTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Adjustment" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="AdjustmentBasisCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AllowCustomAdjustmentsFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="CleId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="DnzChrId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="EndDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="ListPrice" type="{http://xmlns.oracle.com/adf/svc/types/}AmountType" minOccurs="0"/&gt;
 *         &lt;element name="MajorVersion" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="PricingTermId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="StartDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date" minOccurs="0"/&gt;
 *         &lt;element name="TierLineSA" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}TierLineSA" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PricingTermSA", propOrder = {
    "adjustmentTypeCode",
    "adjustment",
    "adjustmentBasisCode",
    "allowCustomAdjustmentsFlag",
    "cleId",
    "dnzChrId",
    "endDate",
    "listPrice",
    "majorVersion",
    "pricingTermId",
    "startDate",
    "tierLineSA"
})
public class PricingTermSA {

    @XmlElement(name = "AdjustmentTypeCode")
    protected String adjustmentTypeCode;
    @XmlElementRef(name = "Adjustment", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> adjustment;
    @XmlElementRef(name = "AdjustmentBasisCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> adjustmentBasisCode;
    @XmlElement(name = "AllowCustomAdjustmentsFlag")
    protected Boolean allowCustomAdjustmentsFlag;
    @XmlElementRef(name = "CleId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> cleId;
    @XmlElement(name = "DnzChrId")
    protected Long dnzChrId;
    @XmlElementRef(name = "EndDate", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> endDate;
    @XmlElementRef(name = "ListPrice", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<AmountType> listPrice;
    @XmlElement(name = "MajorVersion")
    protected Long majorVersion;
    @XmlElement(name = "PricingTermId")
    protected Long pricingTermId;
    @XmlElement(name = "StartDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar startDate;
    @XmlElement(name = "TierLineSA")
    protected List<TierLineSA> tierLineSA;

    /**
     * Gets the value of the adjustmentTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdjustmentTypeCode() {
        return adjustmentTypeCode;
    }

    /**
     * Sets the value of the adjustmentTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdjustmentTypeCode(String value) {
        this.adjustmentTypeCode = value;
    }

    /**
     * Gets the value of the adjustment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getAdjustment() {
        return adjustment;
    }

    /**
     * Sets the value of the adjustment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setAdjustment(JAXBElement<BigDecimal> value) {
        this.adjustment = value;
    }

    /**
     * Gets the value of the adjustmentBasisCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAdjustmentBasisCode() {
        return adjustmentBasisCode;
    }

    /**
     * Sets the value of the adjustmentBasisCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAdjustmentBasisCode(JAXBElement<String> value) {
        this.adjustmentBasisCode = value;
    }

    /**
     * Gets the value of the allowCustomAdjustmentsFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAllowCustomAdjustmentsFlag() {
        return allowCustomAdjustmentsFlag;
    }

    /**
     * Sets the value of the allowCustomAdjustmentsFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAllowCustomAdjustmentsFlag(Boolean value) {
        this.allowCustomAdjustmentsFlag = value;
    }

    /**
     * Gets the value of the cleId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCleId() {
        return cleId;
    }

    /**
     * Sets the value of the cleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCleId(JAXBElement<Long> value) {
        this.cleId = value;
    }

    /**
     * Gets the value of the dnzChrId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDnzChrId() {
        return dnzChrId;
    }

    /**
     * Sets the value of the dnzChrId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDnzChrId(Long value) {
        this.dnzChrId = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setEndDate(JAXBElement<XMLGregorianCalendar> value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the listPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public JAXBElement<AmountType> getListPrice() {
        return listPrice;
    }

    /**
     * Sets the value of the listPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AmountType }{@code >}
     *     
     */
    public void setListPrice(JAXBElement<AmountType> value) {
        this.listPrice = value;
    }

    /**
     * Gets the value of the majorVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMajorVersion() {
        return majorVersion;
    }

    /**
     * Sets the value of the majorVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMajorVersion(Long value) {
        this.majorVersion = value;
    }

    /**
     * Gets the value of the pricingTermId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getPricingTermId() {
        return pricingTermId;
    }

    /**
     * Sets the value of the pricingTermId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setPricingTermId(Long value) {
        this.pricingTermId = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDate(XMLGregorianCalendar value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the tierLineSA property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tierLineSA property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTierLineSA().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TierLineSA }
     * 
     * 
     */
    public List<TierLineSA> getTierLineSA() {
        if (tierLineSA == null) {
            tierLineSA = new ArrayList<TierLineSA>();
        }
        return this.tierLineSA;
    }

}
