
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.adf.svc.types.MeasureType;


/**
 * <p>Java class for SalesAgreementLineSA complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SalesAgreementLineSA"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractLine"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PriceListId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AllowPricelistOverrideYn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MinReleaseQuantity" type="{http://xmlns.oracle.com/adf/svc/types/}MeasureType" minOccurs="0"/&gt;
 *         &lt;element name="CommittedQuantity" type="{http://xmlns.oracle.com/adf/svc/types/}MeasureType" minOccurs="0"/&gt;
 *         &lt;element name="CommitLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PricingTermSA" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}PricingTermSA" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SalesAgreementLineSA", propOrder = {
    "priceListId",
    "allowPricelistOverrideYn",
    "minReleaseQuantity",
    "committedQuantity",
    "commitLevelCode",
    "pricingTermSA"
})
public class SalesAgreementLineSA
    extends ContractLine
{

    @XmlElementRef(name = "PriceListId", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> priceListId;
    @XmlElementRef(name = "AllowPricelistOverrideYn", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> allowPricelistOverrideYn;
    @XmlElementRef(name = "MinReleaseQuantity", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<MeasureType> minReleaseQuantity;
    @XmlElementRef(name = "CommittedQuantity", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<MeasureType> committedQuantity;
    @XmlElementRef(name = "CommitLevelCode", namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> commitLevelCode;
    @XmlElement(name = "PricingTermSA")
    protected List<PricingTermSA> pricingTermSA;

    /**
     * Gets the value of the priceListId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPriceListId() {
        return priceListId;
    }

    /**
     * Sets the value of the priceListId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPriceListId(JAXBElement<String> value) {
        this.priceListId = value;
    }

    /**
     * Gets the value of the allowPricelistOverrideYn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAllowPricelistOverrideYn() {
        return allowPricelistOverrideYn;
    }

    /**
     * Sets the value of the allowPricelistOverrideYn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAllowPricelistOverrideYn(JAXBElement<String> value) {
        this.allowPricelistOverrideYn = value;
    }

    /**
     * Gets the value of the minReleaseQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public JAXBElement<MeasureType> getMinReleaseQuantity() {
        return minReleaseQuantity;
    }

    /**
     * Sets the value of the minReleaseQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public void setMinReleaseQuantity(JAXBElement<MeasureType> value) {
        this.minReleaseQuantity = value;
    }

    /**
     * Gets the value of the committedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public JAXBElement<MeasureType> getCommittedQuantity() {
        return committedQuantity;
    }

    /**
     * Sets the value of the committedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MeasureType }{@code >}
     *     
     */
    public void setCommittedQuantity(JAXBElement<MeasureType> value) {
        this.committedQuantity = value;
    }

    /**
     * Gets the value of the commitLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCommitLevelCode() {
        return commitLevelCode;
    }

    /**
     * Sets the value of the commitLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCommitLevelCode(JAXBElement<String> value) {
        this.commitLevelCode = value;
    }

    /**
     * Gets the value of the pricingTermSA property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pricingTermSA property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPricingTermSA().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PricingTermSA }
     * 
     * 
     */
    public List<PricingTermSA> getPricingTermSA() {
        if (pricingTermSA == null) {
            pricingTermSA = new ArrayList<PricingTermSA>();
        }
        return this.pricingTermSA;
    }

}
