
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="majorVersion" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="externalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="externalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="deleteAllVersions" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "id",
    "majorVersion",
    "externalSourceKey",
    "externalReferenceKey",
    "deleteAllVersions"
})
@XmlRootElement(name = "deleteContractAsync")
public class DeleteContractAsync {

    protected long id;
    protected long majorVersion;
    @XmlElement(required = true)
    protected String externalSourceKey;
    @XmlElement(required = true)
    protected String externalReferenceKey;
    protected boolean deleteAllVersions;

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the majorVersion property.
     * 
     */
    public long getMajorVersion() {
        return majorVersion;
    }

    /**
     * Sets the value of the majorVersion property.
     * 
     */
    public void setMajorVersion(long value) {
        this.majorVersion = value;
    }

    /**
     * Gets the value of the externalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalSourceKey() {
        return externalSourceKey;
    }

    /**
     * Sets the value of the externalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalSourceKey(String value) {
        this.externalSourceKey = value;
    }

    /**
     * Gets the value of the externalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalReferenceKey() {
        return externalReferenceKey;
    }

    /**
     * Sets the value of the externalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalReferenceKey(String value) {
        this.externalReferenceKey = value;
    }

    /**
     * Gets the value of the deleteAllVersions property.
     * 
     */
    public boolean isDeleteAllVersions() {
        return deleteAllVersions;
    }

    /**
     * Sets the value of the deleteAllVersions property.
     * 
     */
    public void setDeleteAllVersions(boolean value) {
        this.deleteAllVersions = value;
    }

}
