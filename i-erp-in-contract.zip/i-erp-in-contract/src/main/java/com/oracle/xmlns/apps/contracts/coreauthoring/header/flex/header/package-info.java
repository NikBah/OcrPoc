@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/contracts/coreAuthoring/header/flex/header/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.apps.contracts.coreauthoring.header.flex.header;
