
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="contractId" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="lineId" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="headerExternalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="headerExternalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="lineExternalSourceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="lineExternalReferenceKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="holdUntilDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date"/&gt;
 *         &lt;element name="holdReasonCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="applyHldRsnSetId" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "contractId",
    "lineId",
    "headerExternalSourceKey",
    "headerExternalReferenceKey",
    "lineExternalSourceKey",
    "lineExternalReferenceKey",
    "holdUntilDate",
    "holdReasonCode",
    "applyHldRsnSetId"
})
@XmlRootElement(name = "applyHoldOnContractUsingSetId")
public class ApplyHoldOnContractUsingSetId {

    protected long contractId;
    protected long lineId;
    @XmlElement(required = true)
    protected String headerExternalSourceKey;
    @XmlElement(required = true)
    protected String headerExternalReferenceKey;
    @XmlElement(required = true)
    protected String lineExternalSourceKey;
    @XmlElement(required = true)
    protected String lineExternalReferenceKey;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar holdUntilDate;
    @XmlElement(required = true)
    protected String holdReasonCode;
    protected long applyHldRsnSetId;

    /**
     * Gets the value of the contractId property.
     * 
     */
    public long getContractId() {
        return contractId;
    }

    /**
     * Sets the value of the contractId property.
     * 
     */
    public void setContractId(long value) {
        this.contractId = value;
    }

    /**
     * Gets the value of the lineId property.
     * 
     */
    public long getLineId() {
        return lineId;
    }

    /**
     * Sets the value of the lineId property.
     * 
     */
    public void setLineId(long value) {
        this.lineId = value;
    }

    /**
     * Gets the value of the headerExternalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeaderExternalSourceKey() {
        return headerExternalSourceKey;
    }

    /**
     * Sets the value of the headerExternalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeaderExternalSourceKey(String value) {
        this.headerExternalSourceKey = value;
    }

    /**
     * Gets the value of the headerExternalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeaderExternalReferenceKey() {
        return headerExternalReferenceKey;
    }

    /**
     * Sets the value of the headerExternalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeaderExternalReferenceKey(String value) {
        this.headerExternalReferenceKey = value;
    }

    /**
     * Gets the value of the lineExternalSourceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineExternalSourceKey() {
        return lineExternalSourceKey;
    }

    /**
     * Sets the value of the lineExternalSourceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineExternalSourceKey(String value) {
        this.lineExternalSourceKey = value;
    }

    /**
     * Gets the value of the lineExternalReferenceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineExternalReferenceKey() {
        return lineExternalReferenceKey;
    }

    /**
     * Sets the value of the lineExternalReferenceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineExternalReferenceKey(String value) {
        this.lineExternalReferenceKey = value;
    }

    /**
     * Gets the value of the holdUntilDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getHoldUntilDate() {
        return holdUntilDate;
    }

    /**
     * Sets the value of the holdUntilDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setHoldUntilDate(XMLGregorianCalendar value) {
        this.holdUntilDate = value;
    }

    /**
     * Gets the value of the holdReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldReasonCode() {
        return holdReasonCode;
    }

    /**
     * Sets the value of the holdReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldReasonCode(String value) {
        this.holdReasonCode = value;
    }

    /**
     * Gets the value of the applyHldRsnSetId property.
     * 
     */
    public long getApplyHldRsnSetId() {
        return applyHldRsnSetId;
    }

    /**
     * Sets the value of the applyHldRsnSetId property.
     * 
     */
    public void setApplyHldRsnSetId(long value) {
        this.applyHldRsnSetId = value;
    }

}
