
package com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractHeader;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="contractHeader" type="{http://xmlns.oracle.com/apps/contracts/coreAuthoring/transaction/transactionService/}ContractHeader"/&gt;
 *         &lt;element name="targetStatusCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="closeDate" type="{http://xmlns.oracle.com/adf/svc/types/}date-Date"/&gt;
 *         &lt;element name="closeReasonCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="cancelReasonCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="versionFlag" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "contractHeader",
    "targetStatusCode",
    "closeDate",
    "closeReasonCode",
    "cancelReasonCode",
    "versionFlag"
})
@XmlRootElement(name = "mergeContractInAllStatus")
public class MergeContractInAllStatus {

    @XmlElement(required = true)
    protected ContractHeader contractHeader;
    @XmlElement(required = true)
    protected String targetStatusCode;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar closeDate;
    @XmlElement(required = true)
    protected String closeReasonCode;
    @XmlElement(required = true)
    protected String cancelReasonCode;
    protected boolean versionFlag;

    /**
     * Gets the value of the contractHeader property.
     * 
     * @return
     *     possible object is
     *     {@link ContractHeader }
     *     
     */
    public ContractHeader getContractHeader() {
        return contractHeader;
    }

    /**
     * Sets the value of the contractHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContractHeader }
     *     
     */
    public void setContractHeader(ContractHeader value) {
        this.contractHeader = value;
    }

    /**
     * Gets the value of the targetStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetStatusCode() {
        return targetStatusCode;
    }

    /**
     * Sets the value of the targetStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetStatusCode(String value) {
        this.targetStatusCode = value;
    }

    /**
     * Gets the value of the closeDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCloseDate() {
        return closeDate;
    }

    /**
     * Sets the value of the closeDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCloseDate(XMLGregorianCalendar value) {
        this.closeDate = value;
    }

    /**
     * Gets the value of the closeReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCloseReasonCode() {
        return closeReasonCode;
    }

    /**
     * Sets the value of the closeReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCloseReasonCode(String value) {
        this.closeReasonCode = value;
    }

    /**
     * Gets the value of the cancelReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelReasonCode() {
        return cancelReasonCode;
    }

    /**
     * Sets the value of the cancelReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelReasonCode(String value) {
        this.cancelReasonCode = value;
    }

    /**
     * Gets the value of the versionFlag property.
     * 
     */
    public boolean isVersionFlag() {
        return versionFlag;
    }

    /**
     * Sets the value of the versionFlag property.
     * 
     */
    public void setVersionFlag(boolean value) {
        this.versionFlag = value;
    }

}
