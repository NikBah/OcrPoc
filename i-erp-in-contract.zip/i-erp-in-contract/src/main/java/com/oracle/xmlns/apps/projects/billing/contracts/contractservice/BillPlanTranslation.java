
package com.oracle.xmlns.apps.projects.billing.contracts.contractservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BillPlanTranslation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillPlanTranslation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BillPlanId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="MajorVersion" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="Language" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="BillPlanName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceComment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InvoiceInstructions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SourceLang" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillPlanTranslation", propOrder = {
    "billPlanId",
    "majorVersion",
    "language",
    "billPlanName",
    "invoiceComment",
    "invoiceInstructions",
    "sourceLang"
})
public class BillPlanTranslation {

    @XmlElementRef(name = "BillPlanId", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPlanId;
    @XmlElement(name = "MajorVersion")
    protected Long majorVersion;
    @XmlElement(name = "Language")
    protected String language;
    @XmlElement(name = "BillPlanName")
    protected String billPlanName;
    @XmlElementRef(name = "InvoiceComment", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceComment;
    @XmlElementRef(name = "InvoiceInstructions", namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invoiceInstructions;
    @XmlElement(name = "SourceLang")
    protected String sourceLang;

    /**
     * Gets the value of the billPlanId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPlanId() {
        return billPlanId;
    }

    /**
     * Sets the value of the billPlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPlanId(JAXBElement<Long> value) {
        this.billPlanId = value;
    }

    /**
     * Gets the value of the majorVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMajorVersion() {
        return majorVersion;
    }

    /**
     * Sets the value of the majorVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMajorVersion(Long value) {
        this.majorVersion = value;
    }

    /**
     * Gets the value of the language property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguage() {
        return language;
    }

    /**
     * Sets the value of the language property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguage(String value) {
        this.language = value;
    }

    /**
     * Gets the value of the billPlanName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillPlanName() {
        return billPlanName;
    }

    /**
     * Sets the value of the billPlanName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillPlanName(String value) {
        this.billPlanName = value;
    }

    /**
     * Gets the value of the invoiceComment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceComment() {
        return invoiceComment;
    }

    /**
     * Sets the value of the invoiceComment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceComment(JAXBElement<String> value) {
        this.invoiceComment = value;
    }

    /**
     * Gets the value of the invoiceInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvoiceInstructions() {
        return invoiceInstructions;
    }

    /**
     * Sets the value of the invoiceInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvoiceInstructions(JAXBElement<String> value) {
        this.invoiceInstructions = value;
    }

    /**
     * Gets the value of the sourceLang property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceLang() {
        return sourceLang;
    }

    /**
     * Sets the value of the sourceLang property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceLang(String value) {
        this.sourceLang = value;
    }

}
