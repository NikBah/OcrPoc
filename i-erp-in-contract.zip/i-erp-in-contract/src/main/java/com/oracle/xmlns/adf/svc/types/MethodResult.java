
package com.oracle.xmlns.adf.svc.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.oracle.xmlns.adf.svc.errors.ServiceMessage;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractHeaderResult;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractPartyAddressResult;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractPartyContactResult;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractPartyResult;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractRelatedDocumentResult;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.PricingTermSAResult;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.SalesCreditResult;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.TierLineSAResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.AssignmentDetailResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.AssociatedProjectResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.BillPlanResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.BillPlanTranslationResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.BillingControlResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.JobAssignmentOverrideResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.JobRateOverrideResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.JobTitleOverrideResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.LaborMultiplierOverrideResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.NonLaborRateOverrideResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.PersonRateOverrideResult;
import com.oracle.xmlns.apps.projects.billing.contracts.contractservice.RevenuePlanResult;


/**
 * <p>Java class for MethodResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MethodResult"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Message" type="{http://xmlns.oracle.com/adf/svc/errors/}ServiceMessage" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MethodResult", propOrder = {
    "message"
})
@XmlSeeAlso({
    ContractPartyAddressResult.class,
    TierLineSAResult.class,
    PricingTermSAResult.class,
    ContractPartyContactResult.class,
    ContractPartyResult.class,
    SalesCreditResult.class,
    ContractRelatedDocumentResult.class,
    ContractHeaderResult.class,
    BigDecimalResult.class,
    BigIntegerResult.class,
    BooleanResult.class,
    ByteResult.class,
    BytesResult.class,
    TimestampResult.class,
    TimeResult.class,
    DateResult.class,
    DoubleResult.class,
    FloatResult.class,
    IntegerResult.class,
    LongResult.class,
    ShortResult.class,
    StringResult.class,
    DataHandlerResult.class,
    DataObjectResult.class,
    BillingControlResult.class,
    LaborMultiplierOverrideResult.class,
    AssignmentDetailResult.class,
    JobAssignmentOverrideResult.class,
    JobTitleOverrideResult.class,
    NonLaborRateOverrideResult.class,
    PersonRateOverrideResult.class,
    BillPlanTranslationResult.class,
    JobRateOverrideResult.class,
    BillPlanResult.class,
    RevenuePlanResult.class,
    AssociatedProjectResult.class
})
public class MethodResult {

    @XmlElement(name = "Message")
    protected List<ServiceMessage> message;

    /**
     * Gets the value of the message property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the message property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMessage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ServiceMessage }
     * 
     * 
     */
    public List<ServiceMessage> getMessage() {
        if (message == null) {
            message = new ArrayList<ServiceMessage>();
        }
        return this.message;
    }

}
