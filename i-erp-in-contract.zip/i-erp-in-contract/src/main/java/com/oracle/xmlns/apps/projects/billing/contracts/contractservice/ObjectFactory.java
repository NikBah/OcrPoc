
package com.oracle.xmlns.apps.projects.billing.contracts.contractservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import com.oracle.xmlns.adf.svc.types.AmountType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.projects.billing.contracts.contractservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BillingControlResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "billingControlResult");
    private final static QName _BillingControl_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "billingControl");
    private final static QName _LaborMultiplierOverride_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "laborMultiplierOverride");
    private final static QName _LaborMultiplierOverrideResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "laborMultiplierOverrideResult");
    private final static QName _AssignmentDetailResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "assignmentDetailResult");
    private final static QName _AssignmentDetail_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "assignmentDetail");
    private final static QName _JobAssignmentOverrideResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "jobAssignmentOverrideResult");
    private final static QName _JobAssignmentOverride_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "jobAssignmentOverride");
    private final static QName _JobTitleOverride_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "jobTitleOverride");
    private final static QName _JobTitleOverrideResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "jobTitleOverrideResult");
    private final static QName _NonLaborRateOverrideResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "nonLaborRateOverrideResult");
    private final static QName _NonLaborRateOverride_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "nonLaborRateOverride");
    private final static QName _PersonRateOverrideResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "personRateOverrideResult");
    private final static QName _PersonRateOverride_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "personRateOverride");
    private final static QName _BillPlanTranslationResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "billPlanTranslationResult");
    private final static QName _BillPlanTranslation_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "billPlanTranslation");
    private final static QName _JobRateOverrideResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "jobRateOverrideResult");
    private final static QName _JobRateOverride_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "jobRateOverride");
    private final static QName _BillPlanResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "billPlanResult");
    private final static QName _BillPlan_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "billPlan");
    private final static QName _RevenuePlanResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "revenuePlanResult");
    private final static QName _RevenuePlan_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "revenuePlan");
    private final static QName _AssociatedProject_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "associatedProject");
    private final static QName _AssociatedProjectResult_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "associatedProjectResult");
    private final static QName _AssociatedProjectProjElementId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "ProjElementId");
    private final static QName _AssociatedProjectFundingAmount_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "FundingAmount");
    private final static QName _AssociatedProjectCurrencyCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "CurrencyCode");
    private final static QName _AssociatedProjectPercentComplete_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "PercentComplete");
    private final static QName _AssociatedProjectExternalSourceKey_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "ExternalSourceKey");
    private final static QName _AssociatedProjectExternalReferenceKey_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "ExternalReferenceKey");
    private final static QName _RevenuePlanEmpBillRateSchId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "EmpBillRateSchId");
    private final static QName _RevenuePlanJobBillRateSchId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "JobBillRateSchId");
    private final static QName _RevenuePlanLaborSchFixedDate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LaborSchFixedDate");
    private final static QName _RevenuePlanLaborDiscountPercentage_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LaborDiscountPercentage");
    private final static QName _RevenuePlanLaborDiscountReasonCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LaborDiscountReasonCode");
    private final static QName _RevenuePlanEnableLbrBillXtnsnFlag_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "EnableLbrBillXtnsnFlag");
    private final static QName _RevenuePlanNlBillRateSchId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlBillRateSchId");
    private final static QName _RevenuePlanNlSchFixedDate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlSchFixedDate");
    private final static QName _RevenuePlanNlDiscountPercentage_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlDiscountPercentage");
    private final static QName _RevenuePlanNlDiscountReasonCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlDiscountReasonCode");
    private final static QName _RevenuePlanEnableNlBillXtnsnFlag_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "EnableNlBillXtnsnFlag");
    private final static QName _RevenuePlanBurdenSchId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "BurdenSchId");
    private final static QName _RevenuePlanBurdenSchFixedDate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "BurdenSchFixedDate");
    private final static QName _RevenuePlanLaborTpScheduleId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LaborTpScheduleId");
    private final static QName _RevenuePlanLaborTpSchFixedDate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LaborTpSchFixedDate");
    private final static QName _RevenuePlanNlTpScheduleId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlTpScheduleId");
    private final static QName _RevenuePlanNlTpSchFixedDate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlTpSchFixedDate");
    private final static QName _RevenuePlanOnHoldFlag_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "OnHoldFlag");
    private final static QName _RevenuePlanLaborBillBasisCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LaborBillBasisCode");
    private final static QName _RevenuePlanLaborMarkupPercentage_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LaborMarkupPercentage");
    private final static QName _RevenuePlanNlBillBasisCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlBillBasisCode");
    private final static QName _RevenuePlanNlMarkupPercentage_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NlMarkupPercentage");
    private final static QName _BillPlanInvoiceCurrencyOptCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "InvoiceCurrencyOptCode");
    private final static QName _BillPlanFirstBillingOffsetDays_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "FirstBillingOffsetDays");
    private final static QName _BillPlanInvoiceInstructions_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "InvoiceInstructions");
    private final static QName _BillPlanInvoiceComment_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "InvoiceComment");
    private final static QName _BillPlanInvoiceCurrDateType_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "InvoiceCurrDateType");
    private final static QName _BillPlanInvoiceCurrExchgDate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "InvoiceCurrExchgDate");
    private final static QName _BillPlanInvoiceCurrRateType_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "InvoiceCurrRateType");
    private final static QName _BillPlanInvoiceCurrencyCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "InvoiceCurrencyCode");
    private final static QName _BillPlanDocNumber_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "DocNumber");
    private final static QName _BillPlanLocFlag_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "LocFlag");
    private final static QName _BillPlanReportTypeCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "ReportTypeCode");
    private final static QName _JobRateOverrideContractLineId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "ContractLineId");
    private final static QName _JobRateOverrideRate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "Rate");
    private final static QName _JobRateOverrideRateCurrencyCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "RateCurrencyCode");
    private final static QName _JobRateOverrideDiscountPercentage_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "DiscountPercentage");
    private final static QName _JobRateOverrideRateDiscReasonCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "RateDiscReasonCode");
    private final static QName _JobRateOverrideEndDateActive_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "EndDateActive");
    private final static QName _BillPlanTranslationBillPlanId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "BillPlanId");
    private final static QName _NonLaborRateOverrideNonLaborResourceId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "NonLaborResourceId");
    private final static QName _NonLaborRateOverrideOrganizationId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "OrganizationId");
    private final static QName _NonLaborRateOverrideMarkupPercentage_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "MarkupPercentage");
    private final static QName _JobAssignmentOverrideBillingTitle_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "BillingTitle");
    private final static QName _AssignmentDetailExtensionAmount_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "ExtensionAmount");
    private final static QName _AssignmentDetailPercentage_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "Percentage");
    private final static QName _BillingControlRbsElementId_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "RbsElementId");
    private final static QName _BillingControlEndDate_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "EndDate");
    private final static QName _BillingControlSoftLimitAmount_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "SoftLimitAmount");
    private final static QName _BillingControlSoftLimitCurrencyCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "SoftLimitCurrencyCode");
    private final static QName _BillingControlHardLimitAmount_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "HardLimitAmount");
    private final static QName _BillingControlHardLimitCurrencyCode_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "HardLimitCurrencyCode");
    private final static QName _BillingControlActiveFlag_QNAME = new QName("http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", "ActiveFlag");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.projects.billing.contracts.contractservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BillingControlResult }
     * 
     */
    public BillingControlResult createBillingControlResult() {
        return new BillingControlResult();
    }

    /**
     * Create an instance of {@link BillingControl }
     * 
     */
    public BillingControl createBillingControl() {
        return new BillingControl();
    }

    /**
     * Create an instance of {@link LaborMultiplierOverride }
     * 
     */
    public LaborMultiplierOverride createLaborMultiplierOverride() {
        return new LaborMultiplierOverride();
    }

    /**
     * Create an instance of {@link LaborMultiplierOverrideResult }
     * 
     */
    public LaborMultiplierOverrideResult createLaborMultiplierOverrideResult() {
        return new LaborMultiplierOverrideResult();
    }

    /**
     * Create an instance of {@link AssignmentDetailResult }
     * 
     */
    public AssignmentDetailResult createAssignmentDetailResult() {
        return new AssignmentDetailResult();
    }

    /**
     * Create an instance of {@link AssignmentDetail }
     * 
     */
    public AssignmentDetail createAssignmentDetail() {
        return new AssignmentDetail();
    }

    /**
     * Create an instance of {@link JobAssignmentOverrideResult }
     * 
     */
    public JobAssignmentOverrideResult createJobAssignmentOverrideResult() {
        return new JobAssignmentOverrideResult();
    }

    /**
     * Create an instance of {@link JobAssignmentOverride }
     * 
     */
    public JobAssignmentOverride createJobAssignmentOverride() {
        return new JobAssignmentOverride();
    }

    /**
     * Create an instance of {@link JobTitleOverride }
     * 
     */
    public JobTitleOverride createJobTitleOverride() {
        return new JobTitleOverride();
    }

    /**
     * Create an instance of {@link JobTitleOverrideResult }
     * 
     */
    public JobTitleOverrideResult createJobTitleOverrideResult() {
        return new JobTitleOverrideResult();
    }

    /**
     * Create an instance of {@link NonLaborRateOverrideResult }
     * 
     */
    public NonLaborRateOverrideResult createNonLaborRateOverrideResult() {
        return new NonLaborRateOverrideResult();
    }

    /**
     * Create an instance of {@link NonLaborRateOverride }
     * 
     */
    public NonLaborRateOverride createNonLaborRateOverride() {
        return new NonLaborRateOverride();
    }

    /**
     * Create an instance of {@link PersonRateOverrideResult }
     * 
     */
    public PersonRateOverrideResult createPersonRateOverrideResult() {
        return new PersonRateOverrideResult();
    }

    /**
     * Create an instance of {@link PersonRateOverride }
     * 
     */
    public PersonRateOverride createPersonRateOverride() {
        return new PersonRateOverride();
    }

    /**
     * Create an instance of {@link BillPlanTranslationResult }
     * 
     */
    public BillPlanTranslationResult createBillPlanTranslationResult() {
        return new BillPlanTranslationResult();
    }

    /**
     * Create an instance of {@link BillPlanTranslation }
     * 
     */
    public BillPlanTranslation createBillPlanTranslation() {
        return new BillPlanTranslation();
    }

    /**
     * Create an instance of {@link JobRateOverrideResult }
     * 
     */
    public JobRateOverrideResult createJobRateOverrideResult() {
        return new JobRateOverrideResult();
    }

    /**
     * Create an instance of {@link JobRateOverride }
     * 
     */
    public JobRateOverride createJobRateOverride() {
        return new JobRateOverride();
    }

    /**
     * Create an instance of {@link BillPlanResult }
     * 
     */
    public BillPlanResult createBillPlanResult() {
        return new BillPlanResult();
    }

    /**
     * Create an instance of {@link BillPlan }
     * 
     */
    public BillPlan createBillPlan() {
        return new BillPlan();
    }

    /**
     * Create an instance of {@link RevenuePlanResult }
     * 
     */
    public RevenuePlanResult createRevenuePlanResult() {
        return new RevenuePlanResult();
    }

    /**
     * Create an instance of {@link RevenuePlan }
     * 
     */
    public RevenuePlan createRevenuePlan() {
        return new RevenuePlan();
    }

    /**
     * Create an instance of {@link AssociatedProject }
     * 
     */
    public AssociatedProject createAssociatedProject() {
        return new AssociatedProject();
    }

    /**
     * Create an instance of {@link AssociatedProjectResult }
     * 
     */
    public AssociatedProjectResult createAssociatedProjectResult() {
        return new AssociatedProjectResult();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillingControlResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "billingControlResult")
    public JAXBElement<BillingControlResult> createBillingControlResult(BillingControlResult value) {
        return new JAXBElement<BillingControlResult>(_BillingControlResult_QNAME, BillingControlResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillingControl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "billingControl")
    public JAXBElement<BillingControl> createBillingControl(BillingControl value) {
        return new JAXBElement<BillingControl>(_BillingControl_QNAME, BillingControl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LaborMultiplierOverride }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "laborMultiplierOverride")
    public JAXBElement<LaborMultiplierOverride> createLaborMultiplierOverride(LaborMultiplierOverride value) {
        return new JAXBElement<LaborMultiplierOverride>(_LaborMultiplierOverride_QNAME, LaborMultiplierOverride.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LaborMultiplierOverrideResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "laborMultiplierOverrideResult")
    public JAXBElement<LaborMultiplierOverrideResult> createLaborMultiplierOverrideResult(LaborMultiplierOverrideResult value) {
        return new JAXBElement<LaborMultiplierOverrideResult>(_LaborMultiplierOverrideResult_QNAME, LaborMultiplierOverrideResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssignmentDetailResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "assignmentDetailResult")
    public JAXBElement<AssignmentDetailResult> createAssignmentDetailResult(AssignmentDetailResult value) {
        return new JAXBElement<AssignmentDetailResult>(_AssignmentDetailResult_QNAME, AssignmentDetailResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssignmentDetail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "assignmentDetail")
    public JAXBElement<AssignmentDetail> createAssignmentDetail(AssignmentDetail value) {
        return new JAXBElement<AssignmentDetail>(_AssignmentDetail_QNAME, AssignmentDetail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JobAssignmentOverrideResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "jobAssignmentOverrideResult")
    public JAXBElement<JobAssignmentOverrideResult> createJobAssignmentOverrideResult(JobAssignmentOverrideResult value) {
        return new JAXBElement<JobAssignmentOverrideResult>(_JobAssignmentOverrideResult_QNAME, JobAssignmentOverrideResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JobAssignmentOverride }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "jobAssignmentOverride")
    public JAXBElement<JobAssignmentOverride> createJobAssignmentOverride(JobAssignmentOverride value) {
        return new JAXBElement<JobAssignmentOverride>(_JobAssignmentOverride_QNAME, JobAssignmentOverride.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JobTitleOverride }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "jobTitleOverride")
    public JAXBElement<JobTitleOverride> createJobTitleOverride(JobTitleOverride value) {
        return new JAXBElement<JobTitleOverride>(_JobTitleOverride_QNAME, JobTitleOverride.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JobTitleOverrideResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "jobTitleOverrideResult")
    public JAXBElement<JobTitleOverrideResult> createJobTitleOverrideResult(JobTitleOverrideResult value) {
        return new JAXBElement<JobTitleOverrideResult>(_JobTitleOverrideResult_QNAME, JobTitleOverrideResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonLaborRateOverrideResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "nonLaborRateOverrideResult")
    public JAXBElement<NonLaborRateOverrideResult> createNonLaborRateOverrideResult(NonLaborRateOverrideResult value) {
        return new JAXBElement<NonLaborRateOverrideResult>(_NonLaborRateOverrideResult_QNAME, NonLaborRateOverrideResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NonLaborRateOverride }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "nonLaborRateOverride")
    public JAXBElement<NonLaborRateOverride> createNonLaborRateOverride(NonLaborRateOverride value) {
        return new JAXBElement<NonLaborRateOverride>(_NonLaborRateOverride_QNAME, NonLaborRateOverride.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersonRateOverrideResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "personRateOverrideResult")
    public JAXBElement<PersonRateOverrideResult> createPersonRateOverrideResult(PersonRateOverrideResult value) {
        return new JAXBElement<PersonRateOverrideResult>(_PersonRateOverrideResult_QNAME, PersonRateOverrideResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersonRateOverride }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "personRateOverride")
    public JAXBElement<PersonRateOverride> createPersonRateOverride(PersonRateOverride value) {
        return new JAXBElement<PersonRateOverride>(_PersonRateOverride_QNAME, PersonRateOverride.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillPlanTranslationResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "billPlanTranslationResult")
    public JAXBElement<BillPlanTranslationResult> createBillPlanTranslationResult(BillPlanTranslationResult value) {
        return new JAXBElement<BillPlanTranslationResult>(_BillPlanTranslationResult_QNAME, BillPlanTranslationResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillPlanTranslation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "billPlanTranslation")
    public JAXBElement<BillPlanTranslation> createBillPlanTranslation(BillPlanTranslation value) {
        return new JAXBElement<BillPlanTranslation>(_BillPlanTranslation_QNAME, BillPlanTranslation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JobRateOverrideResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "jobRateOverrideResult")
    public JAXBElement<JobRateOverrideResult> createJobRateOverrideResult(JobRateOverrideResult value) {
        return new JAXBElement<JobRateOverrideResult>(_JobRateOverrideResult_QNAME, JobRateOverrideResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link JobRateOverride }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "jobRateOverride")
    public JAXBElement<JobRateOverride> createJobRateOverride(JobRateOverride value) {
        return new JAXBElement<JobRateOverride>(_JobRateOverride_QNAME, JobRateOverride.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillPlanResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "billPlanResult")
    public JAXBElement<BillPlanResult> createBillPlanResult(BillPlanResult value) {
        return new JAXBElement<BillPlanResult>(_BillPlanResult_QNAME, BillPlanResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillPlan }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "billPlan")
    public JAXBElement<BillPlan> createBillPlan(BillPlan value) {
        return new JAXBElement<BillPlan>(_BillPlan_QNAME, BillPlan.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RevenuePlanResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "revenuePlanResult")
    public JAXBElement<RevenuePlanResult> createRevenuePlanResult(RevenuePlanResult value) {
        return new JAXBElement<RevenuePlanResult>(_RevenuePlanResult_QNAME, RevenuePlanResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RevenuePlan }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "revenuePlan")
    public JAXBElement<RevenuePlan> createRevenuePlan(RevenuePlan value) {
        return new JAXBElement<RevenuePlan>(_RevenuePlan_QNAME, RevenuePlan.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssociatedProject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "associatedProject")
    public JAXBElement<AssociatedProject> createAssociatedProject(AssociatedProject value) {
        return new JAXBElement<AssociatedProject>(_AssociatedProject_QNAME, AssociatedProject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssociatedProjectResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "associatedProjectResult")
    public JAXBElement<AssociatedProjectResult> createAssociatedProjectResult(AssociatedProjectResult value) {
        return new JAXBElement<AssociatedProjectResult>(_AssociatedProjectResult_QNAME, AssociatedProjectResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ProjElementId", scope = AssociatedProject.class)
    public JAXBElement<Long> createAssociatedProjectProjElementId(Long value) {
        return new JAXBElement<Long>(_AssociatedProjectProjElementId_QNAME, Long.class, AssociatedProject.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "FundingAmount", scope = AssociatedProject.class)
    public JAXBElement<AmountType> createAssociatedProjectFundingAmount(AmountType value) {
        return new JAXBElement<AmountType>(_AssociatedProjectFundingAmount_QNAME, AmountType.class, AssociatedProject.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "CurrencyCode", scope = AssociatedProject.class)
    public JAXBElement<String> createAssociatedProjectCurrencyCode(String value) {
        return new JAXBElement<String>(_AssociatedProjectCurrencyCode_QNAME, String.class, AssociatedProject.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "PercentComplete", scope = AssociatedProject.class)
    public JAXBElement<BigDecimal> createAssociatedProjectPercentComplete(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_AssociatedProjectPercentComplete_QNAME, BigDecimal.class, AssociatedProject.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = AssociatedProject.class)
    public JAXBElement<String> createAssociatedProjectExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, AssociatedProject.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = AssociatedProject.class)
    public JAXBElement<String> createAssociatedProjectExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, AssociatedProject.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EmpBillRateSchId", scope = RevenuePlan.class)
    public JAXBElement<Long> createRevenuePlanEmpBillRateSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanEmpBillRateSchId_QNAME, Long.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "JobBillRateSchId", scope = RevenuePlan.class)
    public JAXBElement<Long> createRevenuePlanJobBillRateSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanJobBillRateSchId_QNAME, Long.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborSchFixedDate", scope = RevenuePlan.class)
    public JAXBElement<XMLGregorianCalendar> createRevenuePlanLaborSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanLaborSchFixedDate_QNAME, XMLGregorianCalendar.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborDiscountPercentage", scope = RevenuePlan.class)
    public JAXBElement<BigDecimal> createRevenuePlanLaborDiscountPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanLaborDiscountPercentage_QNAME, BigDecimal.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborDiscountReasonCode", scope = RevenuePlan.class)
    public JAXBElement<String> createRevenuePlanLaborDiscountReasonCode(String value) {
        return new JAXBElement<String>(_RevenuePlanLaborDiscountReasonCode_QNAME, String.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EnableLbrBillXtnsnFlag", scope = RevenuePlan.class)
    public JAXBElement<Boolean> createRevenuePlanEnableLbrBillXtnsnFlag(Boolean value) {
        return new JAXBElement<Boolean>(_RevenuePlanEnableLbrBillXtnsnFlag_QNAME, Boolean.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlBillRateSchId", scope = RevenuePlan.class)
    public JAXBElement<Long> createRevenuePlanNlBillRateSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanNlBillRateSchId_QNAME, Long.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlSchFixedDate", scope = RevenuePlan.class)
    public JAXBElement<XMLGregorianCalendar> createRevenuePlanNlSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanNlSchFixedDate_QNAME, XMLGregorianCalendar.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlDiscountPercentage", scope = RevenuePlan.class)
    public JAXBElement<BigDecimal> createRevenuePlanNlDiscountPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanNlDiscountPercentage_QNAME, BigDecimal.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlDiscountReasonCode", scope = RevenuePlan.class)
    public JAXBElement<String> createRevenuePlanNlDiscountReasonCode(String value) {
        return new JAXBElement<String>(_RevenuePlanNlDiscountReasonCode_QNAME, String.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EnableNlBillXtnsnFlag", scope = RevenuePlan.class)
    public JAXBElement<Boolean> createRevenuePlanEnableNlBillXtnsnFlag(Boolean value) {
        return new JAXBElement<Boolean>(_RevenuePlanEnableNlBillXtnsnFlag_QNAME, Boolean.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "BurdenSchId", scope = RevenuePlan.class)
    public JAXBElement<Long> createRevenuePlanBurdenSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanBurdenSchId_QNAME, Long.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "BurdenSchFixedDate", scope = RevenuePlan.class)
    public JAXBElement<XMLGregorianCalendar> createRevenuePlanBurdenSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanBurdenSchFixedDate_QNAME, XMLGregorianCalendar.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborTpScheduleId", scope = RevenuePlan.class)
    public JAXBElement<Long> createRevenuePlanLaborTpScheduleId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanLaborTpScheduleId_QNAME, Long.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborTpSchFixedDate", scope = RevenuePlan.class)
    public JAXBElement<XMLGregorianCalendar> createRevenuePlanLaborTpSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanLaborTpSchFixedDate_QNAME, XMLGregorianCalendar.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlTpScheduleId", scope = RevenuePlan.class)
    public JAXBElement<Long> createRevenuePlanNlTpScheduleId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanNlTpScheduleId_QNAME, Long.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlTpSchFixedDate", scope = RevenuePlan.class)
    public JAXBElement<XMLGregorianCalendar> createRevenuePlanNlTpSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanNlTpSchFixedDate_QNAME, XMLGregorianCalendar.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "OnHoldFlag", scope = RevenuePlan.class)
    public JAXBElement<Boolean> createRevenuePlanOnHoldFlag(Boolean value) {
        return new JAXBElement<Boolean>(_RevenuePlanOnHoldFlag_QNAME, Boolean.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = RevenuePlan.class)
    public JAXBElement<String> createRevenuePlanExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = RevenuePlan.class)
    public JAXBElement<String> createRevenuePlanExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborBillBasisCode", scope = RevenuePlan.class)
    public JAXBElement<String> createRevenuePlanLaborBillBasisCode(String value) {
        return new JAXBElement<String>(_RevenuePlanLaborBillBasisCode_QNAME, String.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborMarkupPercentage", scope = RevenuePlan.class)
    public JAXBElement<BigDecimal> createRevenuePlanLaborMarkupPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanLaborMarkupPercentage_QNAME, BigDecimal.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlBillBasisCode", scope = RevenuePlan.class)
    public JAXBElement<String> createRevenuePlanNlBillBasisCode(String value) {
        return new JAXBElement<String>(_RevenuePlanNlBillBasisCode_QNAME, String.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlMarkupPercentage", scope = RevenuePlan.class)
    public JAXBElement<BigDecimal> createRevenuePlanNlMarkupPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanNlMarkupPercentage_QNAME, BigDecimal.class, RevenuePlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceCurrencyOptCode", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanInvoiceCurrencyOptCode(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceCurrencyOptCode_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "FirstBillingOffsetDays", scope = BillPlan.class)
    public JAXBElement<BigDecimal> createBillPlanFirstBillingOffsetDays(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BillPlanFirstBillingOffsetDays_QNAME, BigDecimal.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceInstructions", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanInvoiceInstructions(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceInstructions_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceComment", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanInvoiceComment(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceComment_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EmpBillRateSchId", scope = BillPlan.class)
    public JAXBElement<Long> createBillPlanEmpBillRateSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanEmpBillRateSchId_QNAME, Long.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "JobBillRateSchId", scope = BillPlan.class)
    public JAXBElement<Long> createBillPlanJobBillRateSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanJobBillRateSchId_QNAME, Long.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborSchFixedDate", scope = BillPlan.class)
    public JAXBElement<XMLGregorianCalendar> createBillPlanLaborSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanLaborSchFixedDate_QNAME, XMLGregorianCalendar.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborDiscountPercentage", scope = BillPlan.class)
    public JAXBElement<BigDecimal> createBillPlanLaborDiscountPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanLaborDiscountPercentage_QNAME, BigDecimal.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborDiscountReasonCode", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanLaborDiscountReasonCode(String value) {
        return new JAXBElement<String>(_RevenuePlanLaborDiscountReasonCode_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EnableLbrBillXtnsnFlag", scope = BillPlan.class)
    public JAXBElement<Boolean> createBillPlanEnableLbrBillXtnsnFlag(Boolean value) {
        return new JAXBElement<Boolean>(_RevenuePlanEnableLbrBillXtnsnFlag_QNAME, Boolean.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlBillRateSchId", scope = BillPlan.class)
    public JAXBElement<Long> createBillPlanNlBillRateSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanNlBillRateSchId_QNAME, Long.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlSchFixedDate", scope = BillPlan.class)
    public JAXBElement<XMLGregorianCalendar> createBillPlanNlSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanNlSchFixedDate_QNAME, XMLGregorianCalendar.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlDiscountPercentage", scope = BillPlan.class)
    public JAXBElement<BigDecimal> createBillPlanNlDiscountPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanNlDiscountPercentage_QNAME, BigDecimal.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlDiscountReasonCode", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanNlDiscountReasonCode(String value) {
        return new JAXBElement<String>(_RevenuePlanNlDiscountReasonCode_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EnableNlBillXtnsnFlag", scope = BillPlan.class)
    public JAXBElement<Boolean> createBillPlanEnableNlBillXtnsnFlag(Boolean value) {
        return new JAXBElement<Boolean>(_RevenuePlanEnableNlBillXtnsnFlag_QNAME, Boolean.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "BurdenSchId", scope = BillPlan.class)
    public JAXBElement<Long> createBillPlanBurdenSchId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanBurdenSchId_QNAME, Long.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "BurdenSchFixedDate", scope = BillPlan.class)
    public JAXBElement<XMLGregorianCalendar> createBillPlanBurdenSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanBurdenSchFixedDate_QNAME, XMLGregorianCalendar.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborTpScheduleId", scope = BillPlan.class)
    public JAXBElement<Long> createBillPlanLaborTpScheduleId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanLaborTpScheduleId_QNAME, Long.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborTpSchFixedDate", scope = BillPlan.class)
    public JAXBElement<XMLGregorianCalendar> createBillPlanLaborTpSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanLaborTpSchFixedDate_QNAME, XMLGregorianCalendar.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlTpScheduleId", scope = BillPlan.class)
    public JAXBElement<Long> createBillPlanNlTpScheduleId(Long value) {
        return new JAXBElement<Long>(_RevenuePlanNlTpScheduleId_QNAME, Long.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlTpSchFixedDate", scope = BillPlan.class)
    public JAXBElement<XMLGregorianCalendar> createBillPlanNlTpSchFixedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_RevenuePlanNlTpSchFixedDate_QNAME, XMLGregorianCalendar.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "OnHoldFlag", scope = BillPlan.class)
    public JAXBElement<Boolean> createBillPlanOnHoldFlag(Boolean value) {
        return new JAXBElement<Boolean>(_RevenuePlanOnHoldFlag_QNAME, Boolean.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceCurrDateType", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanInvoiceCurrDateType(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceCurrDateType_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceCurrExchgDate", scope = BillPlan.class)
    public JAXBElement<XMLGregorianCalendar> createBillPlanInvoiceCurrExchgDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_BillPlanInvoiceCurrExchgDate_QNAME, XMLGregorianCalendar.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceCurrRateType", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanInvoiceCurrRateType(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceCurrRateType_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceCurrencyCode", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanInvoiceCurrencyCode(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceCurrencyCode_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlBillBasisCode", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanNlBillBasisCode(String value) {
        return new JAXBElement<String>(_RevenuePlanNlBillBasisCode_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborBillBasisCode", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanLaborBillBasisCode(String value) {
        return new JAXBElement<String>(_RevenuePlanLaborBillBasisCode_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LaborMarkupPercentage", scope = BillPlan.class)
    public JAXBElement<BigDecimal> createBillPlanLaborMarkupPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanLaborMarkupPercentage_QNAME, BigDecimal.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NlMarkupPercentage", scope = BillPlan.class)
    public JAXBElement<BigDecimal> createBillPlanNlMarkupPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RevenuePlanNlMarkupPercentage_QNAME, BigDecimal.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "DocNumber", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanDocNumber(String value) {
        return new JAXBElement<String>(_BillPlanDocNumber_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "LocFlag", scope = BillPlan.class)
    public JAXBElement<Boolean> createBillPlanLocFlag(Boolean value) {
        return new JAXBElement<Boolean>(_BillPlanLocFlag_QNAME, Boolean.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ReportTypeCode", scope = BillPlan.class)
    public JAXBElement<String> createBillPlanReportTypeCode(String value) {
        return new JAXBElement<String>(_BillPlanReportTypeCode_QNAME, String.class, BillPlan.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ContractLineId", scope = JobRateOverride.class)
    public JAXBElement<Long> createJobRateOverrideContractLineId(Long value) {
        return new JAXBElement<Long>(_JobRateOverrideContractLineId_QNAME, Long.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "Rate", scope = JobRateOverride.class)
    public JAXBElement<BigDecimal> createJobRateOverrideRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_JobRateOverrideRate_QNAME, BigDecimal.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "RateCurrencyCode", scope = JobRateOverride.class)
    public JAXBElement<String> createJobRateOverrideRateCurrencyCode(String value) {
        return new JAXBElement<String>(_JobRateOverrideRateCurrencyCode_QNAME, String.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "DiscountPercentage", scope = JobRateOverride.class)
    public JAXBElement<BigDecimal> createJobRateOverrideDiscountPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_JobRateOverrideDiscountPercentage_QNAME, BigDecimal.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "RateDiscReasonCode", scope = JobRateOverride.class)
    public JAXBElement<String> createJobRateOverrideRateDiscReasonCode(String value) {
        return new JAXBElement<String>(_JobRateOverrideRateDiscReasonCode_QNAME, String.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EndDateActive", scope = JobRateOverride.class)
    public JAXBElement<XMLGregorianCalendar> createJobRateOverrideEndDateActive(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_JobRateOverrideEndDateActive_QNAME, XMLGregorianCalendar.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = JobRateOverride.class)
    public JAXBElement<String> createJobRateOverrideExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = JobRateOverride.class)
    public JAXBElement<String> createJobRateOverrideExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, JobRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "BillPlanId", scope = BillPlanTranslation.class)
    public JAXBElement<Long> createBillPlanTranslationBillPlanId(Long value) {
        return new JAXBElement<Long>(_BillPlanTranslationBillPlanId_QNAME, Long.class, BillPlanTranslation.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceComment", scope = BillPlanTranslation.class)
    public JAXBElement<String> createBillPlanTranslationInvoiceComment(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceComment_QNAME, String.class, BillPlanTranslation.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "InvoiceInstructions", scope = BillPlanTranslation.class)
    public JAXBElement<String> createBillPlanTranslationInvoiceInstructions(String value) {
        return new JAXBElement<String>(_BillPlanInvoiceInstructions_QNAME, String.class, BillPlanTranslation.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ContractLineId", scope = PersonRateOverride.class)
    public JAXBElement<Long> createPersonRateOverrideContractLineId(Long value) {
        return new JAXBElement<Long>(_JobRateOverrideContractLineId_QNAME, Long.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "Rate", scope = PersonRateOverride.class)
    public JAXBElement<BigDecimal> createPersonRateOverrideRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_JobRateOverrideRate_QNAME, BigDecimal.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "RateCurrencyCode", scope = PersonRateOverride.class)
    public JAXBElement<String> createPersonRateOverrideRateCurrencyCode(String value) {
        return new JAXBElement<String>(_JobRateOverrideRateCurrencyCode_QNAME, String.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "DiscountPercentage", scope = PersonRateOverride.class)
    public JAXBElement<BigDecimal> createPersonRateOverrideDiscountPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_JobRateOverrideDiscountPercentage_QNAME, BigDecimal.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "RateDiscReasonCode", scope = PersonRateOverride.class)
    public JAXBElement<String> createPersonRateOverrideRateDiscReasonCode(String value) {
        return new JAXBElement<String>(_JobRateOverrideRateDiscReasonCode_QNAME, String.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EndDateActive", scope = PersonRateOverride.class)
    public JAXBElement<XMLGregorianCalendar> createPersonRateOverrideEndDateActive(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_JobRateOverrideEndDateActive_QNAME, XMLGregorianCalendar.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = PersonRateOverride.class)
    public JAXBElement<String> createPersonRateOverrideExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = PersonRateOverride.class)
    public JAXBElement<String> createPersonRateOverrideExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, PersonRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ContractLineId", scope = NonLaborRateOverride.class)
    public JAXBElement<Long> createNonLaborRateOverrideContractLineId(Long value) {
        return new JAXBElement<Long>(_JobRateOverrideContractLineId_QNAME, Long.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "NonLaborResourceId", scope = NonLaborRateOverride.class)
    public JAXBElement<Long> createNonLaborRateOverrideNonLaborResourceId(Long value) {
        return new JAXBElement<Long>(_NonLaborRateOverrideNonLaborResourceId_QNAME, Long.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "OrganizationId", scope = NonLaborRateOverride.class)
    public JAXBElement<Long> createNonLaborRateOverrideOrganizationId(Long value) {
        return new JAXBElement<Long>(_NonLaborRateOverrideOrganizationId_QNAME, Long.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "Rate", scope = NonLaborRateOverride.class)
    public JAXBElement<BigDecimal> createNonLaborRateOverrideRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_JobRateOverrideRate_QNAME, BigDecimal.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "RateCurrencyCode", scope = NonLaborRateOverride.class)
    public JAXBElement<String> createNonLaborRateOverrideRateCurrencyCode(String value) {
        return new JAXBElement<String>(_JobRateOverrideRateCurrencyCode_QNAME, String.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "DiscountPercentage", scope = NonLaborRateOverride.class)
    public JAXBElement<BigDecimal> createNonLaborRateOverrideDiscountPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_JobRateOverrideDiscountPercentage_QNAME, BigDecimal.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "RateDiscReasonCode", scope = NonLaborRateOverride.class)
    public JAXBElement<String> createNonLaborRateOverrideRateDiscReasonCode(String value) {
        return new JAXBElement<String>(_JobRateOverrideRateDiscReasonCode_QNAME, String.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "MarkupPercentage", scope = NonLaborRateOverride.class)
    public JAXBElement<BigDecimal> createNonLaborRateOverrideMarkupPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_NonLaborRateOverrideMarkupPercentage_QNAME, BigDecimal.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EndDateActive", scope = NonLaborRateOverride.class)
    public JAXBElement<XMLGregorianCalendar> createNonLaborRateOverrideEndDateActive(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_JobRateOverrideEndDateActive_QNAME, XMLGregorianCalendar.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = NonLaborRateOverride.class)
    public JAXBElement<String> createNonLaborRateOverrideExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = NonLaborRateOverride.class)
    public JAXBElement<String> createNonLaborRateOverrideExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, NonLaborRateOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ContractLineId", scope = JobTitleOverride.class)
    public JAXBElement<Long> createJobTitleOverrideContractLineId(Long value) {
        return new JAXBElement<Long>(_JobRateOverrideContractLineId_QNAME, Long.class, JobTitleOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EndDateActive", scope = JobTitleOverride.class)
    public JAXBElement<XMLGregorianCalendar> createJobTitleOverrideEndDateActive(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_JobRateOverrideEndDateActive_QNAME, XMLGregorianCalendar.class, JobTitleOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = JobTitleOverride.class)
    public JAXBElement<String> createJobTitleOverrideExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, JobTitleOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = JobTitleOverride.class)
    public JAXBElement<String> createJobTitleOverrideExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, JobTitleOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ContractLineId", scope = JobAssignmentOverride.class)
    public JAXBElement<Long> createJobAssignmentOverrideContractLineId(Long value) {
        return new JAXBElement<Long>(_JobRateOverrideContractLineId_QNAME, Long.class, JobAssignmentOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "BillingTitle", scope = JobAssignmentOverride.class)
    public JAXBElement<String> createJobAssignmentOverrideBillingTitle(String value) {
        return new JAXBElement<String>(_JobAssignmentOverrideBillingTitle_QNAME, String.class, JobAssignmentOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EndDateActive", scope = JobAssignmentOverride.class)
    public JAXBElement<XMLGregorianCalendar> createJobAssignmentOverrideEndDateActive(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_JobRateOverrideEndDateActive_QNAME, XMLGregorianCalendar.class, JobAssignmentOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = JobAssignmentOverride.class)
    public JAXBElement<String> createJobAssignmentOverrideExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, JobAssignmentOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = JobAssignmentOverride.class)
    public JAXBElement<String> createJobAssignmentOverrideExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, JobAssignmentOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExtensionAmount", scope = AssignmentDetail.class)
    public JAXBElement<AmountType> createAssignmentDetailExtensionAmount(AmountType value) {
        return new JAXBElement<AmountType>(_AssignmentDetailExtensionAmount_QNAME, AmountType.class, AssignmentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "CurrencyCode", scope = AssignmentDetail.class)
    public JAXBElement<String> createAssignmentDetailCurrencyCode(String value) {
        return new JAXBElement<String>(_AssociatedProjectCurrencyCode_QNAME, String.class, AssignmentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "Percentage", scope = AssignmentDetail.class)
    public JAXBElement<BigDecimal> createAssignmentDetailPercentage(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_AssignmentDetailPercentage_QNAME, BigDecimal.class, AssignmentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = AssignmentDetail.class)
    public JAXBElement<String> createAssignmentDetailExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, AssignmentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = AssignmentDetail.class)
    public JAXBElement<String> createAssignmentDetailExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, AssignmentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ContractLineId", scope = LaborMultiplierOverride.class)
    public JAXBElement<Long> createLaborMultiplierOverrideContractLineId(Long value) {
        return new JAXBElement<Long>(_JobRateOverrideContractLineId_QNAME, Long.class, LaborMultiplierOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EndDateActive", scope = LaborMultiplierOverride.class)
    public JAXBElement<XMLGregorianCalendar> createLaborMultiplierOverrideEndDateActive(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_JobRateOverrideEndDateActive_QNAME, XMLGregorianCalendar.class, LaborMultiplierOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = LaborMultiplierOverride.class)
    public JAXBElement<String> createLaborMultiplierOverrideExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, LaborMultiplierOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = LaborMultiplierOverride.class)
    public JAXBElement<String> createLaborMultiplierOverrideExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, LaborMultiplierOverride.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "RbsElementId", scope = BillingControl.class)
    public JAXBElement<Long> createBillingControlRbsElementId(Long value) {
        return new JAXBElement<Long>(_BillingControlRbsElementId_QNAME, Long.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "EndDate", scope = BillingControl.class)
    public JAXBElement<XMLGregorianCalendar> createBillingControlEndDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_BillingControlEndDate_QNAME, XMLGregorianCalendar.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "SoftLimitAmount", scope = BillingControl.class)
    public JAXBElement<AmountType> createBillingControlSoftLimitAmount(AmountType value) {
        return new JAXBElement<AmountType>(_BillingControlSoftLimitAmount_QNAME, AmountType.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "SoftLimitCurrencyCode", scope = BillingControl.class)
    public JAXBElement<String> createBillingControlSoftLimitCurrencyCode(String value) {
        return new JAXBElement<String>(_BillingControlSoftLimitCurrencyCode_QNAME, String.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AmountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "HardLimitAmount", scope = BillingControl.class)
    public JAXBElement<AmountType> createBillingControlHardLimitAmount(AmountType value) {
        return new JAXBElement<AmountType>(_BillingControlHardLimitAmount_QNAME, AmountType.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "HardLimitCurrencyCode", scope = BillingControl.class)
    public JAXBElement<String> createBillingControlHardLimitCurrencyCode(String value) {
        return new JAXBElement<String>(_BillingControlHardLimitCurrencyCode_QNAME, String.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ActiveFlag", scope = BillingControl.class)
    public JAXBElement<Boolean> createBillingControlActiveFlag(Boolean value) {
        return new JAXBElement<Boolean>(_BillingControlActiveFlag_QNAME, Boolean.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalSourceKey", scope = BillingControl.class)
    public JAXBElement<String> createBillingControlExternalSourceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalSourceKey_QNAME, String.class, BillingControl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/projects/billing/contracts/contractService/", name = "ExternalReferenceKey", scope = BillingControl.class)
    public JAXBElement<String> createBillingControlExternalReferenceKey(String value) {
        return new JAXBElement<String>(_AssociatedProjectExternalReferenceKey_QNAME, String.class, BillingControl.class, value);
    }

}
