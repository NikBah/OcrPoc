package com.g4s.integration.exception;

@SuppressWarnings("serial")
public class GenericException extends Exception {
    
    public GenericException() {
    }
}
