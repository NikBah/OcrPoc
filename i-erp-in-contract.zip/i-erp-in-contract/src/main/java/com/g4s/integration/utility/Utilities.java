package com.g4s.integration.utility;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.g4s.integration.exception.GenericException;

public class Utilities {

    private static final Logger LOGGER = LoggerFactory.getLogger(Utilities.class);

    public Properties fetchPropertyFile(String propName) throws GenericException {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("fetchPropertyFile started at : " + new Date());
        }
        Properties properties = new Properties();
        InputStream input = null;
        try {
            input = this.getClass().getResourceAsStream("/" + propName);
            if (null != input) {
                properties.load(input);
            }
            else {
                LOGGER.error("Exception in loading "+ propName+ " file in Utilities : ");
                throw new GenericException(); 
            }
        } catch (IOException e) {

            LOGGER.error("Exception in loading property file in Utilities : " + e);
            throw new GenericException();
        }

        return properties;

    }
}
