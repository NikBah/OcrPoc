package com.g4s.integration.contractcreation;

import java.io.ByteArrayInputStream;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class ResponseHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseHandler.class);

	@SuppressWarnings("unchecked")
	public JSONObject prepareResponse(String response) {

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Preparing response started at : " + new Date());
		}

		JSONObject createContractResponse = new JSONObject();

		try {
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Getting & setting the attributes in response from Fusion Cloud : ");
			}
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();

			NodeList nodes = null;
			Document doc = db.parse(new InputSource(new ByteArrayInputStream(response.getBytes("utf-8"))));

			JSONObject jsonObject = new JSONObject();

			nodes = doc.getElementsByTagName("env:Fault");

			/* Handle success response */
			if (nodes.getLength() < 1) {

				nodes = doc.getElementsByTagName("ns1:Id");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("id", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:MajorVersion");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("majorVersion", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:OrgId");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("orgId", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:ContractTypeId");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("contractTypeId", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:ContractNumber");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("contractNumber", getCharacterDataFromElement(line));
				}

				nodes = doc.getElementsByTagName("ns1:StartDate");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("startDate", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:EndDate");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("endDate", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:BuyOrSell");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("buyOrSell", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:CurrencyCode");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("currencyCode", getCharacterDataFromElement(line));
				}

				nodes = doc.getElementsByTagName("ns1:LegalEntityId");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("legalEntityId", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:LineAutonumberEnabledFlag");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("lineAutonumberEnabledFlag", getCharacterDataFromElement(line));
				}

				nodes = doc.getElementsByTagName("ns1:StsCode");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("stsCode", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:WebServiceFlag");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("webServiceFlag", getCharacterDataFromElement(line));
				}
				nodes = doc.getElementsByTagName("ns1:AgreementEnabledFlag");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("agreementEnabledFlag", getCharacterDataFromElement(line));
				}

				createContractResponse.put("createContractResponse", jsonObject);
			}

			/* Handle fault response */
			else {

				nodes = doc.getElementsByTagName("faultcode");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("faultCode", getCharacterDataFromElement(line));

				}
				nodes = doc.getElementsByTagName("faultstring");
				if (nodes.getLength() > 0) {
					Element line = (Element) nodes.item(0);
					jsonObject.put("faultString", getCharacterDataFromElement(line));
				}

				createContractResponse.put("faultResponse", jsonObject);
			}
		} catch (Exception e) {
			LOGGER.error("Exception caught: " + e.getMessage());
		}
		return createContractResponse;

	}

	public String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "";
	}

}
