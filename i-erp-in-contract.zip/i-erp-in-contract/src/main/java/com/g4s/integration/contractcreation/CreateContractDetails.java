package com.g4s.integration.contractcreation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.camel.Body;
import com.g4s.integration.constant.Constants;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractHeader;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractParty;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ContractPartyContact;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.types.CreateContract;
import com.oracle.xmlns.apps.contracts.coreauthoring.transaction.transactionservice.ObjectFactory;

public class CreateContractDetails {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateContractDetails.class);

    @SuppressWarnings("rawtypes")
    public CreateContract prepareContractDetails(@Body HashMap<?, ?> hashMap)
            throws DatatypeConfigurationException, java.text.ParseException {

        org.slf4j.MDC.put("app.name", "i-erp-in-contract");
        ObjectFactory fact = new ObjectFactory();
        CreateContract cc = new CreateContract();
        ContractHeader ch = new ContractHeader();
        ContractParty cp = new ContractParty();
        ContractParty cp2 = new ContractParty();

        ContractPartyContact cpc = new ContractPartyContact();

        try {

            Map<?, ?> creatCntrct = (HashMap<?, ?>) hashMap.get("createContract");
            Map<?, ?> cntrctHeader = (HashMap<?, ?>) creatCntrct.get("contractHeader");
            List contractPartyList = (ArrayList) cntrctHeader.get("ContractParty");
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Contract Party list: " + contractPartyList.toString());
            }
            Map<?, ?> cntrctParty1 = (HashMap<?, ?>) contractPartyList.get(0);
            Map<?, ?> cntrctParty2 = (HashMap<?, ?>) contractPartyList.get(1);
            Map<?, ?> cntrctPartyCntct = (HashMap<?, ?>) cntrctParty1.get("ContractPartyContact");

            if (cntrctHeader.get("OrgId") != "") {
                String test = String.valueOf(cntrctHeader.get("OrgId"));
                long orgId = Long.valueOf((String) test).longValue();
                ch.setOrgId(orgId);
            }

            if (cntrctHeader.get("ContractTypeId") != "") {
                String test = String.valueOf(cntrctHeader.get("ContractTypeId"));
                long CntrctTypId = Long.valueOf((String) test).longValue();
                ch.setContractTypeId(CntrctTypId);
            }

            ch.setContractNumber(cntrctHeader.get("ContractNumber").toString());

            DateFormat df = new SimpleDateFormat(Constants.DATE_FORMAT);

            Date strtdate = null;
            strtdate = df.parse(cntrctHeader.get("StartDate").toString());
            GregorianCalendar startd = new GregorianCalendar();
            startd.setTime(strtdate);
            XMLGregorianCalendar sdate = DatatypeFactory.newInstance().newXMLGregorianCalendar(startd);
            ch.setStartDate(sdate);

            Date enddate = null;
            enddate = df.parse(cntrctHeader.get("EndDate").toString());
            GregorianCalendar endd = new GregorianCalendar();
            endd.setTime(enddate);
            XMLGregorianCalendar xgcal2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(endd);
            JAXBElement<XMLGregorianCalendar> edate = fact.createContractLineEndDate(xgcal2);
            ch.setEndDate(edate);

            ch.setBuyOrSell(cntrctHeader.get("BuyOrSell").toString());

            if (cntrctHeader.get("LegalEntityId") != "") {
                String test = String.valueOf(cntrctHeader.get("LegalEntityId"));
                long LegalEntityId = Long.valueOf((String) test).longValue();
                JAXBElement<Long> LegalId = fact.createContractHeaderLegalEntityId(LegalEntityId);
                ch.setLegalEntityId(LegalId);
            }

            if (cntrctHeader.get("LineAutonumberEnabledFlag") != "") {
                String test = String.valueOf(cntrctHeader.get("LineAutonumberEnabledFlag"));
                Boolean LineAutonumberEnabledFlag = Boolean.valueOf((String) test).booleanValue();
                JAXBElement<Boolean> LineFlag = fact
                        .createContractHeaderLineAutonumberEnabledFlag(LineAutonumberEnabledFlag);
                ch.setLineAutonumberEnabledFlag(LineFlag);
            }

            String RleCodevar = (cntrctParty1.get("RleCode").toString());
            cp.setRleCode(RleCodevar);
            cp2.setRleCode(cntrctParty2.get("RleCode").toString());

            JAXBElement<String> JtObject1Code = fact
                    .createContractLineJtotObject1Code(cntrctParty1.get("JtotObject1Code").toString());
            cp.setJtotObject1Code(JtObject1Code);
            JAXBElement<String> JtObject1Code2 = fact
                    .createContractLineJtotObject1Code(cntrctParty2.get("JtotObject1Code").toString());
            cp2.setJtotObject1Code(JtObject1Code2);

            if (cntrctParty1.get("Object1Id1") != "") {
                String test = String.valueOf(cntrctParty1.get("Object1Id1"));
                long Object1_Id1 = Long.valueOf((String) test).longValue();

                cp.setObject1Id1(Object1_Id1);
            }

            if (cntrctParty2.get("Object1Id1") != "") {
                String test = String.valueOf(cntrctParty2.get("Object1Id1"));
                long Object1_Id2 = Long.valueOf((String) test).longValue();

                cp2.setObject1Id1(Object1_Id2);
            }

            cpc.setCroCode(cntrctPartyCntct.get("CroCode").toString());

            cpc.setJtotObject1Code(cntrctPartyCntct.get("JtotObject1Code").toString());

            if (cntrctPartyCntct.get("Object1Id1") != "") {
                String test = String.valueOf(cntrctPartyCntct.get("Object1Id1"));
                long Object1_Id1_cpc = Long.valueOf((String) test).longValue();

                cpc.setObject1Id1(Object1_Id1_cpc);
            }

            JAXBElement<String> Owner_Yn = fact
                    .createContractPartyContactOwnerYn(cntrctPartyCntct.get("OwnerYn").toString());
            cpc.setOwnerYn(Owner_Yn);

            cp.getContractPartyContact().add(cpc);
            ch.getContractParty().add(cp);
            ch.getContractParty().add(cp2);

        }

        catch (Exception e) {

            LOGGER.error("Exception caught: " + e.getMessage());
        }

        cc.setContractHeader(ch);

        return cc;
    }

}
