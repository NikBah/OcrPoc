package com.g4s.integration.exception;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.g4s.integration.exception.GenericException;
import com.g4s.integration.constant.Constants;
import com.g4s.integration.exception.DBConnection;
import com.g4s.integration.utility.Utilities;

public class ErrorMapper {

    private static Utilities utility = new Utilities();

    static Map<String, LinkedHashMap<String, String>> exceptionMap = new LinkedHashMap<String, LinkedHashMap<String, String>>();
    static Map<String, String> restMap = null;
    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorMapper.class);

    static JSONObject replyStatus = new JSONObject();
    Statement stmt = null;
    ResultSet rs = null;
    Properties properties = utility.fetchPropertyFile(Constants.PROPERTYFILE);

    private ErrorMapper() throws GenericException {

        try {

            stmt = DBConnection.getStatement();
            rs = stmt.executeQuery(
                    "SELECT Exception, Status, ServiceCode, Originator, OriginatorCode, OriginatorMessage, Severity FROM ErrorMapper");

            while (rs.next()) {
                restMap = new LinkedHashMap<String, String>();
                restMap.put(Constants.STATUS, rs.getString(Constants.STATUS));
                restMap.put(Constants.SERVICECODE, rs.getString(Constants.SERVICECODE));
                restMap.put(Constants.ORIGINATOR, rs.getString(Constants.ORIGINATOR));
                restMap.put(Constants.ORIGINATORCODE, rs.getString(Constants.ORIGINATORCODE));
                restMap.put(Constants.ORIGINATORMESSAGE, rs.getString(Constants.ORIGINATORMESSAGE));
                restMap.put(Constants.SEVERITY, rs.getString(Constants.SEVERITY));
                restMap.put("InterfaceId", properties.getProperty("contract.interfaceId"));
                restMap.put("InterfaceDesc", properties.getProperty("contract.interfaceDesc"));
                exceptionMap.put(rs.getString("Exception").toString(), (LinkedHashMap<String, String>) restMap);
            }
        } catch (SQLException e) {
            LOGGER.error("ErrorMapper.ErrorMapper - SQL connection failed in method arrayReading :" + e);
            throw new GenericException();
        } catch (Exception e) {
            LOGGER.info("ErrorMapper.ErrorMapper - Generic Exception caught :" + e);
            throw new GenericException();
        }
    }

    @SuppressWarnings("unchecked")
    public static JSONObject jsonExceptionResponse(String exception) throws GenericException {
        Properties properties = utility.fetchPropertyFile(Constants.PROPERTYFILE);
        LOGGER.info("ErrorMapper.jsonExceptionResponse - Inside Error Mapper");
        JSONObject finalResponse = null;
        finalResponse = new JSONObject();
        String[] parts = exception.split(":");
        String excep = parts[0];
        if (null != exceptionMap.get(excep)) {
            Map<String, String> excepMap = exceptionMap.get(excep);
            replyStatus.put("ReplyStatus", excepMap);
            finalResponse.put("Response", replyStatus);
            return finalResponse;
        }
        LOGGER.info("ErrorMapper.jsonExceptionResponse - Exception Not listed in Database");
        Map<String, String> jsonExceptionObjectResponse = new LinkedHashMap<String, String>();
        JSONObject jsonExceptionReplyStatus = new JSONObject();
        jsonExceptionObjectResponse.put(Constants.STATUS, "F");
        jsonExceptionObjectResponse.put(Constants.SERVICECODE, "503");
        jsonExceptionObjectResponse.put(Constants.ORIGINATOR, "Integration");
        jsonExceptionObjectResponse.put(Constants.ORIGINATORCODE, "T0100");
        jsonExceptionObjectResponse.put(Constants.ORIGINATORMESSAGE, exception);
        jsonExceptionObjectResponse.put(Constants.SEVERITY, "4");
        jsonExceptionObjectResponse.put("InterfaceId", properties.getProperty("contract.interfaceId"));
        jsonExceptionObjectResponse.put("InterfaceDesc", properties.getProperty("contract.interfaceDesc"));
        jsonExceptionReplyStatus.put("ReplyStatus", jsonExceptionObjectResponse);
        finalResponse.put("Response", jsonExceptionReplyStatus);
        return finalResponse;
    }

}
