package com.g4s.integration.contractcreation;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.camel.Exchange;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.g4s.integration.constant.Constants;
import com.g4s.integration.exception.GenericException;
import com.g4s.integration.utility.Utilities;

public class Response {

    private static Utilities utility = new Utilities();

    @SuppressWarnings({ "unused" })
    public org.json.simple.JSONObject xmlToJson(Exchange exchange)
            throws JSONException, org.json.JSONException, IOException, ParseException {
        org.json.simple.JSONObject jsonsimple = new org.json.simple.JSONObject();
        JSONObject xmlJsonObject = new JSONObject();
        String body = exchange.getIn().getBody(String.class);
        xmlJsonObject = org.json.XML.toJSONObject(body);

        JSONParser jsonParser = new JSONParser();

        org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject) jsonParser.parse(xmlJsonObject.toString());

        return jsonObject;
    }

    @SuppressWarnings("unchecked")
    public org.json.simple.JSONObject opsResponse(Exchange exchange)
            throws org.json.JSONException, ParseException, GenericException {
        String jsonBody = exchange.getIn().getBody(String.class);
        Properties properties = utility.fetchPropertyFile(Constants.PROPERTYFILE);
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);

        org.json.simple.JSONObject finalResponse = new org.json.simple.JSONObject();
        Map<String, String> replyStatusComponents = new LinkedHashMap<String, String>();
        LinkedHashMap<String, Object> datalog = new LinkedHashMap<String, Object>();

        if (jsonBody.contains("Fault")) {

            replyStatusComponents.put(Constants.STATUS, "F");
            replyStatusComponents.put(Constants.SERVICECODE, "HTTP 500");
            replyStatusComponents.put(Constants.ORIGINATOR, "Oracle Fusion");
            replyStatusComponents.put(Constants.ORIGINATORCODE, "");
            replyStatusComponents.put(Constants.ORIGINATORMESSAGE, "");
            replyStatusComponents.put(Constants.SEVERITY, "4");
            replyStatusComponents.put(Constants.INTERFACEID, properties.getProperty("contract.interfaceId"));
            replyStatusComponents.put(Constants.INTERFACEDESC, properties.getProperty("contract.interfaceDesc"));
            datalog.put("ReplyStatus", replyStatusComponents);
            datalog.put("DATA", exchange.getIn().getBody());

            finalResponse.put("Response", datalog);
        } else {

            replyStatusComponents.put(Constants.STATUS, "S");
            replyStatusComponents.put(Constants.SERVICECODE, "200");
            replyStatusComponents.put(Constants.ORIGINATOR, "Integration");
            replyStatusComponents.put(Constants.ORIGINATORCODE, "S0000");
            replyStatusComponents.put(Constants.ORIGINATORMESSAGE, "Success");
            replyStatusComponents.put(Constants.SEVERITY, "Nil");
            replyStatusComponents.put(Constants.INTERFACEID, properties.getProperty("contract.interfaceId"));
            replyStatusComponents.put(Constants.INTERFACEDESC, properties.getProperty("contract.interfaceDesc"));
            datalog.put("ReplyStatus", replyStatusComponents);
            datalog.put("DATA", exchange.getIn().getBody());
            finalResponse.put("Response", datalog);
        }
        return finalResponse;
    }
}
