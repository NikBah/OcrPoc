package com.g4s.integration.constant;

public class Constants {

    public static final String DATE_FORMAT = "yyyy-MM-dd";

    public static final String STATUS = "Status";

    public static final String SERVICECODE = "ServiceCode";

    public static final String ORIGINATOR = "Originator";

    public static final String ORIGINATORCODE = "OriginatorCode";

    public static final String ORIGINATORMESSAGE = "OriginatorMessage";

    public static final String SEVERITY = "Severity";
    
    public static final String INTERFACEID = "InterfaceId";
    
    public static final String INTERFACEDESC = "InterfaceDesc";

    public static final String PROPERTYFILE = "contract.properties";

    public static final String PROPERTY_FILE_NAME = "contract.properties";

    private Constants() {

    }
}
