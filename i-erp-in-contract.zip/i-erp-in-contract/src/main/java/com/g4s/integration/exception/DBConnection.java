package com.g4s.integration.exception;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.g4s.integration.constant.Constants;
import com.g4s.integration.exception.GenericException;
import com.g4s.integration.utility.Utilities;

public class DBConnection {
    private static String userName;
    private static String password;
    private static String host;
    private static String port;
    private static String dbname;
    private static String dbClient;
    private static Statement statement;
    private static Utilities utility = new Utilities();
    private static DataSource dataSource = new DataSource();
    private static final Logger LOGGER = LoggerFactory.getLogger(DBConnection.class);

    private DBConnection() {
        /*
         * Default database parameters
         */
        try {

            DriverManager.registerDriver(new com.mysql.jdbc.Driver());

            Properties prop = null;
            prop = utility.fetchPropertyFile(Constants.PROPERTYFILE);

            host = prop.getProperty("contract.sql.host");
            port = prop.getProperty("contract.sql.port");
            dbname = prop.getProperty("contract.sql.database");
            userName = prop.getProperty("contract.sql.username");
            password = prop.getProperty("contract.sql.password");
            dbClient = prop.getProperty("contract.sql.client");
            /* Creation of an instance of the connection statement */
            statement = getConnectionStatement();
        } catch (SQLException e) {
            LOGGER.error("DBConnection.DBConnection - SQLException occured :" + e);
        } catch (GenericException e) {
            LOGGER.error("DBConnection.DBConnection - GenericException occured :" + e);
        }
    }

    /* Private method charge to set the connection statement */
    private static Statement getConnectionStatement() throws GenericException {
        try {
            Properties prop = utility.fetchPropertyFile(Constants.PROPERTYFILE);
            StringBuilder sb = new StringBuilder();
            sb.append("jdbc:");
            sb.append(dbClient);
            sb.append(":");
            sb.append("//");
            sb.append(host);
            sb.append(":");
            sb.append(port);
            sb.append("/");
            sb.append(dbname);

            Connection conn = DriverManager.getConnection(sb.toString(), userName, password);

            dataSource.setUsername(userName);
            dataSource.setPassword(password);
            dataSource.setDriverClassName(prop.getProperty("contract.sql.driver"));
            dataSource.setUrl(sb.toString());

            // Creation of the Statement object
            java.sql.Statement state = conn.createStatement();
            return (Statement) state;
        } catch (SQLException ex) {
            LOGGER.error("DBConnection.getConnectionStatement - Error during creating Datasource :" + ex);
        }
        return null;
    }

    /*
     * Private inner class responsible for instantiating the single instance of
     * the singleton
     */
    private static class DbSingletonManagerHolder {

        private static final DBConnection INSTANCE = new DBConnection();

        private DbSingletonManagerHolder() {

        }

    }

    /**
     * @return Public method, which is the only method allowed to return an
     *         instance of the singleton (the instance here is the database
     *         connection statement)
     */
    public static DBConnection getInstance() {
        try {
            return DbSingletonManagerHolder.INSTANCE;
        } catch (ExceptionInInitializerError ex) {
            LOGGER.info("DBConnection.getInstance - Initialization error :" + ex);
        }
        return null;
    }

    public static Statement getStatement() {
        return statement;
    }

    public static DataSource getDataSource() {
        return dataSource;
    }
}