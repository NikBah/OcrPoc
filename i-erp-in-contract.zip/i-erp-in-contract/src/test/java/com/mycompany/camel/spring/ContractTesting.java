package com.mycompany.camel.spring;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.camel.EndpointInject;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.CamelSpringTestSupport;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ContractTesting extends CamelSpringTestSupport {

	HashMap<String, Object> hashMap = new HashMap<String, Object>();

	@EndpointInject(uri = "mock:result")
	protected MockEndpoint resultEndpoint;

	@Produce(uri = "direct:restService")
	protected ProducerTemplate inputEndpoint;

	@SuppressWarnings("unchecked")
	@Test
	public void testCamelRoute() throws Exception {

		HashMap<String, Object> tempHashMap1 = new HashMap<String, Object>();
		HashMap<String, Object> tempHashMap2 = new HashMap<String, Object>();
		HashMap<String, Object> tempHashMap3 = new HashMap<String, Object>();
		HashMap<String, Object> CP1 = new HashMap<String, Object>();
		HashMap<String, Object> CP2 = new HashMap<String, Object>();
		@SuppressWarnings("rawtypes")
		ArrayList CPList = new ArrayList();

		tempHashMap2.put("OrgId", "300000021587116");
		tempHashMap2.put("ContractTypeId", "300000030190622");
		tempHashMap2.put("ContractNumber", "56660E");
		tempHashMap2.put("StartDate", "2016-05-05");
		tempHashMap2.put("EndDate", "2017-05-05");
		tempHashMap2.put("BuyOrSell", "S");
		tempHashMap2.put("LegalEntityId", "300000021533917");
		tempHashMap2.put("LineAutonumberEnabledFlag", "1");

		CP1.put("RleCode", "SUPPLIER");
		CP1.put("JtotObject1Code", "OKX_OPERUNIT");
		CP1.put("Object1Id1", "300000021587116");
		CP1.put("ContractPartyContact", tempHashMap3);

		tempHashMap3.put("CroCode", "CONTRACT_ADMIN");
		tempHashMap3.put("JtotObject1Code", "OKX_RESOURCE");
		tempHashMap3.put("Object1Id1", "300000018193004");
		tempHashMap3.put("OwnerYn", "Y");

		CP2.put("RleCode", "CUSTOMER");
		CP2.put("JtotObject1Code", "OKX_OPERUNIT");
		CP2.put("Object1Id1", "300000021587116");

		CPList.add(CP1);
		CPList.add(CP2);
		tempHashMap2.put("ContractParty", CPList);

		tempHashMap1.put("contractHeader", tempHashMap2);
		hashMap.put("createContract", tempHashMap1);

		context.getRouteDefinition("CntrctResponse").adviceWith(context, new AdviceWithRouteBuilder() {
			@Override
			public void configure() throws Exception {
				replaceFromWith("direct:restService");
				weaveById("response").after().convertBodyTo(String.class).to("mock:result");
			}
		});

		context.start();

		inputEndpoint.sendBody(hashMap);

		String response = getMockEndpoint("mock:result").getExchanges().get(0).getIn().getBody().toString();

		assertTrue(response.contains("createContractResponse"));

	}

	@Override
	protected ClassPathXmlApplicationContext createApplicationContext() {
		return new ClassPathXmlApplicationContext("META-INF/spring/camel-context.xml");
	}

}
