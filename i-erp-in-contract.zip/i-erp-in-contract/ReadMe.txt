I-ERP-IN-006-Create Contract
===========================

To build this project use

    mvn install

To run this project with Maven use

    mvn camel:run

For more help see the G4S Integration documentation

	http://jira.g4s.com:8090/display/javint/Interface+Specs 